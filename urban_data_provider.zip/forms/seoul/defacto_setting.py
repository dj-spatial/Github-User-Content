# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Population Dialog
                                 A QGIS plugin
 .
                             -------------------
        begin                : 2017-02-06
        git sha              : $Format:%H$
        copyright            : (C) 2017 by D.J Paek
        email                : dj.paek2@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import json
import os
import glob
import tempfile
import pandas as pd
import geopandas as gpd
import sqlite3
import zipfile
import urllib.request
from PyQt5 import uic
from datetime import datetime, timedelta
from pathlib import Path
from PyQt5.QtWidgets import (
    QCheckBox, QSizePolicy, QGridLayout, QVBoxLayout, QDialog, QDialogButtonBox
)
from qgis.core import QgsMessageLog, Qgis, QgsSettings
from qgis.gui import QgsMessageBar
from qgis.PyQt.QtCore import pyqtSignal
from ...utils.sgis_utils import available_years, get_access_token, get_admin_area

# Constants
FORM_CLASS_SETTING, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'defacto_setting.ui'))
DEFAULT_TIMEOUT = '2017-02-07 12:00'
GPKG_FILE = 'seoul.gpkg'
DB_ERROR_MSG = 'DB를 저장할 경로를 지정하세요.'
TOKEN_ERROR_MSG = '인증키 발급이 정상적으로 처리되지 않았습니다.'

class DefactoSetting(QDialog, FORM_CLASS_SETTING):
    closing_plugin = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.load_settings()
        self.connect_signals()
        self.check_boundary()
        self.status_check()

    def setup_ui(self):
        self.setupUi(self)
        self.bar = QgsMessageBar()
        self.bar.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        self.setLayout(QGridLayout())
        self.layout().setContentsMargins(10, 10, 5, 5)
        self.layout().addWidget(self.groupBox, 0, 0, 2, 1)
        self.layout().addWidget(self.bar, 0, 0, 1, 1)
        self.show()
        self.action_label.hide()
        self.ok_button = self.dialog_BB.button(QDialogButtonBox.Ok)
        self.ok_button.setEnabled(False)

    def load_settings(self):
        self.qst = QgsSettings()
        self.defacto_key = self.qst.value('urban_data_provider/defactoKey', '')
        self.consumer_key = self.qst.value('urban_data_provider/consumerKey', '')
        self.consumer_secret = self.qst.value('urban_data_provider/consumerSecret', '')
        self.access_token = self.qst.value('urban_data_provider/accessToken', '')
        self.access_timeout = self.qst.value('urban_data_provider/accessTimeout', DEFAULT_TIMEOUT)
        self.access_timeout_parse = datetime.strptime(self.access_timeout, '%Y-%m-%d %H:%M')
        self.db_path = self.qst.value('urban_data_provider/dbPath', '')
        self.manual_download = False

        self.defactoKeyLE.setText(self.defacto_key)
        self.consumerKeyLE.setText(self.consumer_key)
        self.consumerSecretLE.setText(self.consumer_secret)
        if self.db_path and Path(self.db_path).exists():
            self.dbPathFW.setDefaultRoot(self.db_path)
            self.dbPathFW.setFilePath(self.db_path)

        self.update_check_status(self.defacto_key, self.defactoKeyCkB)
        self.update_check_status(self.consumer_key, self.consumerKeyCkB)
        self.update_check_status(self.consumer_secret, self.consumerSecretCkB)
        self.update_check_status(self.db_path, self.dbPathCkB)

    def connect_signals(self):
        self.defactoKeyLE.textEdited.connect(lambda: self.update_check_status(self.defactoKeyLE.text(), self.defactoKeyCkB))
        self.consumerKeyLE.textEdited.connect(lambda: self.update_check_status(self.consumerKeyLE.text(), self.consumerKeyCkB))
        self.consumerSecretLE.textEdited.connect(lambda: self.update_check_status(self.consumerSecretLE.text(), self.consumerSecretCkB))
        self.dbPathFW.fileChanged.connect(self.set_db_path)
        self.sggBtn.clicked.connect(lambda: self.get_boundary('11', '1', 'sgg'))
        self.emdBtn.clicked.connect(lambda: self.get_boundary('11', '2', 'emd'))
        self.trackBtn.clicked.connect(lambda: self.get_boundary('', '2', 'track'))

    def update_check_status(self, text: str, checkbox: QCheckBox):
        checkbox.setChecked(bool(text))
        self.status_check()

    def check_boundary(self):
        self.reset_boundary_ui()
        if not self.db_path or not os.path.isdir(self.db_path):
            return
        admin_boundary_path = os.path.join(self.db_path, GPKG_FILE)
        if not os.path.isfile(admin_boundary_path):
            return

        conn = sqlite3.connect(admin_boundary_path)
        cursor = conn.cursor()
        cursor.execute("SELECT table_name FROM gpkg_contents")
        rows = cursor.fetchall()

        for row in rows:
            table_name = row[0]
            if 'sgg' in table_name:
                self.set_boundary_ui(self.sggPathCkB, self.sggBtn)
            if 'emd' in table_name:
                self.set_boundary_ui(self.emdPathCkB, self.emdBtn)
            if 'track' in table_name:
                self.set_boundary_ui(self.trackPathCkB, self.trackBtn)

        cursor.close()
        conn.close()

    def reset_boundary_ui(self):
        self.sggPathCkB.setChecked(False)
        self.sggBtn.setEnabled(True)
        self.emdPathCkB.setChecked(False)
        self.emdBtn.setEnabled(True)
        self.trackPathCkB.setChecked(False)
        self.trackBtn.setEnabled(True)

    def set_boundary_ui(self, checkbox: QCheckBox, pushbutton):
        checkbox.setChecked(True)
        pushbutton.setEnabled(False)

    def set_db_path(self):
        file_path = str(Path(self.dbPathFW.filePath()).resolve())
        self.qst.setValue('urban_data_provider/dbPath', file_path)
        self.update_check_status(file_path, self.dbPathCkB)
        self.db_path = file_path
        self.check_boundary()

    def get_boundary(self, admin_level: str, low_search: str, prefix: str):
        if not self.dbPathCkB.isChecked():
            self.show_message(DB_ERROR_MSG, Qgis.Warning)
            return
        if not self.access_token or self.access_timeout_parse <= datetime.now():
            if not self.refresh_access_token():
                return
        admin_path = os.path.join(self.db_path, GPKG_FILE)
        if admin_level:
            self.retrieve_admin_area(admin_level, low_search, prefix, admin_path)
        else:
            self.download_track_data(admin_path, prefix)
        self.status_check()

    def refresh_access_token(self) -> bool:
        consumer_key = self.consumerKeyLE.text()
        consumer_secret = self.consumerSecretLE.text()
        if not consumer_key:
            self.show_message('서비스 ID(Consumer Key)를 입력해주세요.', Qgis.Warning)
            return False
        if not consumer_secret:
            self.show_message('보안 Key(Consumer Secret)를 입력해주세요.', Qgis.Warning)
            return False
        try:
            self.access_response = get_access_token(consumer_key, consumer_secret)
        except Exception:
            self.show_message(TOKEN_ERROR_MSG, Qgis.Warning)
            return False
        else:
            if self.access_response[2] == 'Success':
                self.access_token = self.access_response[0]
                self.access_timeout = datetime.fromtimestamp(self.access_response[1]).strftime('%Y-%m-%d %H:%M')
                self.qst.setValue('urban_data_provider/accessToken', self.access_token)
                self.qst.setValue('urban_data_provider/accessTimeout', self.access_timeout)
                return True
            else:
                self.show_message(self.access_response[2], Qgis.Warning)
                return False

    def retrieve_admin_area(self, admin_level: str, low_search: str, prefix: str, admin_path: str):
        boundary = get_admin_area(self.access_token, admin_level, low_search, '2016')
        gdf = gpd.GeoDataFrame.from_features(boundary['features'])
        table_path = os.path.join(os.path.dirname(__file__), '../../utils/', f'adm_{prefix}.csv')
        table = pd.read_csv(table_path, header=0, encoding='cp949', dtype=str)
        gdf = pd.merge(gdf[['adm_cd', 'adm_nm', 'geometry']], table[['adm_cd', 'defacto_cd']], how='left', on='adm_cd')
        gdf.to_file(admin_path, layer=prefix, driver="GPKG")
        self.show_message(u'성공!', Qgis.Info)
        self.set_boundary_ui(self.get_checkbox(prefix), self.get_pushbutton(prefix))

    def download_track_data(self, admin_path: str, prefix: str):
        temp_dir = tempfile.gettempdir()
        if not self.manual_download:
            url = 'https://datafile.seoul.go.kr/bigfile/iot/inf/nio_download.do?useCache=false&infId=DOWNLOAD&infSeq=4&seqNo=&seq=5'
            zip_path = os.path.join(temp_dir, 'track.zip')
            try:
                urllib.request.urlretrieve(url, zip_path)
            except Exception:
                self.action_label.show()
                self.manual_download = True
                self.show_message(u'보안 등의 이유로 연결되지 않습니다.', Qgis.Warning)
            else:
                self.extract_track_data(zip_path, temp_dir, admin_path, prefix)
        else:
            zip_path = self.get_latest_downloaded_file()
            self.extract_track_data(zip_path, temp_dir, admin_path, prefix)

    def extract_track_data(self, zip_path: str, temp_dir: str, admin_path: str, prefix: str):
        fnames = ['track.dbf', 'track.sbn', 'track.sbx', 'track.shp', 'track.shx']
        with zipfile.ZipFile(zip_path, 'r') as zf:
            for i, member in enumerate(zf.infolist()):
                if i < 6:  # skip administrative files
                    continue
                member.filename = fnames[i - 6]
                zf.extract(member, temp_dir)
        os.remove(zip_path)
        shp_path = os.path.join(temp_dir, 'track.shp')
        gdf = gpd.read_file(shp_path, encoding='cp949')
        gdf.rename(columns={'TOT_REG_CD': 'defacto_cd', 'ADM_NM': 'adm_nm', 'ADM_CD': 'adm_cd'}, inplace=True)
        gdf.to_file(admin_path, layer=prefix, driver='GPKG')
        self.show_message(u'성공!', Qgis.Info)
        self.set_boundary_ui(self.trackPathCkB, self.trackBtn)

    def get_checkbox(self, prefix: str) -> QCheckBox:
        if prefix == 'sgg':
            return self.sggPathCkB
        elif prefix == 'emd':
            return self.emdPathCkB
        elif prefix == 'track':
            return self.trackPathCkB

    def get_pushbutton(self, prefix: str):
        if prefix == 'sgg':
            return self.sggBtn
        elif prefix == 'emd':
            return self.emdBtn
        elif prefix == 'track':
            return self.trackBtn

    def show_message(self, message: str, level: Qgis.MessageLevel):
        self.bar.pushMessage("Warning:", message, level=level, duration=2)

    def status_check(self):
        ready_list = [checkbox.isChecked() for checkbox in self.groupBox.findChildren(QCheckBox)]
        if False in ready_list:
            if_ready = '설정이 완료되지 않았습니다.'
            self.ok_button.setEnabled(False)
        else:
            self.qst.setValue('urban_data_provider/consumerKey', self.consumerKeyLE.text())
            self.qst.setValue('urban_data_provider/consumerSecret', self.consumerSecretLE.text())
            self.qst.setValue('urban_data_provider/defactoKey', self.defactoKeyLE.text())
            if_ready = '설정 완료! 확인버튼을 눌러주세요.'
            self.ok_button.setEnabled(True)
        self.label.setText(if_ready)

    def get_latest_downloaded_file(self, download_folder=None):
        if download_folder is None:
            # Use default download folder based on the OS
            if os.name == 'nt':  # Windows
                download_folder = os.path.join(os.environ['USERPROFILE'], 'Downloads')
            else:  # macOS/Linux
                download_folder = os.path.join(os.path.expanduser('~'), 'Downloads')

        # Get list of files in the download folder
        files = glob.glob(os.path.join(download_folder, '*'))

        if not files:
            return None

        # Find the most recently modified file
        latest_file = max(files, key=os.path.getctime)
        return latest_file


    def closeEvent(self, event):
        self.closing_plugin.emit()
        event.accept()
