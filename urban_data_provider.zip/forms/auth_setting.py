# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Population Dialog
                                 A QGIS plugin
 .
                             -------------------
        begin                : 2017-02-06
        git sha              : $Format:%H$
        copyright            : (C) 2017 by D.J Paek
        email                : dj.paek2@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
import os.path
import tempfile
import pandas as pd
import geopandas as gpd
import sqlite3
import zipfile
import urllib.request
from PyQt5 import uic
from datetime import datetime, timedelta
from pathlib import Path
from PyQt5.QtWidgets import QCheckBox, QSizePolicy, QGridLayout, QVBoxLayout
from qgis.PyQt.QtWidgets import QDialog, QDialogButtonBox
from qgis.core import QgsMessageLog
from qgis.gui import QgsMessageBar
from qgis.PyQt.QtCore import pyqtSignal

from qgis.core import (
    Qgis,
    QgsSettings
)

FORM_CLASS_SETTING, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'auth_setting.ui'))

class AuthSetting(QDialog, FORM_CLASS_SETTING):
    closingPlugin = pyqtSignal()

    def __init__(self, iface, parent=None):
        self.iface = iface
        super(AuthSetting, self).__init__(parent)
        self.setupUi(self)
        self.bar = QgsMessageBar()
        self.bar.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        self.setLayout(QGridLayout())
        self.layout().setContentsMargins(10, 10, 5, 5)
        self.layout().addWidget(self.groupBox, 0, 0, 2, 1)
        self.layout().addWidget(self.bar, 0, 0, 1, 1)
        self.show()

        # Constructor
        self.ok_button = self.dialog_BB.button(QDialogButtonBox.Ok)
        self.ok_button.setEnabled(False)
        self.qst = QgsSettings()

        self.vworld_key = self.qst.value('urban_data_provider/vworld_key')
        self.road_key = self.qst.value('urban_data_provider/road_key')
        self.naver_key = self.qst.value('urban_data_provider/naver_key')
        self.naver_secret = self.qst.value('urban_data_provider/naver_secret')
        self.kakao_key = self.qst.value('urban_data_provider/kakao_key')

        self.vworldLE.setText(self.vworld_key) if self.vworld_key else self.vworldLE.setText('')
        self.roadLE.setText(self.road_key) if self.road_key else self.roadLE.setText('')
        self.naverLE.setText(self.naver_key) if self.naver_key else self.naverLE.setText('')
        self.naverLE_2.setText(self.naver_secret) if self.naver_key else self.naverLE_2.setText('')
        self.kakaoLE.setText(self.kakao_key) if self.kakao_key else self.kakaoLE.setText('')

        self.change_check_status(self.vworldLE.text(), self.vworldCkB)
        self.change_check_status(self.roadLE.text(), self.roadCkB)
        self.change_check_status(self.naverLE.text(), self.naverCkB)
        self.change_check_status(self.naverLE_2.text(), self.naverCkB_2)
        self.change_check_status(self.kakaoLE.text(), self.kakaoCkB)

        # Connect signals
        self.vworldLE.textEdited.connect(lambda: self.change_check_status(self.vworldLE.text(), self.vworldCkB))
        self.roadLE.textEdited.connect(lambda: self.change_check_status(self.roadLE.text(), self.roadCkB))
        self.naverLE.textEdited.connect(lambda: self.change_check_status(self.naverLE.text(), self.naverCkB))
        self.naverLE_2.textEdited.connect(lambda: self.change_check_status(self.naverLE_2.text(), self.naverCkB_2))
        self.kakaoLE.textEdited.connect(lambda: self.change_check_status(self.kakaoLE.text(), self.kakaoCkB))

    # end of __init__

    def change_check_status(self, txt, ckb):
        if txt == '':
            ckb.setChecked(False)
        else:
            ckb.setChecked(True)
        self.status_check()

    def status_check(self):
        ready_list = [checkbox.isChecked() for checkbox in self.groupBox.findChildren(QCheckBox)]
        if False in ready_list:
            if_ready = ''
            self.ok_button.setEnabled(False)
        else:
            self.qst.setValue('urban_data_provider/vworld_key', self.vworldLE.text())
            self.qst.setValue('urban_data_provider/road_key', self.roadLE.text())
            self.qst.setValue('urban_data_provider/naver_key', self.naverLE.text())
            self.qst.setValue('urban_data_provider/naver_secret', self.naverLE_2.text())
            self.qst.setValue('urban_data_provider/kakao_key', self.kakaoLE.text())
            if_ready = u'설정 완료! 확인버튼을 눌러주세요.'
            self.ok_button.setEnabled(True)
        self.label.setText(if_ready)

    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()