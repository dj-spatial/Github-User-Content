# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Population Dialog
                                 A QGIS plugin
 .
                             -------------------
        begin                : 2017-02-06
        git sha              : $Format:%H$
        copyright            : (C) 2017 by D.J Paek
        email                : dj.paek2@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os.path
from PyQt5 import uic
from datetime import datetime, timedelta
from PyQt5.QtWidgets import QCheckBox, QSizePolicy, QGridLayout, QVBoxLayout
from qgis.PyQt.QtWidgets import QDialog, QDialogButtonBox
from qgis.gui import QgsMessageBar
from qgis.core import (
    Qgis,
    QgsSettings
)
from ...utils.sgis_utils import available_years, get_access_token

FORM_CLASS_SETTING, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'census_setting.ui'))


class CensusSetting(QDialog, FORM_CLASS_SETTING):
    def __init__(self, parent=None):
        super(CensusSetting, self).__init__(parent)
        self.setupUi(self)
        self.bar = QgsMessageBar()
        self.bar.setSizePolicy( QSizePolicy.Minimum, QSizePolicy.Fixed)
        self.setLayout(QGridLayout())
        self.layout().setContentsMargins(10, 10, 5, 5)
        self.layout().addWidget(self.groupBox, 0, 0, 2, 1)
        self.layout().addWidget(self.bar, 0, 0, 1, 1)
        self.show()


        # Constructor
        self.ok_button = self.dialog_BB.button(QDialogButtonBox.Ok)
        self.ok_button.setEnabled(False)
        self.qst = QgsSettings()
        self.consumer_key = self.qst.value('urban_data_provider/consumerKey')
        self.consumer_secret = self.qst.value('urban_data_provider/consumerSecret')
        if self.consumer_key:
            self.consumerKeyLE.setText(self.consumer_key)
        else:
            self.consumer_key = ''
        if self.consumer_secret:
            self.consumerSecretLE.setText(self.consumer_secret)
        else:
            self.consumer_secret = ''
        self.change_check_status(self.consumer_key, self.consumerKeyCkB)
        self.change_check_status(self.consumer_secret, self.consumerSecretCkB)

        # access token, access timeout
        self.access_token = self.qst.value('urban_data_provider/accessToken')
        self.access_timeout = self.qst.value('urban_data_provider/accessTimeout', '2017-02-07 12:00')
        self.access_timeout_parse = datetime.strptime(self.access_timeout, '%Y-%m-%d %H:%M')
        self.check_token()

        # 행정경계 기준연도
        self.boundary_year = self.qst.value('urban_data_provider/boundaryYear', '2021')
        self.recent_boundary = self.qst.value('urban_data_provider/recentCheck_b')
        if self.boundary_year == str(datetime.now().year):
            boundary_text = u'기준연도: ' + self.boundary_year + u'년(최신 업데이트 완료)'
        else:
            if self.recent_boundary:
                boundary_text = u'기준연도: ' + self.boundary_year + u'년(' + self.recent_boundary + u' 업데이트)'
            else:
                boundary_text = ''
        self.boundaryLE.setText(boundary_text)
        self.change_check_status(boundary_text, self.boundaryCkB)

        # 데이터 기준연도
        self.init_years = self.qst.value('urban_data_provider/initYears', ['2018', '2018', '2018'])  # [인구, 사업체, 농림]
        self.recent_years = self.qst.value('urban_data_provider/recentCheck_y')
        if self.recent_years:
            self.recent_suffix = '(' + str(self.recent_years) + u' 업데이트)'
            year_text = u'최신연도: ' + self.init_years[0] + u'년' + self.recent_suffix
        else:
            self.recent_suffix = '(2018-01-01 업데이트)'
            year_text = ''
        self.yearLE.setText(year_text)
        self.change_check_status(year_text, self.yearCkB)

        # Connect signals
        self.btnYear.clicked.connect(self.update_years)
        self.btnBoundary.clicked.connect(self.update_boundary)
        self.btnToken.clicked.connect(self.get_token)
        self.consumerKeyLE.textEdited.connect(lambda: self.change_check_status(self.consumerKeyLE.text(), self.consumerKeyCkB))
        self.consumerSecretLE.textEdited.connect(lambda: self.change_check_status(self.consumerSecretLE.text(), self.consumerSecretCkB))
        self.status_check()

    # end of __init__

    def change_check_status(self, txt, ckb):
        if txt == '':
            ckb.setChecked(False)
        else:
            ckb.setChecked(True)
            if self.accessTokenCkB.isChecked():
                self.status_check()

    def check_token(self):
        if not self.access_token or self.access_timeout_parse <= datetime.now():
            expire_text = ''
        else:
            expire_text = u'인증키-유효: ' + self.access_timeout + u'까지'
        self.accessTokenLE.setText(expire_text)
        self.change_check_status(expire_text, self.accessTokenCkB)

    def get_token(self):
        consumer_key = self.consumerKeyLE.text()
        consumer_secret = self.consumerSecretLE.text()
        if not consumer_key:
            self.errMsg = u'서비스 ID(Consumer Key)를 입력해주세요.'
            self.bar.pushMessage("Warning:", self.errMsg, level=Qgis.Warning, duration=2)
            return
        if not consumer_secret:
            self.errMsg = u'보안 Key(Consumer Secret)를 입력해주세요.'
            self.bar.pushMessage("Warning:", self.errMsg, level=Qgis.Warning, duration=2)
            return
        try:
            access_response = get_access_token(consumer_key, consumer_secret)
        except Exception:
            expire_text = ''
            self.errMsg = u'인증키 발급이 정상적으로 처리되지 않았습니다.'
            self.bar.pushMessage("Warning:", self.errMsg, level=Qgis.Warning, duration=2)
            self.change_check_status(expire_text, self.accessTokenCkB)
            return
        else:
            self.errMsg = access_response[2]
            if self.errMsg == 'Success':
                current_time = datetime.now()
                self.access_token = access_response[0]
                self.access_timeout = datetime.fromtimestamp(access_response[1]).strftime('%Y-%m-%d %H:%M')
                self.bar.pushMessage("Information:", u'인증키가 발급되었습니다!', level=Qgis.Info, duration=2)
                expire_text = u'인증키-유효: ' + self.access_timeout + u'까지'
                self.accessTokenLE.setText(expire_text)
                self.qst.setValue('urban_data_provider/consumerKey', consumer_key)
                self.qst.setValue('urban_data_provider/consumerSecret', consumer_secret)
                self.qst.setValue('urban_data_provider/accessToken', self.access_token)
                self.qst.setValue('urban_data_provider/accessTimeout', self.access_timeout)
            else:
                self.bar.pushMessage("Warning:", self.errMsg, level=Qgis.Warning, duration=2)
                expire_text = ''
            self.change_check_status(expire_text, self.accessTokenCkB)

    def update_boundary(self):
        boundary_text = ''
        if not self.accessTokenCkB.isChecked():
            self.bar.pushMessage("Warning:", u'유효한 인증키가 없습니다.', level=Qgis.Warning, duration=2)
            self.change_check_status(boundary_text, self.boundaryCkB)
            return
        if self.boundary_year == str(datetime.now().year):
            boundary_text = u'현재 최신 데이터입니다.'
            self.bar.pushMessage("Information:", boundary_text, level=Qgis.Info, duration=2)
        else:
            try:
                self.boundary_year = str(available_years(self.access_token, 3))
            except Exception:
                self.bar.pushMessage("Warning:", u'경계 업데이트가 정상적으로 실행되지 않았습니다.', level=Qgis.Warning,
                                                    duration=2)
                self.change_check_status(boundary_text, self.boundaryCkB)
            else:
                self.qst.setValue('urban_data_provider/boundaryYear', self.boundary_year)
                self.qst.setValue('urban_data_provider/recentCheck_b', datetime.now().strftime('%Y-%m-%d'))
                boundary_text = u'기준연도: ' + self.boundary_year + u'년(최신 업데이트 완료)'
                self.change_check_status(boundary_text, self.boundaryCkB)
                self.boundaryLE.setText(boundary_text)
                self.bar.pushMessage("Information:", u'최신 데이터로 업데이트하였습니다.', level=Qgis.Info,
                                                    duration=2)

    def update_years(self):
        if not self.accessTokenCkB.isChecked():
            self.bar.pushMessage("Warning:", u'유효한 인증키가 없습니다.', level=Qgis.Warning, duration=2)
            return
        for i in range(3):
            self.init_years[i] = str(available_years(self.access_token, i))
        self.recent_suffix = u'년(최신 업데이트 완료)'
        year_text = u'기준연도: ' + self.init_years[0] + self.recent_suffix
        self.yearLE.setText(year_text)
        self.qst.setValue('urban_data_provider/initYears', self.init_years)
        self.qst.setValue('urban_data_provider/recentCheck_y', datetime.now().strftime('%Y-%m-%d'))
        self.bar.pushMessage("Information:", u'최신 데이터로 업데이트 되었습니다!', level=Qgis.Info, duration=2)
        self.change_check_status(year_text, self.yearCkB)

    def status_check(self):
        ready_list = [checkbox.isChecked() for checkbox in self.groupBox.findChildren(QCheckBox)]
        if False in ready_list:
            if_ready = ''
        else:
            if_ready = u'설정 완료! 확인버튼을 눌러주세요.'
            self.ok_button.setEnabled(True)
        self.label.setText(if_ready)
