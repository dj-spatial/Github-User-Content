# -*- coding: utf-8 -*-
"""
/***************************************************************************
 CensusPanel
                                 A QGIS plugin
 .
                             -------------------
        begin                : 2017-02-06
        git sha              : $Format:%H$
        copyright            : (C) 2017 by D.J Paek
        email                : 1002jeen@daum.net
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
import os.path
import sqlite3
import pandas
from PyQt5 import uic
from PyQt5.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QTreeWidgetItem,
    QComboBox,
    QSpinBox,
    QGridLayout,
    QVBoxLayout,
    QWidget,
    QFrame,
    QTabWidget,
    QCheckBox,
    QButtonGroup
 )
from qgis.core import QgsMessageLog
from ...utils.sgis_utils import get_industry, get_base_years

FORM_CLASS_POPULATION, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './sub_panel/population_panel.ui'))

FORM_CLASS_HOUSEHOLD, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './sub_panel/household_panel.ui'))

FORM_CLASS_HOUSE, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './sub_panel/house_panel.ui'))

FORM_CLASS_COMPANY, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './sub_panel/company_panel.ui'))

FORM_CLASS_INDUSTRY, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './sub_panel/industry_panel.ui'))

FORM_CLASS_FISHERY, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './sub_panel/fisheryhousehold_panel.ui'))

FORM_CLASS_HOUSEHOLD_MEMBER, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './sub_panel/householdmember_panel.ui'))


class CensusPanel:
    def __init__(self, census_id, init_year=None, parent=None):
        """Constructor."""
        self.parent = parent
        self.init_year = int(init_year)
        self.init_years = get_base_years(census_id, init_year)
        self.base_years = self.init_years
        self.type_search = ['']
        self.type_search_val = ['00']
        self.type_search_name = [u'전체']
        self.sub_search = ''
        self.sub_search_val = ['']
        self.sub_search_name = ['']


class PopulationPanel(QDialog, FORM_CLASS_POPULATION):

    def __init__(self, census_id, parent=None, init_year=None):
        """Constructor."""
        super(PopulationPanel, self).__init__(parent)
        self.init_year = int(init_year)
        self.setupUi(self)
        self.show()
        ok_button = self.dialog_BB.button(QDialogButtonBox.Ok)
        ok_button.clicked.connect(self.get_search)
        self.tabWidget.currentChanged.connect(self.refresh_tab)
        self.tab1_CkB_0.clicked.connect(self.check_change)
        self.tab2_CkB_0.clicked.connect(self.check_change)
        self.tab3_CkB_0.clicked.connect(self.check_change)
        self.tab4_CkB_0.clicked.connect(self.check_change)
        self.eduGB.clicked.connect(self.edu_clicked)
        self.marriageGB.clicked.connect(self.marriage_clicked)

        # 기본 파라미터
        self.init_years = get_base_years(census_id, init_year)
        self.base_years = self.init_years
        self.target_text = ''
        self.type_search = ["mrg_state", "edu_level", "gender"]
        self.type_search_val = ['00']
        self.type_search_name = []
        self.sub_search = "age_type"
        self.sub_search_val = ['']
        self.sub_search_name = ['']
        self.type_search_val_list = [[1, 2, 3, 4, 5], [0, 1, 2, 3, 4, 5, 6, 7, 8], [0, 1, 2]]
    # end of __init__

    def refresh_tab(self):
        for checkbox in self.tabWidget.findChildren(QCheckBox):
            checkbox.setChecked(False)

    def get_search(self):
        # get type search
        self.type_search_val = []
        i = 0
        for cb in self.findChildren(QComboBox):
            if not cb.isEnabled():
                self.type_search_val.append('00')
                self.type_search_name.append(u'전체')
            else:
                self.type_search_val.append(self.type_search_val_list[i][cb.currentIndex()])
                self.type_search_name.append(cb.currentText())
            i = i + 1

        # target text
        self.target_text = u' (성별)' + self.type_search_name[2]
        if self.eduGB.isChecked():
            self.target_text = self.target_text + u' (학력)' + self.type_search_name[1]
        if self.marriageGB.isChecked():
            self.target_text = self.target_text + u' (혼인)' + self.type_search_name[0]

        # get sub search
        self.sub_search_val = []
        self.sub_search_name = []
        if self.subSearchGroup.isChecked():
            for checkbox in self.subGroup.buttons():
                if checkbox.isChecked():
                    self.sub_search_val.append(checkbox.property('subSearch'))
                    self.sub_search_name.append(checkbox.text())
        if not self.sub_search_val:
            self.sub_search_val = ['']
            self.sub_search_name = [u'전체']

    def check_change(self):
        if self.tabWidget.currentWidget().findChildren(QCheckBox)[0].isChecked():
            for checkbox in self.tabWidget.currentWidget().findChildren(QCheckBox):
                checkbox.setChecked(True)
        else:
            for checkbox in self.tabWidget.currentWidget().findChildren(QCheckBox):
                checkbox.setChecked(False)

    def edu_clicked(self):
        if self.eduGB.isChecked() or self.marriageGB.isChecked():
            self.base_years = ['2010', '2005', '2000']
        else:
            self.base_years = self.init_years

    def marriage_clicked(self):
        if self.eduGB.isChecked() or self.marriageGB.isChecked():
            self.base_years = ['2010', '2005', '2000']
        else:
            self.base_years = self.init_years


class HouseHoldPanel(QDialog, FORM_CLASS_HOUSEHOLD):
    def __init__(self, census_id, parent=None, init_year=None):
        """Constructor."""
        super(HouseHoldPanel, self).__init__(parent)
        self.init_year = int(init_year)

        self.setupUi(self)
        self.show()
        ok_button = self.dialog_BB.button(QDialogButtonBox.Ok)
        ok_button.clicked.connect(self.get_search)

        self.typeBG.buttonClicked.connect(self.change_type)
        self.CkB_0.toggled.connect(self.check_change)
        self.tenantChoiceGB.clicked.connect(self.tenant_choice)

        # 기본 파라미터
        self.init_years = get_base_years(census_id, init_year)
        self.base_years = self.init_years
        self.target_text = ''
        self.type_search = ["ocptn_type"]
        self.type_search_val =  ['00']
        self.sub_search = "household_type"
        self.sub_search_val = ['']
        self.sub_search_name = ['']
        self.type_nm = 'all'
        self.type_nm_kor = u'전체가구'
        self.type_search_val_list = [[1, 2, 3, 4, 5, 6]]
    # end of __init__

    def change_type(self):
        self.type_nm = self.typeBG.checkedButton().objectName()
        if self.type_nm == 'all':
            self.type_nm_kor = u'전체'
            self.CkB_0.setEnabled(False)
            for checkbox in self.subGroup.buttons():
                checkbox.setEnabled(False)
        else:
            self.type_nm_kor = u'유형별'
            self.CkB_0.setEnabled(True)
            for checkbox in self.subGroup.buttons():
                checkbox.setEnabled(True)

    def get_search(self):
        # get type search
        self.type_search_val = []
        self.type_search_name = []
        i = 0
        for cb in self.findChildren(QComboBox):
            if cb.isEnabled() == False:
                self.type_search_val.append('00')
                self.type_search_name.append(u'전체')
            else:
                self.type_search_val.append(self.type_search_val_list[i][cb.currentIndex()])
                self.type_search_name.append(cb.currentText())
            i = i + 1
        # get sub search
        self.sub_search_val = []
        self.sub_search_name = []
        if self.type_nm == 'cat':
            for checkbox in self.subGroup.buttons():
                if checkbox.isChecked():
                    self.sub_search_val.append(checkbox.property('subSearch'))
                    self.sub_search_name.append(checkbox.text())
        if not self.sub_search_val:
            self.type_nm = 'all'
            self.type_nm_kor = u'전체'
            self.sub_search_val = ['']
            self.sub_search_name = [u'전체가구']

        # target text
        self.target_text = u' (가구분류)' + self.type_nm_kor
        if self.tenantChoiceGB.isChecked():
            self.target_text = self.target_text + u' (점유형태)' + self.type_search_name[0]

    def check_change(self):
        if self.CkB_0.isChecked():
            for checkbox in self.subGroup.buttons():
                checkbox.setChecked(True)
        else:
            for checkbox in self.subGroup.buttons():
                checkbox.setChecked(False)

    def tenant_choice(self):
        if self.tenantChoiceGB.isChecked():
            self.base_years = ['2010', '2005', '2000']
        else:
            self.base_years = self.init_years


class HousePanel(QDialog, FORM_CLASS_HOUSE):
    def __init__(self, census_id, parent=None, init_year=None):
        """Constructor."""
        super(HousePanel, self).__init__(parent)
        self.init_year = int(init_year)
        self.setupUi(self)
        self.show()
        ok_button = self.dialog_BB.button(QDialogButtonBox.Ok)
        ok_button.clicked.connect(self.get_search)
        self.CkB_0.toggled.connect(self.check_change)

        # 건축연도 업데이트
        self.const_year = [[u'2018년', u'2017년', u'2016년', u'2015년', u'2014년', u'2013년', u'2012년', u'2011년', u'2010년', u'2009년~2005년', u'2004년~2000년', u'1999년~1990년', u'1989년~1980년', u'1979년 이전', u'미상'],
                           [u'2017년', u'2016년', u'2015년', u'2014년', u'2013년', u'2012년', u'2011년', u'2010년', u'2009년~2005년', u'2004년~2000년', u'1999년~1990년', u'1989년~1980년', u'1979년 이전', u'미상'],
                           [u'2016년', u'2015년', u'2014년', u'2013년', u'2012년', u'2011년', u'2010년', u'2009년~2005년', u'2004년~2000년', u'1999년~1990년', u'1989년~1980년', u'1979년 이전', u'미상'],
                           [u'2015년', u'2014년', u'2013년', u'2012년', u'2011년', u'2010년', u'2009년~2005년', u'2004년~2000년', u'1999년~1990년', u'1989년~1980년', u'1979년 이전', u'미상'],
                           [u'2010년', u'2009년', u'2008년', u'2007년', u'2006년', u'2005년', u'2004년~2000년', u'1999년~1995년', u'1994년~1990년', u'1989년~1980년', u'1979년~1970년', u'1969년~1960년', u'1959년 이전', u'미상']
                           ]
        new_const_year = [y + u'년' for y in list(map(str, list(range(self.init_year, 2018, -1))))]
        for ny in reversed(new_const_year):
            new_list_item = [ny] + self.const_year[0]
            self.const_year.insert(0, new_list_item)

        # 기본 파라미터
        self.init_years = get_base_years(census_id, init_year)
        self.base_years = self.init_years
        self.target_text = ''
        self.type_search = ["house_type"]
        self.type_search_val = ['00']
        self.sub_search = "house_area_cd"
        self.sub_search_val = ['']
        self.sub_search_name = ['']
        self.house_type_cd = ['00', '01', '02', '03', '04', '05', '06']

        # 건축연도 코드 업데이트
        self.const_year_cd = [
            ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '99'],
            ['01', '02', '03', '04', '05', '06', '07', '08', '10', '11', '12', '13', '14', '99'],
            ['01', '02', '03', '04', '05', '06', '07', '10', '11', '12', '13', '14', '99'],
            ['01', '02', '03', '04', '05', '06', '10', '11', '12', '13', '14', '99'],
            ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '99']
        ]
        new_const_cd = [y[2:] for y in list(map(str, list(range(self.init_year, 2018, -1))))]
        for nc in reversed(new_const_cd):
            new_list_item = [nc] + self.const_year_cd[0]
            self.const_year_cd.insert(0, new_list_item)

        self.use_year_cd = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12']
    # end of __init__

    def get_search(self):
        # get type search
        self.type_search_val = []
        self.type_search_name = []
        self.type_search_val.append(self.house_type_cd[self.type_CB.currentIndex()])
        self.type_search_name.append(self.type_CB.currentText())

        #get sub search
        self.sub_search_val = []
        self.sub_search_name = []
        if self.subSearchGroup.isChecked():
            for checkbox in self.subGroup.buttons():
                if checkbox.isChecked():
                    self.sub_search_val.append(checkbox.property('subSearch'))
                    self.sub_search_name.append(checkbox.text())
        if not self.sub_search_val:
            self.sub_search_val = ['']
            self.sub_search_name = [u'면적구분_전체']

        # target text
        self.target_text = u' (주택유형)' + self.type_search_name[0]

    def check_change(self):
        if self.CkB_0.isChecked():
            for checkbox in self.subGroup.buttons():
                checkbox.setChecked(True)
        else:
            for checkbox in self.subGroup.buttons():
                checkbox.setChecked(False)


class CompanyPanel(QDialog, FORM_CLASS_COMPANY):

    def __init__(self, census_id, parent=None, init_year=None):
        """Constructor."""
        super(CompanyPanel, self).__init__(parent)
        self.init_year = int(init_year)

        # Get Biz
        # f_dir = 'C:/Temp/census_field.sqlite'
        f_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'sgis/census_field.sqlite')
        conn = sqlite3.connect(f_dir)
        sql = "select eng, gr_id, kor, gr from census_field where oid = 'corpdistsummary'"
        df = pandas.read_sql_query(sql, conn)
        conn.close()
        biz_group = {'C': u'소매업', 'D': u'생활서비스', 'E': u'교통', 'F': u'여가생활', 'G': u'숙박',
                     'H': u'음식', 'I': u'교육', 'J': u'의료', 'K': u'공공', 'A': u'농림어업', 'B': u'기업', '99': u'기타'}

        # Create a Tab Widget
        self.tab_widget = QTabWidget()
        self.tab_widget.setEnabled(False)
        self.sub_group = QButtonGroup()
        self.sub_group.setExclusive(False)
        for k, v in biz_group.items():
            ''' Tab Contents '''
            tab = QWidget()
            tab.setObjectName(k)
            self.tab_widget.addTab(tab, v)
            tab_layout = QVBoxLayout()

            # Add Check All
            self.check_all = QCheckBox(u'모두선택')
            self.check_all.setObjectName('checkall_' + k)
            self.check_all.clicked.connect(self.check_change)
            tab_layout.addWidget(self.check_all)

            # Add H Line
            line = QFrame()
            line.setFrameShape(QFrame.HLine)
            line.setFrameShadow(QFrame.Sunken)
            tab_layout.addWidget(line)

            # Add Sub Check Boxes
            checks_layout = QGridLayout()
            checks_layout.setSpacing(10)

            biz = df[df["gr_id"] == k]
            for i, (kor, eng) in enumerate(zip(biz['kor'], biz['eng'])):
                row = i // 6
                col = i % 6
                chk = QCheckBox(kor)
                chk.setProperty('subSearch', eng)
                self.sub_group.addButton(chk, i)
                checks_layout.addWidget(chk, row, col)
            tab_layout.addLayout(checks_layout)
            tab_layout.addStretch(1)
            tab.setLayout(tab_layout)
        # layout.setSpacing(0)
        # self.setLayout(layout)

        self.setupUi(self)
        self.layout.addWidget(self.tab_widget)
        ok_button = self.dialog_BB.button(QDialogButtonBox.Ok)
        ok_button.clicked.connect(self.get_search)
        self.tab_widget.currentChanged.connect(self.refresh_tab)
        self.typeBG.buttonClicked.connect(self.change_type)

        # 기본 파라미터
        self.base_years = get_base_years(census_id, init_year)
        self.target_text = ''
        self.type_search = ['']
        self.type_search_val = ['00']
        self.sub_search = "theme_cd"
        self.sub_search_val = ['']
        self.sub_search_name = ['']
        self.type_nm = 'all'
        self.type_nm_kor = u'전체사업체'
        self.type_search_name = [u'전체']
    # end of __init__

    def refresh_tab(self):
        for checkbox in self.tab_widget.findChildren(QCheckBox):
            checkbox.setChecked(False)

    def change_type(self):
        self.type_nm = self.typeBG.checkedButton().objectName()
        if self.type_nm == 'all':
            self.type_nm_kor = u'전체사업체'
            self.tab_widget.setEnabled(False)
            for checkbox in self.sub_group.buttons():
                checkbox.setEnabled(False)
        else:
            self.type_nm_kor = u'사업체유형별'
            self.tab_widget.setEnabled(True)
            for checkbox in self.sub_group.buttons():
                checkbox.setEnabled(True)

    def get_search(self):
        #get sub search
        self.sub_search_val = []
        self.sub_search_name = []
        if self.type_nm == 'cat':
            for checkbox in self.sub_group.buttons():
                if checkbox.isChecked():
                    self.sub_search_val.append(checkbox.property('subSearch'))
                    self.sub_search_name.append(checkbox.text())
        if not self.sub_search_val:
            self.type_nm = 'all'
            self.type_nm_kor = u'전체사업체'
            self.sub_search_val = ['']
            self.sub_search_name = [u'전체']
        self.target_text = u' (검색대상)' + self.type_nm_kor

    def check_change(self):
        if self.tab_widget.currentWidget().findChildren(QCheckBox)[0].isChecked():
            for checkbox in self.tab_widget.currentWidget().findChildren(QCheckBox):
                checkbox.setChecked(True)
        else:
            for checkbox in self.tab_widget.currentWidget().findChildren(QCheckBox):
                checkbox.setChecked(False)


class IndustryPanel(QDialog, FORM_CLASS_INDUSTRY):

    def __init__(self, census_id, parent=None, init_year=None, access_token=None):
        """Constructor."""
        super(IndustryPanel, self).__init__(parent)
        self.init_year = int(init_year)
        self.access_token = access_token
        self.setupUi(self)
        self.show()
        self.ok_button = self.dialog_BB.button(QDialogButtonBox.Ok)
        self.type_CB.currentIndexChanged.connect(self.refresh_tree)
        self.treeWidget.itemSelectionChanged.connect(self.update_tree)
        self.ok_button.clicked.connect(self.get_search)
        self.ok_button.setEnabled(False)

        # 기본 파라미터
        self.init_years = get_base_years(census_id, init_year)
        self.target_text = ''
        self.type_search = ['']
        self.type_search_val =  ['00']
        self.sub_search = "class_code"
        self.sub_search_val = ['']
        self.sub_search_name = ['']
        self.type_search_name = [self.type_CB.currentText().split('(')[0]]
        self.search_order_list = ['10', '9', '8']
        self.search_order = self.search_order_list[0]
        self.refresh_tree()
    # end of __init__

    def refresh_tree(self):
        self.treeWidget.clear()
        self.type_idx = self.type_CB.currentIndex()
        self.type_search_name = self.type_CB.currentText().split('(')[0]
        self.search_order = self.search_order_list[self.type_idx]

        industry_codes = get_industry(self.access_token, self.search_order, '')
        children_list = []
        for i, c in enumerate(industry_codes):
            child_item = QTreeWidgetItem()
            child_item.setText(0, c['class_code'] + '.' + c['class_nm'])
            children_list.append(child_item)
        self.treeWidget.addTopLevelItems(children_list)

        if self.type_idx == 0:
            self.base_years = self.init_years[:self.init_years.index('2016')]
        elif self.type_idx == 1:
            self.base_years = ['2016', '2015', '2014', '2013', '2012', '2011', '2010', '2009', '2008', '2007', '2006']
        else:
            self.base_years = ['2005', '2004', '2003', '2002', '2001', '2000']

    def get_search(self):
        # get sub search
        self.sub_search_val = []
        self.sub_search_name = []
        current_code_full_name = self.treeWidget.currentItem().text(0)
        current_code = current_code_full_name.split('.')[0]
        current_name = current_code_full_name.split('.')[1]
        self.sub_search_val.append(current_code)
        self.sub_search_name.append(current_name)
        QgsMessageLog.logMessage(str(self.type_search_name))
        self.target_text = u' (기준차수)' + self.type_search_name

    def update_tree(self):
        current = self.treeWidget.currentItem()
        child_count = current.childCount()
        current_code_full_name = self.treeWidget.currentItem().text(0)
        current_code = current_code_full_name.split('.')[0]
        if child_count is not 0:
            return
        if len(current_code) == 6:
            return
        industry_codes = get_industry(self.access_token, self.search_order, current_code)
        children_list = []
        for i, c in enumerate(industry_codes):
            child_item = QTreeWidgetItem()
            child_item.setText(0, c['class_code'] + '.' + c['class_nm'])
            children_list.append(child_item)
        current.addChildren(children_list)
        current.setExpanded(True)
        self.ok_button.setEnabled(True)

class FarmhouseholdPanel():

    def __init__(self, census_id, parent=None, init_year=None):
        """Constructor."""
        self.parent = parent
        self.init_year = int(init_year)
        self.base_years = get_base_years(census_id, init_year)
        self.target_text = ''
        self.type_search = ['']
        self.type_search_val =  ['00']
        self.sub_search = ''
        self.sub_search_val = ['']
        self.sub_search_name = ['']
        self.type_search_name = [u'전체']


class ForesthouseholdPanel():
    def __init__(self, census_id, parent=None, init_year=None):
        """Constructor."""
        self.parent = parent
        self.init_year = int(init_year)
        self.base_years = get_base_years(census_id, init_year)
        self.target_text = ''
        self.type_search = ['']
        self.type_search_val =  ['00']
        self.sub_search = ''
        self.sub_search_val = ['']
        self.sub_search_name = ['']
        self.type_search_name = [u'전체']


class FisheryhouseholdPanel(QDialog, FORM_CLASS_FISHERY):
    def __init__(self, census_id, parent=None, init_year=None):
        """Constructor."""
        super(FisheryhouseholdPanel, self).__init__(parent)
        self.init_year = int(init_year)

        self.setupUi(self)
        self.show()
        ok_button = self.dialog_BB.button(QDialogButtonBox.Ok)
        ok_button.clicked.connect(self.get_search)

        # 기본 파라미터
        self.base_years = get_base_years(census_id, init_year)
        self.target_text = ''
        self.type_search = ["oga_div"]
        self.type_search_val =  ['00']
        self.sub_search = ''
        self.sub_search_val = ['']
        self.sub_search_name = ['']
        self.type_search_val_list = [[0, 1, 2]]
    # end of __init__

    def get_search(self):
        # get type search
        self.type_search_val = []
        self.type_search_name = []
        i = 0
        for cb in self.findChildren(QComboBox):
            if not cb.isEnabled():
                self.type_search_val.append('00')
                self.type_search_name.append(u'전체')
            else:
                self.type_search_val.append(self.type_search_val_list[i][cb.currentIndex()])
                self.type_search_name.append(cb.currentText())
            i = i + 1
        self.target_text = u' (어가구분)' + self.type_search_name[0]


class HouseholdmemberPanel(QDialog, FORM_CLASS_HOUSEHOLD_MEMBER):
    def __init__(self, census_id, parent=None, init_year=None):
        """Constructor."""
        super(HouseholdmemberPanel, self).__init__(parent)
        self.init_year = int(init_year)
        self.setupUi(self)
        self.show()
        ok_button = self.dialog_BB.button(QDialogButtonBox.Ok)
        ok_button.clicked.connect(self.get_search)

        # 기본 파라미터
        self.base_years = get_base_years(census_id, init_year)
        self.target_text = ''
        self.type_search = ["gender", "data_type", "age_to", "age_from"]
        self.type_search_val =  ['00']
        self.sub_search = ''
        self.sub_search_val = ['']
        self.sub_search_name = ['']
        self.type_search_val_list = [[0, 1, 2], [1, 2, 3, 4], [0], [150]]
        self.spinBoxName = [u'연령(to)', u'연령(from)']
    # end of __init__

    def get_search(self):
        # get type search
        self.type_search_val = []
        self.type_search_name = []
        for i, cb in enumerate(self.findChildren(QComboBox)):
            self.type_search_val.append(self.type_search_val_list[i][cb.currentIndex()])
            self.type_search_name.append(cb.currentText())
        for j, sb in enumerate(self.findChildren(QSpinBox)):
            self.type_search_val.append(sb.value())
            self.type_search_name.append(self.spinBoxName[j])

        # get sub search
        self.target_text = u' (가구유형)' + self.type_search_name[1] + u' (성별)' + self.type_search_name[0] + u' (연령)'\
                           + str(self.type_search_val[3]) + u'세 ~ ' + str(self.type_search_val[2])


class CorpindecreasePanel():

    def __init__(self, census_id, parent=None, init_year=None):
        """Constructor."""
        self.parent = parent
        self.init_year = int(init_year)
        self.init_years = get_base_years(census_id, init_year)
        self.base_years = self.init_years
        self.target_text = ''
        self.type_search = ['']
        self.type_search_val = ['00']
        self.sub_search = ''
        self.sub_search_val = ['']
        self.sub_search_name = ['']
        # self.target_text = ' ' + str(self.base_years[0]) + u'년 대비 ' + str(self.base_years[1]) + u'년 사업체 증감'
    # end of __init__

