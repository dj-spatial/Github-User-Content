# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Population Data Provider
                                 A QGIS plugin
 .
                             -------------------
        begin                : 2017-02-06
        git sha              : $Format:%H$
        copyright            : (C) 2017 by D.J Paek
        email                : dj.paek2@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
import os.path
from PyQt5.QtCore import QCoreApplication
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QAction, QMenu
from qgis.core import QgsSettings, QgsMessageLog

from .forms.auth_setting import AuthSetting
from .geocode.geocode_dialog import GeocodeDialog, GeocodeFileDialog
from .place.geocodePlc_dialog import PlaceVworldDialog, PlaceNaverDialog, PlaceKakaoDialog
from .sgis.census_dialog import CensusDialog
from .seoul.defacto_daily_dialog import DefactoDailyDialog
from .seoul.defacto_span_dialog import DefactoSpanDialog
from .sdata.spatialData_dialog import VworldDialog
from .location.site_widget import SiteDockWidget
from .location.local_area_widget import LocalAreaDockWidget


class UrbanDataProvider:
    def __init__(self, iface):
        self.iface = iface
        self.URD_menu = None
        self.geocode_menu = None
        self.place_menu = None
        self.spatial_menu = None
        self.sgis_menu = None
        self.census_action = None
        self.seoul_menu = None
        self.defacto_daily_action = None
        self.defacto_span_action = None
        self.menuTitle = u"도시공간데이터"
        self.qst = QgsSettings()

    def add_submenu(self, submenu):
        if self.URD_menu is not None:
            self.URD_menu.addMenu(submenu)
        else:
            self.iface.addPluginToMenu(u"&도시공간데이터", submenu.menuAction())

    def initGui(self):
        # CREATING MASTER MENU HEAD
        self.URD_menu = QMenu(
            QCoreApplication.translate(self.menuTitle.encode('utf-8'), self.menuTitle.encode('utf-8')))
        self.iface.mainWindow().menuBar().insertMenu(self.iface.firstRightStandardMenu().menuAction(),
                                                     self.URD_menu)

        # 인증키
        icon = QIcon(os.path.dirname(__file__) + "/icons/key.png")
        self.auth_action = QAction(icon, u"인증키", self.iface.mainWindow())
        self.auth_action.triggered.connect(self.run_auth)
        self.URD_menu.addAction(self.auth_action)
        self.URD_menu.addSeparator()

        # ########################################################################
        # #################  GeoCoding SUB-MENU  #######################
        icon = QIcon(os.path.dirname(__file__) + "/icons/geocoder.png")
        self.geocode_menu = QMenu(QCoreApplication.translate(u"URA", "&Geocoding"))
        self.geocode_menu.setIcon(icon)
        self.add_submenu(self.geocode_menu)

        # GeoCode from Input
        icon = QIcon(os.path.dirname(__file__) + "/icons/geocoder_input.png")
        self.geocode_action = QAction(icon, u"주소를 입력하여 개별검색(인증키 없음)", self.iface.mainWindow())
        self.geocode_action.triggered.connect(self.run_geocode)
        self.geocode_menu.addAction(self.geocode_action)

        # GeoCode from file
        icon = QIcon(os.path.dirname(__file__) + "/icons/geocoder_file.png")
        self.geocode_file_action = QAction(icon, u"파일로부터 일괄검색(인증키 없음)", self.iface.mainWindow())
        self.geocode_file_action.triggered.connect(self.run_geocode_file)
        self.geocode_menu.addAction(self.geocode_file_action)

        # ########################################################################
        # #################  Place SUB-MENU  #######################
        icon = QIcon(os.path.dirname(__file__) + "/icons/place.png")
        self.place_menu = QMenu(QCoreApplication.translate(u"URA", u"&장소 검색"))
        self.place_menu.setIcon(icon)
        self.add_submenu(self.place_menu)

        # 브이월드
        icon = QIcon(os.path.dirname(__file__) + "/icons/vworld.png")
        self.place_vworld_action = QAction(icon, u"브이월드(인증키 없음)", self.iface.mainWindow())
        self.place_vworld_action.triggered.connect(self.run_place_vworld)
        self.place_menu.addAction(self.place_vworld_action)

        # 네이버
        icon = QIcon(os.path.dirname(__file__) + "/icons/naver.png")
        self.place_naver_action = QAction(icon, u"네이버(인증키 없음)", self.iface.mainWindow())
        self.place_naver_action.triggered.connect(self.run_place_naver)
        self.place_menu.addAction(self.place_naver_action)

        # 카카오
        icon = QIcon(os.path.dirname(__file__) + "/icons/kakao.png")
        self.place_kakao_action = QAction(icon, u"카카오(인증키 없음)", self.iface.mainWindow())
        self.place_kakao_action.triggered.connect(self.run_place_kakao)
        self.place_menu.addAction(self.place_kakao_action)

        # ########################################################################
        # #################  SGIS SUB-MENU  #######################
        icon = QIcon(os.path.dirname(__file__) + "/icons/census.png")
        self.sgis_menu = QMenu(QCoreApplication.translate(u"URA", u"&통계지리정보"))
        self.sgis_menu.setIcon(icon)
        self.add_submenu(self.sgis_menu)

        # 인구주택총조사
        icon = QIcon(os.path.dirname(__file__) + "/icons/household.png")
        self.census_action = QAction(icon, u"인구주택총조사", self.iface.mainWindow())
        self.census_action.triggered.connect(self.run_census)
        self.sgis_menu.addAction(self.census_action)

        # ########################################################################
        # #################  Seoul Data SUB-MENU  #######################
        icon = QIcon(os.path.dirname(__file__) + "/icons/seoul.png")
        self.seoul_menu = QMenu(QCoreApplication.translate(u"URA", u"서울열린데이터"))
        self.seoul_menu.setIcon(icon)
        self.add_submenu(self.seoul_menu)

        # 생활인구(일간단위)
        icon = QIcon(os.path.dirname(__file__) + "/icons/defacto.png")
        self.defacto_daily_action = QAction(icon, u"일간 생활인구", self.iface.mainWindow())
        self.defacto_daily_action.triggered.connect(self.run_defacto_daily)
        self.seoul_menu.addAction(self.defacto_daily_action)

        # 생활인구(기간단위)
        icon = QIcon(os.path.dirname(__file__) + "/icons/defacto.png")
        self.defacto_span_action = QAction(icon, u"기간 생활인구", self.iface.mainWindow())
        self.defacto_span_action.triggered.connect(self.run_defacto_span)
        self.seoul_menu.addAction(self.defacto_span_action)

        # ########################################################################
        # #################  Spatial Data SUB-MENU  #######################
        icon = QIcon(os.path.dirname(__file__) + "/icons/info.png")
        self.spatial_menu = QMenu(QCoreApplication.translate(u"URA", u"기타공공데이터"))
        self.spatial_menu.setIcon(icon)
        self.add_submenu(self.spatial_menu)

        # 브이월드
        icon = QIcon(os.path.dirname(__file__) + "/icons/vworld.png")
        self.vworld_action = QAction(icon, u"브이월드", self.iface.mainWindow())
        self.vworld_action.triggered.connect(self.run_vworld)
        self.spatial_menu.addAction(self.vworld_action)

        self.URD_menu.addSeparator()

        # ########################################################################
        # #################  입지분석  #######################
        icon = QIcon(os.path.dirname(__file__) + "/icons/location.png")
        self.location_menu = QMenu(QCoreApplication.translate(u"URA", u"&입지분석"))
        self.location_menu.setIcon(icon)
        self.add_submenu(self.location_menu)

        # 부지분석
        icon = QIcon(os.path.dirname(__file__) + "/icons/site.png")
        self.site_analysis_action = QAction(icon, u"토지분석(인증키 없음)", self.iface.mainWindow())
        self.site_analysis_action.triggered.connect(self.run_siteAnalysis)
        self.location_menu.addAction(self.site_analysis_action)

        # 지역분석(토지)
        icon = QIcon(os.path.dirname(__file__) + "/icons/local.png")
        self.local_area_analysis_action = QAction(icon, u"지역분석(토지)", self.iface.mainWindow())
        self.local_area_analysis_action.triggered.connect(self.run_localArea)
        self.location_menu.addAction(self.local_area_analysis_action)

        # 인증키 확인
        self.auth_check()

    def unload(self):
        self.URD_menu.deleteLater()
        self.URD_menu = None
        self.sgis_menu.deleteLater()
        self.sgis_menu = None
        self.census_action.deleteLater()
        self.census_action = None
        self.seoul_menu.deleteLater()
        self.seoul_menu = None
        self.defacto_daily_action.deleteLater()
        self.defacto_daily_action = None

    def auth_check(self):
        self.geocode_action.setEnabled(False)
        self.geocode_file_action.setEnabled(False)
        self.place_vworld_action.setEnabled(False)
        self.place_naver_action.setEnabled(False)
        self.place_kakao_action.setEnabled(False)
        self.site_analysis_action.setEnabled(False)
        vworld_key = self.qst.value('urban_data_provider/vworld_key')
        road_key = self.qst.value('urban_data_provider/road_key')
        naver_key = self.qst.value('urban_data_provider/naver_key')
        naver_secret = self.qst.value('urban_data_provider/naver_secret')
        kakao_key = self.qst.value('urban_data_provider/kakao_key')

        if_ready = [False, False, False, False, False]
        if vworld_key:
            if_ready[0] = True  # vworld
        if road_key:
            if_ready[1] = True  # road
        if naver_key:
            if_ready[2] = True  # naver_key
        if naver_secret:
            if_ready[3] = True  # naver_secret
        if kakao_key:
            if_ready[4] = True  # kakao
        if False in if_ready:
            self.geocode_action.setEnabled(False)
            self.geocode_file_action.setEnabled(False)
        else:
            self.geocode_action.setEnabled(True)
            self.geocode_action.setText(u"주소를 입력하여 개별검색")
            self.geocode_file_action.setEnabled(True)
            self.geocode_file_action.setText(u"파일로부터 일괄검색")
        if if_ready[0]: 
            self.place_vworld_action.setEnabled(True)
            self.place_vworld_action.setText(u"브이월드")
            self.site_analysis_action.setEnabled(True)
            self.site_analysis_action.setText(u"토지분석")
        if if_ready[2] & if_ready[3]: 
            self.place_naver_action.setEnabled(True)
            self.place_naver_action.setText(u"네이버")
        if if_ready[4]: 
            self.place_kakao_action.setEnabled(True)
            self.place_kakao_action.setText(u"카카오")

    def run_auth(self):
        self.dlg = AuthSetting(self.iface)
        if self.dlg.exec_():
            self.auth_check()

    def run_geocode(self):
        self.dlg = GeocodeDialog(self.iface)
        self.dlg.show()

    def run_geocode_file(self):
        self.dlg = GeocodeFileDialog(self.iface)
        self.dlg.show()

    def run_place_vworld(self):
        self.dlg = PlaceVworldDialog(self.iface)
        self.dlg.show()

    def run_place_naver(self):
        self.dlg = PlaceNaverDialog(self.iface)
        self.dlg.show()

    def run_place_kakao(self):
        self.dlg = PlaceKakaoDialog(self.iface)
        self.dlg.show()

    def run_census(self):
        self.census_dlg = CensusDialog(self.iface)
        self.census_dlg.show()

    def run_defacto_daily(self):
        self.defacto_dlg = DefactoDailyDialog(self.iface)
        self.defacto_dlg.show()

    def run_defacto_span(self):
        self.defacto_day_dlg = DefactoSpanDialog(self.iface)
        self.defacto_day_dlg.show()

    def run_vworld(self):
        self.dlg = VworldDialog(self.iface)
        self.dlg.show()

    def run_siteAnalysis(self):
        self.site_widget = SiteDockWidget(self.iface)
        self.site_widget.show()

    def run_localArea(self):
        self.localArea_widget = LocalAreaDockWidget(self.iface)
        self.localArea_widget.show()
