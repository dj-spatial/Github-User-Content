# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Population Data Provider
                                 A QGIS plugin
 .
                             -------------------
        begin                : 2017-02-06
        git sha              : $Format:%H$
        copyright            : (C) 2017 by D.J Paek
        email                : dj.paek2@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""




import json
import os.path
from datetime import datetime, timedelta

from PyQt5 import uic
from PyQt5.QtCore import QCoreApplication
from qgis.PyQt.QtCore import QUrl, Qt
from qgis.PyQt.QtGui import QDesktopServices, QCursor
from qgis.PyQt.QtWidgets import QMenu, QAction, QDockWidget
from qgis.core import (
    Qgis,
    QgsCoordinateReferenceSystem,
    QgsApplication,
    QgsCoordinateTransform,
    QgsVectorLayer,
    QgsProject,
    QgsSettings,
    QgsRectangle,
    QgsGeometry,
    QgsObjectCustomProperties
)

from ..forms.sgis.census_setting import CensusSetting
from .census_procedure import Worker, BizWorker
from ..forms.extent_panel import ExtentPanel
from ..forms.sgis.census_panel import *
from ..utils.sgis_utils import get_access_token, get_admin_stage
from ..utils.sgis_utils import get_census_fields
from ..utils.utils import graduated_symbol, categorized_symbol, single_symbol

FORM_CLASS_CENSUS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), '../forms/sgis/census_dialog.ui'))


class CensusDialog(QDockWidget, FORM_CLASS_CENSUS):
    def __init__(self, iface):
        # Constructor
        QDockWidget.__init__(self)
        self.iface = iface
        self.setupUi(self)
        self.plugin_dir = os.path.dirname(__file__)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self)
        defacto_dock = self.iface.mainWindow().findChild(QDockWidget, 'defactoDock')
        site_dock = self.iface.mainWindow().findChild(QDockWidget, 'siteDock')
        if defacto_dock and defacto_dock.isVisible():
            self.iface.mainWindow().tabifyDockWidget(self, defacto_dock)
        elif site_dock and site_dock.isVisible():
            self.iface.mainWindow().tabifyDockWidget(self, site_dock)
        self.raise_()
        self.ok_button = self.buttonBox.button(QDialogButtonBox.Ok)
        self.cancel_button = self.buttonBox.button(QDialogButtonBox.Cancel)
        self.cancel_button.setEnabled(False)
        self.help_button = self.buttonBox.button(QDialogButtonBox.Help)

        # Navigation Buttons
        self.menuBG.setId(self.mainCensusBtn, 0)
        self.menuBG.setId(self.localSummaryBtn, 1)
        self.menuBG.setId(self.thematicBtn, 2)
        self.menuBG.setId(self.localChangeBtn, 3)

        # Init Setting
        self.consumer_key = None
        self.consumer_secret = None
        self.access_token = None
        self.access_timeout = None
        self.boundary_year = None
        self.init_years = None
        self.token_valid = False
        self.qst = QgsSettings()
        self.init_setting()

        # Attributes
        self.is_admin = True
        self.low_search = '0'
        self.errMsg = 'Success'
        self.worker = None
        self.project = None
        self.field_name_kors = None
        self.field_name_engs = None
        self.census_url = None
        self.sub_search_name = None
        self.sub_search_val = None
        self.sub_search = None
        self.type_search_val = None
        self.type_search = None
        self.base_years = []
        self.search_year = ''
        self.target_text = None
        self.census_id = None
        self.census_name = None
        self.extent_text = ''
        self.search_admin_cd = '0'
        self.search_admin_nm = u'전국'
        self.disabled_idx = [-1]
        self.sido_nm = [u'서울특별시', u'부산광역시', u'대구광역시', u'인천광역시', u'광주광역시', u'대전광역시', u'울산광역시',
                        u'세종특별자치시', u'경기도', u'강원도', u'충청북도', u'충청남도', u'전라북도', u'전라남도', u'경상북도',
                        u'경상남도', u'제주특별자치도']
        self.sido_cd = ['11', '21', '22', '23', '24', '25', '26', '29', '31', '32', '33', '34', '35', '36', '37', '38',
                        '39']
        self.sgg_full = None
        self.sgg_nm = None
        self.sgg_cd = None
        self.emd_full = None
        self.emd_nm = None
        self.emd_cd = None
        self.selected_sgg_cd = None
        self.selected_sido_cd = None
        self.prev_idx = 0
        self.layer_style = 'single'
        self.target_field = None
        self.f_names = None
        self.na_alt = 'N/A'
        self.const_year = []

        # Connect signals
        self.settingTB.clicked.connect(self.census_setting)
        self.ok_button.clicked.connect(self.run_census)
        self.cancel_button.clicked.connect(self.kill_worker)
        self.help_button.clicked.connect(self.give_help)
        self.extentTB.clicked.connect(self.select_extent)
        self.stepCB.currentIndexChanged.connect(self.step_change)
        self.sidoCB.currentIndexChanged.connect(self.sido_change)
        self.sggCB.currentIndexChanged.connect(self.sgg_change)
        self.emdCB.currentIndexChanged.connect(self.emd_change)
        self.menuBG.buttonClicked.connect(self.uncheck_boxes)
        self.targetBG.buttonClicked.connect(self.get_target)
        self.cYearCB.currentIndexChanged.connect(self.change_const_years)
        self.sYearCB.currentIndexChanged.connect(self.change_end_years)
        self.corpindecrease.stateChanged.connect(self.set_unit_list)
        self.constructionChk.clicked.connect(self.refresh_const)
        self.constructionCB.currentIndexChanged.connect(self.change_const)
        self.styleCB.currentIndexChanged.connect(self.set_style)
        self.fieldCB.currentIndexChanged.connect(self.change_style)
        self.popMeasureCB.currentIndexChanged.connect(self.change_style)
        self.rampCB.currentIndexChanged.connect(self.change_style)
        self.invertChk.toggled.connect(self.change_style)
        self.iface.layerTreeView().currentLayerChanged.connect(self.change_active_layer)
        self.naCB.currentIndexChanged.connect(self.activate_na)

        self.set_value_from_admin()
    # end of __init__

    def init_setting(self):
        if_ready = [False, False, False, False, False]
        # consumer key, consumer secret
        self.consumer_key = self.qst.value('urban_data_provider/consumerKey')

        if self.consumer_key:
            if_ready[0] = True
        self.consumer_secret = self.qst.value('urban_data_provider/consumerSecret')
        if self.consumer_secret:
            if_ready[1] = True

        # access token, access timeout
        self.access_token = self.qst.value('urban_data_provider/accessToken')
        self.access_timeout = self.qst.value('urban_data_provider/accessTimeout')
        if self.access_token:
            if_ready[2] = True

        # 행정경계 기준연도
        self.boundary_year = self.qst.value('urban_data_provider/boundaryYear')
        if self.boundary_year:
            if_ready[3] = True

        # 데이터 기준연도
        self.init_years = self.qst.value('urban_data_provider/initYears')  # [인구, 사업체, 농림]
        if self.init_years:
            if_ready[4] = True

        if False in if_ready:
            self.settingSW.setCurrentIndex(0)
            self.boundaryGB.setEnabled(False)
            self.targetGB.setEnabled(False)
            self.subSearchGB.setEnabled(False)
            self.yearGB.setEnabled(False)
            self.ok_button.setEnabled(False)
        else:
            self.check_token()
            if self.token_valid:
                self.accessKeyLE.setText(u'유효(' + self.access_timeout + u')까지')
                self.settingSW.setCurrentIndex(1)
                self.boundaryGB.setEnabled(True)
                self.targetGB.setEnabled(True)
                self.subSearchGB.setEnabled(True)
                self.yearGB.setEnabled(True)
                self.ok_button.setEnabled(True)
            else:
                self.accessKeyLE.setText(self.errMsg)

    def census_setting(self):
        dlg = CensusSetting(self)
        if dlg.exec_():
            self.init_setting()

    def check_input(self):
        if self.is_admin and self.stepCB.currentIndex() == -1:
            self.iface.messageBar().pushMessage("Warning:", u'검색범위를 선택하세요.', level=Qgis.Warning, duration=5)
            return False
        if not self.is_admin and self.extentLE.text() == "":
            self.iface.messageBar().pushMessage("Warning:", u'검색범위를 선택하세요.', level=Qgis.Warning, duration=5)
            return False
        if self.targetBG.checkedId() == -1:
            self.iface.messageBar().pushMessage("Warning:", u'검색대상을 선택하세요.', level=Qgis.Warning, duration=5)
            return False
        return True

    def check_token(self):
        access_timeout_parse = datetime.strptime(self.access_timeout, '%Y-%m-%d %H:%M')
        if access_timeout_parse > datetime.now():
            self.token_valid = True
        else:
            self.get_token()

    def get_token(self):
        try:
            access_response = get_access_token(self.consumer_key, self.consumer_secret)
        except Exception:
            self.token_valid = False
            self.errMsg = u'인증키 발급이 정상적으로 처리되지 않았습니다.'
            self.iface.messageBar().pushMessage("Warning:", self.errMsg, level=Qgis.Warning, duration=5)
            return
        else:
            self.errMsg = access_response[2]
            if self.errMsg == 'Success':
                current_time = datetime.now()
                self.access_token = access_response[0]
                self.access_timeout = (current_time + timedelta(minutes=239)).strftime('%Y-%m-%d %H:%M')
                expire_text = u'(' + self.access_timeout + u')까지 유효'
                self.iface.messageBar().pushMessage("Information:", u'새로운 인증키 발급' + expire_text, level=Qgis.Info,
                                                    duration=5)
                self.qst.setValue('urban_data_provider/accessToken', self.access_token)
                self.qst.setValue('urban_data_provider/accessTimeout', self.access_timeout)
                self.token_valid = True
            else:
                self.iface.messageBar().pushMessage("Warning:", self.errMsg, level=Qgis.Warning, duration=5)
                self.token_valid = False

    def select_extent(self):
        popupmenu = QMenu()
        admin_extent_action = QAction(u'행정구역', self.extentTB)
        map_extent_action = QAction(u'지도범위', self.extentTB)
        popupmenu.addAction(admin_extent_action)
        popupmenu.addSeparator()
        popupmenu.addAction(map_extent_action)
        admin_extent_action.triggered.connect(self.get_admin)
        map_extent_action.triggered.connect(self.get_extent)
        popupmenu.exec_(QCursor.pos())

    def get_admin(self):
        if not self.token_valid:
            self.iface.messageBar().pushMessage("Warning:", u'유효한 인증키가 없습니다.', level=Qgis.Warning, duration=5)
            return
        self.extentSW.setCurrentIndex(0)
        self.is_admin = True
        self.stepCB.clear()
        self.stepCB.addItems([u'전국', u'시도', u'시군구', u'읍면동'])
        self.stepCB.setEnabled(True)
        self.sidoCB.setEnabled(False)
        self.sggCB.setEnabled(False)
        self.emdCB.setEnabled(False)
        self.unitCB.setEnabled(True)
        self.stepCB.setVisible(True)
        self.sidoCB.setVisible(True)
        self.sggCB.setVisible(True)
        self.emdCB.setVisible(True)
        self.check_token()
        self.extentLE.clear()
        self.selected_sido_cd = '11'
        self.prev_idx = 0
        self.set_unit_list()
        self.set_value_from_admin()

    def step_change(self):
        if self.stepCB.currentIndex() == 0:
            self.sidoCB.setEnabled(False)
            self.sggCB.setEnabled(False)
            self.emdCB.setEnabled(False)
            self.sidoCB.clear()
            self.sggCB.clear()
            self.emdCB.clear()
            self.prev_idx = 0
        elif self.stepCB.currentIndex() == 1:
            self.sidoCB.setEnabled(True)
            self.sggCB.setEnabled(False)
            self.emdCB.setEnabled(False)
            self.sggCB.clear()
            self.emdCB.clear()
            if self.prev_idx == 0:
                self.fill_sido()
            self.prev_idx = 1
        elif self.stepCB.currentIndex() == 2:
            self.sidoCB.setEnabled(True)
            self.sggCB.setEnabled(True)
            self.emdCB.setEnabled(False)
            self.emdCB.clear()
            if self.prev_idx == 0:
                self.fill_sido()
            elif self.prev_idx == 1:
                self.fill_sgg()
            self.prev_idx = 2
        else:
            self.sidoCB.setEnabled(True)
            self.sggCB.setEnabled(True)
            self.emdCB.setEnabled(True)
            if self.prev_idx == 0:
                self.fill_sido()
            elif self.prev_idx == 1:
                self.fill_sgg()
            elif self.prev_idx == 2:
                self.fill_emd()
            self.prev_idx = 3
        self.set_unit_list()

    def fill_sido(self):
        self.sidoCB.clear()
        self.sidoCB.addItems(self.sido_nm)

    def fill_sgg(self):
        self.sggCB.clear()
        self.sgg_cd = []
        self.sgg_nm = []
        self.sgg_full = []
        self.selected_sido_cd = self.sido_cd[self.sidoCB.currentIndex()]
        self.check_token()
        admin_stage = get_admin_stage(self.access_token, self.selected_sido_cd, 0)['result']
        for row in admin_stage:
            self.sgg_cd.append(row['cd'])
            self.sgg_nm.append(row['addr_name'])
            self.sgg_full.append(row['full_addr'])
        self.sggCB.addItems(self.sgg_nm)

    def fill_emd(self):
        self.emdCB.clear()
        self.emd_cd = []
        self.emd_nm = []
        self.emd_full = []
        self.selected_sgg_cd = self.sgg_cd[self.sggCB.currentIndex()]
        self.check_token()
        admin_stage = get_admin_stage(self.access_token, self.selected_sgg_cd, 0)['result']
        for row in admin_stage:
            self.emd_cd.append(row['cd'])
            self.emd_nm.append(row['addr_name'])
            self.emd_full.append(row['full_addr'])
        self.emdCB.addItems(self.emd_nm)

    def sido_change(self):
        if self.stepCB.currentIndex() == 2:
            self.fill_sgg()
        elif self.stepCB.currentIndex() == 3:
            self.fill_sgg()
            self.fill_emd()
        self.set_value_from_admin()

    def sgg_change(self):
        if self.stepCB.currentIndex() == 3:
            self.fill_emd()
        self.set_value_from_admin()

    def emd_change(self):
        self.set_value_from_admin()

    def set_value_from_admin(self):
        if self.stepCB.currentIndex() == 0:
            self.search_admin_cd = '0'
            self.search_admin_nm = u'전국'
            self.base_name = u'_전국'
        elif self.stepCB.currentIndex() == 1:
            idx = self.sidoCB.currentIndex()
            self.search_admin_cd = self.sido_cd[idx]
            self.search_admin_nm = self.sido_nm[idx]
            self.base_name = '_' + self.sidoCB.currentText()
        elif self.stepCB.currentIndex() == 2:
            idx = self.sggCB.currentIndex()
            self.search_admin_cd = self.sgg_cd[idx]
            self.search_admin_nm = self.sgg_full[idx]
            self.base_name = '_' + self.sidoCB.currentText() + " " + self.sggCB.currentText()
        elif self.stepCB.currentIndex() == 3:
            idx = self.emdCB.currentIndex()
            self.search_admin_cd = self.emd_cd[idx]
            self.search_admin_nm = self.emd_full[idx]
            self.base_name = '_' + self.sidoCB.currentText() + " " + self.sggCB.currentText() + " " + self.emdCB.currentText()

    def get_extent(self):
        self.extentSW.setCurrentIndex(1)
        dlg = ExtentPanel(self)
        if dlg.exec_():
            self.is_admin = False
            self.stepCB.setEnabled(False)
            self.sidoCB.setEnabled(False)
            self.sggCB.setEnabled(False)
            self.emdCB.setEnabled(False)
            self.stepCB.setVisible(False)
            self.sidoCB.setVisible(False)
            self.sggCB.setVisible(False)
            self.emdCB.setVisible(False)
            self.stepCB.clear()
            self.sidoCB.clear()
            self.sggCB.clear()
            self.emdCB.clear()
            self.unitCB.setEnabled(True)
            self.extentLE.clear()
            self.set_unit_list()
            r = dlg.extentRect
            source_crs = dlg.crs
            xform = QgsCoordinateTransform(source_crs, QgsCoordinateReferenceSystem('EPSG:5179'), QgsProject.instance())
            r_geom = QgsGeometry.fromRect(r)
            r_geom.transform(xform)
            self.extent_text = dlg.lineEdit.text()
            self.search_admin_cd = QgsRectangle.fromWkt(r_geom.asWkt())
            self.search_admin_nm = u'지도범위: ' + self.extent_text
            self.extentLE.setText(self.search_admin_nm)
            self.base_name = u'_선택범위'


    def get_low_search(self):
        low_search_list = ['0', '1', '2', '2']
        self.low_search = low_search_list[self.unitCB.currentIndex()]
        # SGIS - 읍면동 기준 low_search가 '1'이면 집계구 경계가 반환되는 것처럼 설명되어 있으나 '2'로 입력해야 함
        if self.is_admin and self.stepCB.currentIndex() == 3 and self.unitCB.currentIndex() == 1:
            self.low_search = '2'
        # SGIS - 전국 범위의 경우 시도 단위의 데이터만 반환(low_search 1)
        if self.is_admin and self.stepCB.currentIndex() == 0 and self.unitCB.currentIndex() == 0:
            self.low_search = '1'

    def uncheck_boxes(self):
        self.stackedWidget.setCurrentIndex(self.menuBG.checkedId())
        self.yearSW.setCurrentIndex(0)
        self.targetBG.setExclusive(False)
        for checkbox in self.targetBG.buttons():
            checkbox.setChecked(False)
        self.targetBG.setExclusive(True)
        self.yearCB.resize(250, 25)
        self.constructionChk.setChecked(False)
        self.constructionCB.clear()
        self.fieldCB.blockSignals(True)
        self.fieldCB.clear()
        self.fieldCB.blockSignals(False)
        self.set_unit_list()

    def set_unit_list(self):
        unit_list = [u'시도', u'시군구', u'읍면동']
        cb_idx = 0
        self.enable_cb(self.disabled_idx)
        self.disabled_idx = [-1]
        if self.is_admin:
            if self.stepCB.currentIndex() <= 1:
                if self.menuBG.checkedId() == 1 and self.corpindecrease.checkState() == 2:
                    unit_list = [u'시도 - [사업체 증감]에서는 제공되지 않습니다.', u'시군구', u'읍면동']
                    self.disabled_idx = [0]
                    cb_idx = 1
            if self.stepCB.currentIndex() == 2:
                if self.menuBG.checkedId() == 0:
                    unit_list = [u'시군구', u'읍면동', u'집계구']
                elif self.menuBG.checkedId() == 1:
                    unit_list = [u'시군구', u'읍면동', u'집계구 - [지역요약]에서는 제공되지 않습니다.']
                    self.disabled_idx = [2]
            elif self.stepCB.currentIndex() == 3:
                if self.menuBG.checkedId() == 0:
                    unit_list = [u'읍면동', u'집계구']
                elif self.menuBG.checkedId() == 1:
                    unit_list = [u'읍면동', u'집계구 - [지역요약]에서는 제공되지 않습니다.']
                    self.disabled_idx = [1]
        else:
            if self.menuBG.checkedId() == 0:
                unit_list = [u'시도', u'시군구', u'읍면동', '집계구']
            elif self.menuBG.checkedId() == 1 and self.corpindecrease.checkState() != 2:
                unit_list = [u'시도', u'시군구', u'읍면동', u'집계구 - [지역요약]에서는 제공되지 않습니다.']
                self.disabled_idx = [3]
            elif self.menuBG.checkedId() == 1 and self.corpindecrease.checkState() == 2:
                unit_list = [u'시도 - [사업체 증감]에서는 제공되지 않습니다.', u'시군구', u'읍면동', u'집계구 - [지역요약]에서는 제공되지 않습니다.']
                self.disabled_idx = [0, 3]
                cb_idx = 1
        self.unitCB.clear()
        self.unitCB.addItems(unit_list)
        self.disable_cb(self.disabled_idx)
        self.unitCB.setCurrentIndex(cb_idx)

    def enable_cb(self, idx):
        for i in idx:
            if i < 0:
                continue
            else:
                self.unitCB.model().item(i).setEnabled(True)

    def disable_cb(self, idx):
        for i in idx:
            if i < 0:
                continue
            else:
                self.unitCB.model().item(i).setEnabled(False)

    """ 검색할 센서스와 파라미터 값 """

    def get_target(self):
        if not self.token_valid:
            self.iface.messageBar().pushMessage("Warning:", u'유효한 인증키가 없습니다.', level=Qgis.Warning, duration=5)
            self.uncheck_boxes()
            return
        self.check_token()
        self.census_name = self.targetBG.checkedButton().text()
        self.census_id = self.targetBG.checkedButton().objectName()  # SGIS 요청주소 값과 일치, 단 industry는 임의이름 부여
        dlg = None
        if self.census_id == 'population':
            dlg = CensusPanel(self.census_id, self.init_years[0], parent=self)
        elif self.census_id == 'searchpopulation':
            dlg = PopulationPanel(self.census_id, parent=self, init_year=self.init_years[0])
        elif self.census_id == 'household':
            dlg = HouseHoldPanel(self.census_id, parent=self, init_year=self.init_years[0])
        elif self.census_id == 'house':
            dlg = HousePanel(self.census_id, parent=self, init_year=self.init_years[0])
        elif self.census_id == 'company':
            dlg = CompanyPanel(self.census_id, parent=self, init_year=self.init_years[1])
        elif self.census_id == 'industry':
            dlg = IndustryPanel(self.census_id, parent=self, init_year=self.init_years[1],
                                access_token=self.access_token)
            self.census_id = 'company'
        elif self.census_id == 'farmhousehold':
            dlg = FarmhouseholdPanel(self.census_id, parent=self, init_year=self.init_years[2])
        elif self.census_id == 'forestryhousehold':
            dlg = ForesthouseholdPanel(self.census_id, parent=self, init_year=self.init_years[2])
        elif self.census_id == 'fisheryhousehold':
            dlg = FisheryhouseholdPanel(self.census_id, parent=self, init_year=self.init_years[2])
        elif self.census_id == 'householdmember':
            dlg = HouseholdmemberPanel(self.census_id, parent=self, init_year=self.init_years[2])
        elif self.census_id == 'corpindecrease':
            dlg = CorpindecreasePanel(self.census_id, parent=self, init_year=self.init_years[1])
        try:
            dlg.exec_()
        except Exception:
            self.target_text = self.census_name + ']'
            self.type_search = ['']
            self.type_search_val = ['00']
            self.sub_search = ''
            self.sub_search_val = ['']
            self.sub_search_name = ['']
        else:
            if dlg.target_text != '':
                self.target_text = self.census_name + ']' + dlg.target_text
            else:
                self.target_text = ''
            self.type_search = dlg.type_search
            self.type_search_val = dlg.type_search_val
            self.sub_search = dlg.sub_search
            self.sub_search_val = dlg.sub_search_val
            self.sub_search_name = dlg.sub_search_name

        if self.target_text != '':
            self.yearCB.clear()
            if self.menuBG.checkedId() == 0:
                self.yearGB.setTitle(u'기준연도')
                self.base_years = dlg.base_years
                if self.census_id != 'house':
                    self.yearSW.setCurrentIndex(0)
                    self.yearCB.addItems(self.base_years)
                    self.constructionChk.setChecked(False)
                    self.constructionCB.clear()
                else:
                    self.yearSW.setCurrentIndex(1)
                    self.cYearCB.addItems(self.base_years)
                    self.init_target_text = self.census_name + ']' + dlg.target_text
                    self.const_year = dlg.const_year
                    self.const_year_cd = dlg.const_year_cd
            elif self.menuBG.checkedId() == 1:
                self.yearGB.setTitle(u'지역요약 통계는 최신연도(' + self.init_years[1] + u'년)만 제공됩니다')
                if self.census_id != 'corpindecrease':
                    self.yearSW.setCurrentIndex(0)
                    self.base_years = [self.init_years[1]]
                    self.yearCB.addItems(self.base_years)
                else:
                    self.sYearCB.clear()
                    self.eYearCB.clear()
                    self.yearGB.setTitle(u'기준연도')
                    self.yearSW.setCurrentIndex(2)
                    self.base_years = dlg.base_years
                    self.sYearCB.addItems(self.base_years)
                    self.sYearCB.setCurrentIndex(self.sYearCB.count()-1)

            # 센서스 필드명
            self.field_name_engs, self.field_name_kors = get_census_fields(self.census_id)
            self.f_names = []
            for sfx in self.sub_search_name:
                f_name = [sfx + nm for nm in self.field_name_kors]
                self.f_names.append(f_name)

            # 하위 검색 아이템 정렬
            zipped_lists = zip(self.sub_search_val, self.sub_search_name)
            sorted_pairs = sorted(zipped_lists)
            tuples = zip(*sorted_pairs)
            self.sub_search_val, self.sub_search_name = [list(t) for t in tuples]

            # 레이어 스타일 파라미터
            self.fieldCB.blockSignals(True)
            self.fieldCB.clear()
            for fld in self.f_names:
                for f in fld:
                    self.fieldCB.addItem(f)
            self.fieldCB.blockSignals(False)

        else:
            self.uncheck_boxes()

        # 요청 통계
        if self.menuBG.checkedId() == 0:
            self.census_url = 'https://sgisapi.kostat.go.kr/OpenAPI3/stats/' + self.census_id + '.json?'
        elif self.menuBG.checkedId() == 1:
            self.census_url = 'https://sgisapi.kostat.go.kr/OpenAPI3/startupbiz/' + self.census_id + '.json?'

    def set_style(self):
        if self.styleCB.currentIndex() == 0:
            self.fieldCB.setEnabled(True)
            self.popMeasureCB.setEnabled(True)
        elif self.styleCB.currentIndex() == 1:
            self.fieldCB.setEnabled(True)
            self.popMeasureCB.setEnabled(True)
        elif self.styleCB.currentIndex() == 2:
            self.fieldCB.setEnabled(False)
            self.popMeasureCB.setEnabled(False)
        self.change_style()

    def activate_na(self):
        if self.naCB.currentIndex() == 8:
            self.naSB.setEnabled(True)
        else:
            self.naSB.setEnabled(False)

    def refresh_const(self):
        if self.constructionChk.isChecked():
            prev_idx = self.cYearCB.currentIndex()
            prev_cnt = self.cYearCB.count()
            self.cYearCB.clear()
            self.cYearCB.addItems(self.base_years[:-2])
            self.constructionCB.setEnabled(True)
            self.type_search = ['house_type', 'const_year']
            if (prev_cnt - prev_idx) <= 2:
                self.cYearCB.setCurrentIndex(prev_cnt - 3)
            else:
                self.cYearCB.setCurrentIndex(prev_idx)
        else:
            self.cYearCB.clear()
            self.cYearCB.addItems(self.base_years)
            self.constructionCB.clear()
            self.constructionCB.setEnabled(False)
            self.type_search = ['house_type']

    def change_const_years(self):
        if self.constructionChk.isChecked() and self.census_id == 'house' and self.cYearCB.currentIndex() > -1:
            self.constructionCB.clear()
            self.constructionCB.addItems(self.const_year[self.cYearCB.currentIndex()])

    def change_end_years(self):
        self.eYearCB.clear()
        end_years = self.base_years[:self.sYearCB.currentIndex()]
        self.eYearCB.addItems(end_years)

    def change_const(self):
        self.type_search_val = [self.type_search_val[0]]
        if self.constructionCB.currentIndex() > -1 and self.constructionChk.isChecked():
            self.type_search_val.append(
                self.const_year_cd[self.yearCB.currentIndex()][self.constructionCB.currentIndex()])
            self.target_text = self.init_target_text + u' (건축연도)' + self.constructionCB.currentText()

    def run_census(self):
        if not self.token_valid:
            self.iface.messageBar().pushMessage("Warning:", u'유효한 인증키가 없습니다.', level=Qgis.Warning, duration=5)
            return
        self.check_token()
        if not self.check_input():
            return
        if self.menuBG.checkedId() == 0:
            if self.census_id != 'house':
                self.search_year = self.yearCB.currentText()
            else:
                self.search_year = self.cYearCB.currentText()
            self.layer_nm = '[' + self.search_year + '-' + self.target_text
        elif self.menuBG.checkedId() == 1:
            if self.census_id != 'corpindecrease':
                self.search_year = ''
                self.layer_nm = '[' + self.init_years[0] + '-' + self.target_text
            else:
                self.search_year = [self.sYearCB.currentText(), self.eYearCB.currentText()]
                self.layer_nm = '[' + self.target_text + ' ' + self.sYearCB.currentText() + u'부터 '\
                                + self.eYearCB.currentText() + u'까지'
        self.layer_nm = self.layer_nm + self.base_name + '_' + self.unitCB.currentText()
        self.get_low_search()
        if self.naSB.isEnabled():
            self.na_alt = self.naSB.text()
        else:
            self.na_alt = self.naCB.currentText()
        params = [
            self.is_admin,
            self.census_url,
            self.search_year,
            self.search_admin_cd,
            self.search_admin_nm,
            self.low_search,
            self.unitCB.currentIndex(),
            self.type_search,
            self.type_search_val,
            self.target_text,
            self.sub_search,
            self.sub_search_val,
            self.sub_search_name,
            self.field_name_engs,
            self.f_names,
            self.census_name,
            self.boundary_year,
            self.census_id,
            self.access_token,
            self.errMsg,
            self.na_alt
        ]
        if self.menuBG.checkedId() == 0:
            self.worker = Worker(params)
        else:
            self.worker = BizWorker(params)

        self.ok_button.setEnabled(False)
        self.cancel_button.setEnabled(True)
        self.styleGB.setEnabled(False)

        QgsApplication.taskManager().addTask(self.worker)

        # start the worker in a new thread
        self.worker.stepChanged.connect(self.progressLB.setText)
        self.worker.progressChanged.connect(lambda prg: self.progressBar.setValue(int(prg)))
        self.worker.layerCompleted.connect(self.add_layer)
        self.worker.taskCompleted.connect(self.worker_finished)
        self.worker.taskTerminated.connect(self.worker_finished)

    # end of worker

    def add_layer(self, lyr_obj):
        # 레이어 생성
        self.progressLB.setText(u'레이어 생성 중...')
        search_json = json.dumps(lyr_obj)
        vlayer = QgsVectorLayer(search_json, self.layer_nm, "ogr")

        # 레이어 속성
        layer_properties = QgsObjectCustomProperties()
        layer_properties.setValue('current_layer_id', vlayer.id())
        layer_properties.setValue('sgis', self.layer_nm)
        layer_properties.setValue('fields', self.f_names)
        vlayer.setCustomProperties(layer_properties)

        # 레이어 추가
        self.project = QgsProject.instance()
        canvas = self.iface.mapCanvas()
        canvas_crs = canvas.mapSettings().destinationCrs()
        xform2canvas = QgsCoordinateTransform(QgsCoordinateReferenceSystem('EPSG:5179'), canvas_crs, self.project)
        canvas.setExtent(xform2canvas.transform(vlayer.extent()))
        self.project.addMapLayer(vlayer)
        self.progressLB.setText(u'완료(N=' + str(len(lyr_obj['features'])) + u'개)')

    def worker_finished(self):
        self.worker.deleteLater()
        self.progressBar.setValue(0)
        self.ok_button.setEnabled(True)
        self.cancel_button.setEnabled(False)
        self.styleGB.setEnabled(True)

    def kill_worker(self):
        """Kill the worker thread."""
        if self.worker is not None:
            self.progressLB.setText(u'취소가 종료될 때까지 잠시만 기다려주세요.')
            self.worker.cancel()

    def set_renderer(self, layer):
        target_field = self.fieldCB.currentText()
        pop_measure = self.popMeasureCB.currentIndex()
        expression = target_field if pop_measure == 0 else '"' + target_field + '"' + '/area($geometry)'
        ramp_type = self.rampCB.currentText()
        invert = True if self.invertChk.isChecked() else False
        if self.styleCB.currentIndex() == 0:
            style_renderer = graduated_symbol(target_field=expression, ramp_type=ramp_type, invert=invert, opacity=1.0, mode='jenks')
            style_renderer.updateClasses(layer, 10)
        elif self.styleCB.currentIndex() == 1:
            field_id = layer.fields().lookupField(self.fieldCB.currentText())
            if pop_measure == 0:
                unique_values = list(layer.uniqueValues(field_id))
            else:
                unique_values = [f.attributes()[field_id] / f.geometry().area()  for f in layer.getFeatures()]
            unique_values.sort()
            style_renderer = categorized_symbol(unique_values=unique_values, target_field=expression, ramp_type=ramp_type, invert=invert)
        elif self.styleCB.currentIndex() == 2:
            style_renderer = single_symbol()
        return style_renderer

    def change_style(self):
        vlayer = self.iface.activeLayer()
        style_renderer = self.set_renderer(vlayer)
        vlayer.setRenderer(style_renderer)
        self.iface.layerTreeView().refreshLayerSymbology(vlayer.id())
        vlayer.setOpacity(0.7)
        vlayer.triggerRepaint()

    def change_active_layer(self, vlayer):
        if vlayer is None:
            return
        else:
            current_properties = vlayer.customProperties()
            if not current_properties.contains('sgis'):
                return
            else:
                self.fieldCB.blockSignals(True)
                self.fieldCB.clear()
                for fld in current_properties.value('fields'):
                    for f in fld:
                        self.fieldCB.addItem(f)
                self.fieldCB.blockSignals(False)
                self.change_style()

    def tr(self, message, **kwargs):
            """Get the translation for a string using Qt translation API.

            :param message: String for translation.
            :type message: str, QString

            :returns: Translated version of message.
            :rtype: QString
            """
            return QCoreApplication.translate('Dialog', message)

    def give_help(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(self.plugin_dir + "/help/geocodeLd.html"))
