# -*- coding: utf-8 -*-
from PyQt5.QtCore import pyqtSignal
from qgis._core import QgsMessageLog
from qgis.core import (
    Qgis,
    QgsTask
)
from qgis.utils import iface

from ..forms.admin_panel import AdminPanel
from ..utils.sgis_utils import (
    get_admin_area,
    get_user_area,
    admin_from_boundary,
    get_admin_stage,
    get_census,
    join_census
)


class Worker(QgsTask):
    stepChanged = pyqtSignal(str)  # For reporting progress
    layerCompleted = pyqtSignal(object)  # For final result and field name for style

    def __init__(self, params):
        QgsTask.__init__(self)
        self.is_admin = params[0]
        self.census_url = params[1]
        self.search_year = params[2]
        self.search_area = params[3]
        self.search_area_nm = params[4]
        self.low_search = params[5]
        self.search_unit = params[6] + 1
        self.type_search = params[7]
        self.type_search_val = params[8]
        self.target_text = params[9]
        self.sub_search = params[10]
        self.sub_search_val = params[11]
        self.sub_search_name = params[12]
        self.base_engs = params[13]
        self.f_names = params[14]
        self.census_name = params[15]
        self.boundary_year = params[16]
        self.census_id = params[17]
        self.access_token = params[18]
        self.err_msg = params[19]
        self.na_alt = params[20]
        self.step = u'검색 시작..'
        self.not_found_list = []
        self.exception = None
        self.exception_msg = self.err_msg
        self.search_boundary = None
        self.fc = None
        self.percentage = 0
        self.processed = 0
        self.total = 1

        if self.is_admin and self.search_area == '0' and self.search_unit != 1:
            # 전국 범위(searchArea == '0')에서 시군구(searchUnit == 2) 또는 읍면동(searchUnit == 3) 조회 시
            # 개별 시도 단위로 반복 조회하기 위한 전국 시도 리스트 추출(최대 효율 조합 = 시도범위 + 시군구 또는 읍면동 단위로 경계와 센서스 호출)
            self.search_area = AdminPanel.sidoCd
            self.search_area_nm = AdminPanel.sidoNm
        else:
            # 전국 범위에서 시도 단위로 조회하는 경우에는 시도 전체 경계와 시도 전체 데이터를 반환하므로 else에서 처리
            # 그외 경우에도 else에서 처리
            self.search_area = [self.search_area]
            self.search_area_nm = [self.search_area_nm]

    def run(self):
        # 데이터 검색 시작
        self.stepChanged.emit(self.step)
        if self.access_token == '0':
            self.exception = Exception(self.exception_msg)
            return False
        if self.isCanceled():
            return False
        self.fc = {
            'type': 'FeatureCollection',
            'features': [],
            'crs': {
                'type': 'name',
                'properties': {'name': 'urn:ogc:def:crs:EPSG::5179'}
            }
        }
        '''
        영역내경계(userarea), 집계구경계(statsarea)는 항상 최신년도 업데이트 자료만 제공되고 과거 통계데이터는 최신년도 경계에 맞춰 업데이트 되어 제공
        행정구역경계(hadarea)는 연도별로 제공되지만 이 경우에도 과거 통계데이터는 최신년도 행정구역에 맞춰 업데이트 되어 제공
        단계별 주소조회 역시 최신년도 행정구역에 대해서만 제공됨
        따라서 행정구역 경계를 최신 업데이트 된 연도로 조회하여야 데이터 조인 시 불일치가 없음
        과거년도 행정구역 경계를 기준으로 한 과거년도 통계데이터를 결합하려면 과거년도 행정구역 경계를 호출하여 공간조인하거나 데이터를 따로 제공받을 수 밖에 없음
        '''
        for s, s_area in enumerate(self.search_area):
            # 경계정보 수신
            self.step = u' 데이터 요청 중' + '(' + self.search_area_nm[s] + ')'
            self.stepChanged.emit(self.step)
            if self.is_admin:
                self.search_boundary = get_admin_area(self.access_token, s_area, self.low_search, self.boundary_year)
                search_admin_list = [s_area]
            else:
                self.search_boundary = get_user_area(self.access_token, s_area, self.search_unit)
                search_admin_list = admin_from_boundary(self.search_boundary, self.search_unit)

            if self.isCanceled():
                return False
            self.exception_msg = self.search_boundary['errMsg']
            if self.search_boundary['errCd'] != 0:
                self.exception = Exception(self.exception_msg)
                return False

            # 센서스 자료가 없는 행정단위는 누락되어 반환되므로 subFeatCd로 집계범위의 전체 행정코드 조회하여 보충
            feat_cd = [f['properties']['adm_cd'] for f in self.search_boundary['features']]

            # 검색범위에서 인구데이터 수신
            self.step = u' 데이터 수신 중' + '(' + self.search_area_nm[s] + ')'
            self.stepChanged.emit(self.step)

            stat_result = []
            total = len(search_admin_list) * len(self.sub_search_val)
            processed = 0
            for searchAdmin in search_admin_list:
                if searchAdmin == '0':
                    sub_feat_cd = feat_cd
                else:
                    cd_len = len(searchAdmin)
                    sub_feat_cd = [fCd for fCd in feat_cd if fCd[:cd_len] == searchAdmin]
                for i, val in enumerate(self.sub_search_val):
                    census = get_census(
                        self.access_token,
                        self.census_url,
                        self.search_year,
                        self.low_search,
                        searchAdmin,
                        self.type_search,
                        self.type_search_val,
                        self.sub_search,
                        val,
                        self.base_engs,
                        sub_feat_cd
                    )
                    if self.isCanceled():
                        return False
                    if census['errCd'] != 0:
                        self.not_found_list.append(self.sub_search_name[i])
                    stat_result.extend(census['result'])
                    processed += 1
                    self.calculate_progress(processed, total)
                self.calculate_progress(-1, total)

            # 경계정보와 인구데이터 결합
            self.step = u' 데이터 처리 중' + '(' + self.search_area_nm[s] + ')'
            self.stepChanged.emit(self.step)

            total = len(self.search_boundary['features'])
            for processed, feature in enumerate(self.search_boundary['features']):
                matches = [ingu_data for ingu_data in stat_result if
                           ingu_data['adm_cd'] == feature['properties']['adm_cd']]
                for i, match in enumerate(matches):
                    pop_dict = [match[k] if match[k] != 'N/A' else self.na_alt for k in self.base_engs]
                    join_census(feature, pop_dict, self.f_names[i])
                self.calculate_progress(processed, total)
                if self.isCanceled():
                    return False
            self.fc['features'].extend(self.search_boundary['features'])
        self.layerCompleted.emit(self.fc)
        return True

    def finished(self, result):
        if result:
            if len(self.not_found_list) > 0:
                iface.messageBar().pushMessage("검색되지 않은 데이터가 있습니다. ", str(self.not_found_list), level=Qgis.Info,
                                               duration=3)
            return
        else:
            if self.exception is None:
                self.step = u'취소 또는 예외발생으로 실행이 취소되었습니다.'
                self.step_progress()
                iface.messageBar().pushMessage("Warning:", self.step, level=Qgis.Warning, duration=5)
            else:
                self.step = self.exception_msg
                self.step_progress()
                iface.messageBar().pushMessage("Critical:", self.exception_msg, level=Qgis.Critical, duration=5)
                # raise self.exception

    def calculate_progress(self, processed, total):
        processed = processed + 1
        percentage = int((processed * 100) / total)
        self.setProgress(percentage)

    def step_progress(self):
        self.step = str(self.step) + '.'
        self.stepChanged.emit(self.step)


class BizWorker(QgsTask):
    stepChanged = pyqtSignal(str)  # For reporting progress
    layerCompleted = pyqtSignal(object)  # For final result and field name for style

    def __init__(self, params):
        QgsTask.__init__(self)
        self.is_admin = params[0]
        self.census_url = params[1]
        self.search_year = params[2]
        self.search_area = params[3]
        self.search_area_nm = params[4]
        self.low_search = params[5]
        self.search_unit = params[6] + 1
        self.type_search = params[7]
        self.type_search_val = params[8]
        self.target_text = params[9]
        self.sub_search = params[10]
        self.sub_search_val = params[11]
        self.sub_search_name = params[12]
        self.base_engs = params[13]
        self.f_names = params[14]
        self.census_name = params[15]
        self.boundary_year = params[16]
        self.census_id = params[17]
        if self.census_id == 'corpindecrease':
            self.s_year = self.search_year[0]
            self.e_year = self.search_year[1]
            self.search_year = ''
        self.access_token = params[18]
        self.err_msg = params[19]
        self.na_alt = params[20]
        self.step = u'검색 시작..'
        self.not_found_list = []
        self.exception = None
        self.exception_msg = self.err_msg
        self.search_boundary = None
        self.percentage = 0
        self.processed = 0
        self.total = 1

    def run(self):
        # 데이터 검색 시작
        self.stepChanged.emit(self.step)

        if self.access_token == '0':
            self.exception = Exception(self.exception_msg)
            return False
        if self.isCanceled():
            return False

        self.search_boundary = {
            'type': 'FeatureCollection',
            'errMsg': '',
            'errCd': 0,
            'features': [],
            'crs': {
                'type': 'name',
                'properties': {'name': 'urn:ogc:def:crs:EPSG::5179'}
            }
        }

        # 경계정보 수신
        self.step = u'경계정보 요청..'
        self.stepChanged.emit(self.step)
        '''
            영역내경계(userarea), 집계구경계(statsarea)는 항상 최신년도 업데이트 자료만 제공되고 과거 통계데이터는 최신년도 경계에 맞춰 업데이트 되어 제공
            행정구역경계(hadarea)는 연도별로 제공되지만 이 경우에도 과거 통계데이터는 최신년도 행정구역에 맞춰 업데이트 되어 제공
            단계별 주소조회 역시 최신년도 행정구역에 대해서만 제공됨
            따라서 행정구역 경계를 최신 업데이트 된 연도로 조회하여야 데이터 조인 시 불일치가 없음
            과거년도 행정구역 경계를 기준으로 한 과거년도 통계데이터를 결합하려면 과거년도 행정구역 경계를 호출하여 공간조인하거나 데이터를 따로 제공받을 수 밖에 없음
        '''
        if self.is_admin:
            iter_num = self.search_unit if self.search_area == '0' else self.search_unit - 1
            search_admin_list = [self.search_area]
            search_admin_nm = [self.search_area_nm]
            for i in range(iter_num):
                up_list = []
                if self.search_area == '0' and i == 0:
                    search_admin_list = AdminPanel.sidoCd
                    search_admin_nm = AdminPanel.sidoNm
                else:
                    up_list.extend([il for il in search_admin_list])
                    search_admin_list = []
                    search_admin_nm = []
                    for ul in up_list:
                        admin_stage = get_admin_stage(self.access_token, ul, 0)['result']
                        for row in admin_stage:
                            search_admin_list.append(row['cd'])
                            search_admin_nm.append(row['full_addr'])
            if self.search_area == '0' and self.search_unit != 1:
                for s in AdminPanel.sidoCd:
                    f = get_admin_area(self.access_token, s, self.low_search, self.boundary_year)
                    self.search_boundary['errMsg'] = f['errMsg']
                    self.search_boundary['errCd'] = f['errCd']
                    self.search_boundary['features'].extend(f['features'])
            else:
                self.search_boundary = get_admin_area(self.access_token, self.search_area, self.low_search,
                                                      self.boundary_year)
        else:
            self.search_boundary = get_user_area(self.access_token, self.search_area, self.search_unit)
            search_admin_list = []
            search_admin_nm = []
            for f in self.search_boundary['features']:
                if len(f['properties']['adm_cd']) == 2 and self.low_search == '0':
                    search_admin_list.append(f['properties']['adm_cd'] + '010')
                else:
                    search_admin_list.append(f['properties']['adm_cd'])
                search_admin_nm.append(f['properties']['adm_nm'])

        # 생활업종 정보는 인구총조사와 달리 시도코드를 요청 파라미터로 제공되지 않고 시군구 요청시 상위 시도데이터를 함께 반환. 
        # 시도+010 -> 1번 시군구를 조회하면 시도 데이터를 함께 리턴.
        # 자치시의 경우 1번 "자치시"는 011로 끝나므로 해당 010으로 끝나는 "자치시"는 없으며 상위 시도 데이터만 반환함
        if len(search_admin_list[0]) == 2:
            search_admin_list = [searchAdmin + '010' for searchAdmin in search_admin_list]

        # 센서스 자료가 없는 행정단위는 누락되어 반환되므로 subFeatCd로 집계범위의 전체 행정코드 조회하여 보충
        feat_cd = [f['properties']['adm_cd'] for f in self.search_boundary['features']]
        if self.isCanceled():
            return False
        self.exception_msg = self.search_boundary['errMsg']
        if self.search_boundary['errCd'] != 0:
            self.exception = Exception(self.exception_msg)
            return False

        # 검색범위에서 인구데이터 수신
        self.step = u'센서스 데이터 요청..'
        self.stepChanged.emit(self.step)

        stat_result = []
        total = len(search_admin_list) * len(self.sub_search_val)
        processed = 0
        for s, searchAdmin in enumerate(search_admin_list):
            # 검색범위에서 인구데이터 수신
            self.step = u' 데이터 수신 중' + '(' + search_admin_nm[s] + ')'
            self.stepChanged.emit(self.step)

            cd_len = len(searchAdmin)
            sub_feat_cd = [fCd for fCd in feat_cd if fCd[:cd_len] == searchAdmin]

            census = get_census(
                self.access_token,
                self.census_url,
                self.search_year,
                '',
                searchAdmin,
                self.type_search,
                self.type_search_val,
                self.sub_search,
                '',
                self.base_engs,
                sub_feat_cd
            )

            if self.isCanceled():
                return False
            if census['errCd'] != 0:
                self.not_found_list.append(self.sub_search_name[0])

            # 사업체분포 응답결과를 재구성
            if self.census_id == 'corpdistsummary':
                stat_dict = {}
                if self.is_admin and self.search_area == '0':  # 전국단위
                    stat_dict['adm_cd'] = searchAdmin[0:2]
                    css = census['result'][1]
                elif self.is_admin and len(self.search_area) == 2 and self.low_search == '0':  # 시도단위(행정구역)
                    stat_dict['adm_cd'] = self.search_area
                    css = census['result'][1]
                elif not self.is_admin and len(census['result']) == 2 and self.search_unit == 1:  # 시도단위(지도범위)
                    stat_dict['adm_cd'] = searchAdmin[0:2]
                    css = census['result'][1]
                else:
                    css = census['result'][0]
                    stat_dict['adm_cd'] = searchAdmin

                for baseEng in self.base_engs:
                    dist_per = [c['dist_per'] for c in css['theme_list'] if baseEng == c['theme_cd']]
                    try:
                        stat_dict[baseEng] = dist_per[0]
                    except Exception:
                        stat_dict[baseEng] = None
                stat_result.extend([stat_dict])
            elif self.census_id == 'corpindecrease':
                stat_dict = {}
                s_corp_count = {}
                e_corp_count = {}
                for css in census['result']:
                    if css['year'] != self.s_year and css['year'] != self.e_year:
                        continue
                    if css['year'] == self.s_year:
                        start_theme = css['theme_list']
                        for baseEng in self.base_engs:
                            corp_cnt = [sTheme['corp_cnt'] for sTheme in start_theme if sTheme['theme_cd'] == baseEng]
                            try:
                                s_corp_count[baseEng] = corp_cnt[0]
                            except Exception:
                                s_corp_count[baseEng] = 0
                    if css['year'] == self.e_year:
                        end_theme = css['theme_list']
                        for baseEng in self.base_engs:
                            corp_cnt = [eTheme['corp_cnt'] for eTheme in end_theme if eTheme['theme_cd'] == baseEng]
                            try:
                                e_corp_count[baseEng] = corp_cnt[0]
                            except Exception:
                                e_corp_count[baseEng] = 0
                for baseEng in self.base_engs:
                    stat_dict[baseEng] = None
                    try:
                        stat_dict[baseEng] = e_corp_count[baseEng] - s_corp_count[baseEng]
                    except Exception:
                        pass
                stat_dict['adm_cd'] = searchAdmin
                stat_result.extend([stat_dict])
            else:
                stat_result.extend(census['result'])

            processed += 1
            self.calculate_progress(processed, total)

        # 경계정보와 인구데이터 결합
        self.step = u'데이터 처리...'
        self.stepChanged.emit(self.step)
        total = len(self.search_boundary['features'])
        for processed, feature in enumerate(self.search_boundary['features']):
            matches = [ingu_data for ingu_data in stat_result if ingu_data['adm_cd'] == feature['properties']['adm_cd']]
            for i, match in enumerate(matches):
                pop_dict = [match[k] if match[k] != 'N/A' else self.na_alt for k in self.base_engs]
                join_census(feature, pop_dict, self.f_names[i])
            self.calculate_progress(processed, total)
            if self.isCanceled():
                return False
        self.layerCompleted.emit(self.search_boundary)
        return True

    def finished(self, result):
        if result:
            if len(self.not_found_list) > 0:
                iface.messageBar().pushMessage("검색되지 않은 데이터가 있습니다. ", str(self.not_found_list), level=Qgis.Info,
                                               duration=3)
            return
        else:
            if self.exception is None:
                self.step = u'취소 또는 예외발생으로 실행이 취소되었습니다.'
                self.step_progress()
                iface.messageBar().pushMessage("Warning:", self.step, level=Qgis.Warning, duration=5)
            else:
                self.step = self.exception_msg
                self.step_progress()
                iface.messageBar().pushMessage("Critical:", self.exception_msg, level=Qgis.Critical, duration=5)
                # raise self.exception

    def calculate_progress(self, processed, total):
        processed = processed + 1
        percentage = int((processed * 100) / total)
        self.setProgress(percentage)

    def step_progress(self):
        self.step = str(self.step) + '.'
        self.stepChanged.emit(self.step)
