# -*- coding: utf-8 -*-
"""
/***************************************************************************
 NSearchDialog
                                 A QGIS plugin
 .
                             -------------------
        begin                : 2017-02-06
        git sha              : $Format:%H$
        copyright            : (C) 2017 by D.J Paek
        email                : 1002jeen@daum.net
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import sys, os, os.path
from qgis.core import (Qgis,
                       QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform,
                       QgsProject,
                       QgsVectorLayer,
                       QgsFeature,
                       QgsRectangle,
                       QgsField,
                       QgsFields,
                       QgsGeometry,
                       QgsPointXY)
from qgis.PyQt.QtWidgets import QDialog, QDialogButtonBox
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtCore import QUrl, QVariant
from PyQt5 import uic

import sqlite3

from ..utils.utils import get_vworld_search, get_naver_data, get_kakao_data, get_kakao_category
from ..forms.extent_panel import ExtentPanel

FORM_CLASS_Vworld, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), '../forms/place/geocodePlcVworld_dialog_base.ui'))

FORM_CLASS_Naver, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), '../forms/place/geocodePlcNaver_dialog_base.ui'))

FORM_CLASS_Kakao, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), '../forms/place/geocodePlcKakao_dialog_base.ui'))


class PlaceVworldDialog(QDialog, FORM_CLASS_Vworld):
    def __init__(self, iface, parent=None):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

        # Constructor
        super(PlaceVworldDialog, self).__init__(parent)
        self.setupUi(self)

        okButton = self.dialog_BB.button(QDialogButtonBox.Ok)
        closeButton = self.dialog_BB.button(QDialogButtonBox.Close)
        helpButton = self.dialog_BB.button(QDialogButtonBox.Help)

        # 검색카테고리 테이블(VWORLD 제공)
        cat1Names = [u'관광지', u'교육시설', u'교통시설', u'기반/도로/안전/편의시설', u'레저', u'명소', u'문화/예술시설', u'보건시설', u'산업단지', u'서비스산업', u'선형교통', u'선형자연지형', u'숙박시설', u'스포츠시설', u'역사지역', u'원시산업', u'음식점', u'정부공공기관', u'정부입법/사법기관', u'정부행정기관', u'정치/사회/외교', u'제조산업', u'종교시설', u'주거단지', u'주거시설', u'중앙행정기관', u'지방행정기관', u'테마', u'행정구역', u'환경시설']
        self.cat1Codes = ['0603', '0301', '0501', '0502', '0605', '1001', '0602', '0302', '0704', '0703', '0901', '0902', '0401', '0604', '0601', '0701', '0402', '0105', '0104', '0102', '0201', '0702', '0202', '0802', '0801', '0101', '0103', '1002', '0106', '0203']
        self.selectedCodeList = [None, '0603', '060301', '06030100']
        self.cat1CB.addItems(cat1Names)
        self.cat1Change()
        self.cat2Change()
        self.cat1CB.setEnabled(False); self.cat2CB.setEnabled(False); self.cat3CB.setEnabled(False)
		
        self.levelCB.currentIndexChanged.connect(self.levelChange) 
        self.cat1CB.currentIndexChanged.connect(self.cat1Change) 
        self.cat2CB.currentIndexChanged.connect(self.cat2Change)
        self.cat3CB.currentIndexChanged.connect(self.cat3Change)
        # Connect signals
        okButton.clicked.connect(self.geocodePlcVworld)
        closeButton.clicked.connect(self.reject)
        helpButton.clicked.connect(self.giveHelp)
        self.pushButton.clicked.connect(self.getExtent)

	# end of __init__

    """ 검색범위 지정 """
    def getExtent(self):
        dlg = ExtentPanel(self)
        if dlg.exec_():
            self.leText.setText(dlg.lineEdit.text())
            r = dlg.extentRect
            sourceCrs = dlg.crs
            xform = QgsCoordinateTransform(sourceCrs, QgsCoordinateReferenceSystem("EPSG:5179"), QgsProject.instance())
            rGeom = QgsGeometry.fromRect(r)
            rGeom.transform(xform)
            self.bBox = QgsRectangle.fromWkt(rGeom.asWkt())

    """ 검색 카테고리 지정 """
    def levelChange(self):
        if self.levelCB.currentIndex() == 0:
            self.cat1CB.setEnabled(False); self.cat2CB.setEnabled(False); self.cat3CB.setEnabled(False)
        elif self.levelCB.currentIndex() == 1:
            self.cat1CB.setEnabled(True); self.cat2CB.setEnabled(False); self.cat3CB.setEnabled(False)
        elif self.levelCB.currentIndex() == 2:
            self.cat1CB.setEnabled(True); self.cat2CB.setEnabled(True); self.cat3CB.setEnabled(False)
        else:
            self.cat1CB.setEnabled(True); self.cat2CB.setEnabled(True); self.cat3CB.setEnabled(True)

    def cat1Change(self):
        self.cat2CB.clear() 
        self.selectedCodeList[1] = self.cat1Codes[self.cat1CB.currentIndex()]
        self.cat2Codes = []
        conn = sqlite3.connect(os.path.join(os.path.dirname(__file__), '../forms/place/vworld_category.sqlite'))
        with conn:
            cur = conn.cursor()
            cat1 = self.cat1CB.currentText()
            sql = "select distinct code2, name2 from vworld_category where name1 = :N1"
            cur.execute(sql, {"N1" : cat1})
            rows = cur.fetchall()
            for row in rows:
                self.cat2Codes.append(row[0])
                self.cat2CB.addItem(row[1])
        
    def cat2Change(self):
        self.cat3CB.clear() 
        self.selectedCodeList[2] = self.cat2Codes[self.cat2CB.currentIndex()]
        self.cat3Codes = []
        conn = sqlite3.connect(os.path.join(os.path.dirname(__file__), '../forms/place/vworld_category.sqlite'))
        with conn:
            cur = conn.cursor()
            cat2 = self.cat2CB.currentText()
            sql = "select code3, name3 from vworld_category where name2 = :N2"
            cur.execute(sql, {"N2" : cat2})
            rows2 = cur.fetchall()
            for row in rows2:
                self.cat3Codes.append(row[0])
                self.cat3CB.addItem(row[1])

    def cat3Change(self):
        self.selectedCodeList[3] = self.cat3Codes[self.cat3CB.currentIndex()]

    """ 검색시작 """
    def geocodePlcVworld(self):
        searchText = self.searchEdit.text()
        if searchText == '':
            self.iface.messageBar().pushMessage("Info:", u'검색어를 입력하세요.', level=Qgis.Info,  duration = 5)
            return
        if self.leText.text() == '':
            self.bBox = QgsRectangle()
        category = self.selectedCodeList[self.levelCB.currentIndex()]
        isEnd = False
        pageNumber = 0
        searchResults = []
        self.progressLB.setText(u'데이터 검색 중...')
        while isEnd == False:
            pageNumber = pageNumber + 1
            result = get_vworld_search('PLACE', searchText, category, self.bBox, pageNumber)
            total_count = result["total_count"]
            searched = result["searched"]
            search_count = result["search_count"]
            isEnd = result["isEnd"]
            feedback = result["feedback"]
            self.progressBar.setMaximum(total_count)
            searchResults = searchResults + searched
            self.progressBar.setValue(search_count)
        if total_count == 0:
            self.progressLB.setText(feedback)
            self.progressBar.setMaximum(100)
            return

        # create a point layer
        project = QgsProject.instance()
        vLayer = QgsVectorLayer(u"Point?crs=EPSG:5179", searchText, "memory")

        searchFields = QgsFields()
        searchFields.append(QgsField(u'장소명', QVariant.String))
        searchFields.append(QgsField(u'카테고리', QVariant.String))
        searchFields.append(QgsField(u'도로명주소', QVariant.String))
        searchFields.append(QgsField(u'지번주소', QVariant.String))
        vLayer.dataProvider().addAttributes(searchFields)
        vLayer.updateFields()

        self.progressBar.setValue(0)
        self.progressLB.setText(u'데이터 처리 중...')
        for i, search in enumerate(searchResults):
            place_name = search['title']
            category_name = search['category']
            road_address_name = search['address']['road']
            address_name = search['address']['parcel']
            x = float(search['point']['x'])
            y = float(search['point']['y'])
            pointFeat = QgsFeature()
            pointGeom = QgsGeometry.fromPointXY(QgsPointXY(x,y))
            pointFeat.setGeometry(pointGeom)
            attrs = pointFeat.attributes()
            attrs.extend([place_name, category_name, road_address_name, address_name])
            pointFeat.setAttributes(attrs)
            vLayer.dataProvider().addFeature(pointFeat)
            self.progressBar.setValue(i+1)

        canvas = self.iface.mapCanvas()
        canvasCrs = canvas.mapSettings().destinationCrs()
        xform2Canvas = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:5179"), canvasCrs, QgsProject.instance())
        canvas.setExtent(xform2Canvas.transform(vLayer.extent()))
        project.addMapLayer(vLayer)
        self.progressLB.setText(feedback)

    def reject(self):
        """Reject override."""
        # exit the dialog
        QDialog.reject(self)

    def giveHelp(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(self.plugin_dir + "/help/geocodeLd.html"))

class PlaceNaverDialog(QDialog, FORM_CLASS_Naver):
    def __init__(self, iface, parent=None):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

        # Constructor
        super(PlaceNaverDialog, self).__init__(parent)
        self.setupUi(self)

        okButton = self.dialog_BB.button(QDialogButtonBox.Ok)
        closeButton = self.dialog_BB.button(QDialogButtonBox.Close)
        helpButton = self.dialog_BB.button(QDialogButtonBox.Help)

        # Connect signals
        okButton.clicked.connect(self.geocodePlcNaver)
        closeButton.clicked.connect(self.reject)
        helpButton.clicked.connect(self.giveHelp)

	# end of __init__

    def geocodePlcNaver(self):
        searchText = self.searchEdit.text()
        if searchText == '':
            self.iface.messageBar().pushMessage("Info:", u'검색어를 입력하세요.', level=Qgis.Info,  duration = 5)
            return
        isEnd = False
        searchIndex = 0
        searchResults = []
        self.progressLB.setText(u'데이터 검색 중...')
        while isEnd == False:
            result = get_naver_data(searchText, searchIndex)
            total_count = result["total_count"]
            searched = result["searched"]
            search_count = result["search_count"]
            isEnd = result["isEnd"]
            feedback = result["feedback"]
            self.progressBar.setMaximum(total_count)
            searchIndex = searchIndex + 1
            searchResults = searchResults + searched
            self.progressBar.setValue(search_count)
        if total_count == 0:
            self.progressLB.setText(u'검색된 데이터가 없습니다.')
            self.progressBar.setMaximum(100)
            return

        # create a point layer
        project = QgsProject.instance()
        crs = QgsCoordinateReferenceSystem("EPSG:4326")
        # crs.createFromProj4("+proj=tmerc +lat_0=38 +lon_0=128 +k=0.9999 +x_0=400000 +y_0=600000 +ellps=bessel +towgs84=-115.8,474.99,674.11,1.16,-2.31,-1.63,6.43 +units=m +no_defs")
        xform = QgsCoordinateTransform(crs, QgsCoordinateReferenceSystem("EPSG:5179"), QgsProject.instance())
        vLayer = QgsVectorLayer(u"Point?crs=EPSG:5179", searchText, "memory")

        searchFields = QgsFields()
        searchFields.append(QgsField(u'장소명', QVariant.String))
        searchFields.append(QgsField(u'카테고리', QVariant.String))
        searchFields.append(QgsField(u'도로명주소', QVariant.String))
        searchFields.append(QgsField(u'지번주소', QVariant.String))
        searchFields.append(QgsField(u'상세설명', QVariant.String))
        searchFields.append(QgsField(u'URL', QVariant.String))
        vLayer.dataProvider().addAttributes(searchFields)
        vLayer.updateFields()

        self.progressBar.setValue(0)
        self.progressLB.setText(u'데이터 처리 중...')
        for j, search in enumerate(searchResults):
            place_name = search['title']
            category_name = search['category']
            road_address_name = search['roadAddress']
            address_name = search['address']
            description = search['description']
            url = search['link']
            x = float(search['mapx'][:3]+'.'+search['mapx'][4:] )
            y = float(search['mapy'][:2]+'.'+search['mapy'][3:] )

            pointFeat = QgsFeature()
            pointGeom = QgsGeometry.fromPointXY(QgsPointXY(x,y))
            pointGeom.transform(xform)
            pointFeat.setGeometry(pointGeom)
            attrs = pointFeat.attributes()
            attrs.extend([place_name, category_name, road_address_name, address_name, description, url])
            pointFeat.setAttributes(attrs)
            vLayer.dataProvider().addFeature(pointFeat)
            self.progressBar.setValue(j+1)

        canvas = self.iface.mapCanvas()
        canvasCrs = canvas.mapSettings().destinationCrs()
        xform2Canvas = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:5179"), canvasCrs, QgsProject.instance())
        canvas.setExtent(xform2Canvas.transform(vLayer.extent()))
        project.addMapLayer(vLayer)
        self.progressLB.setText(feedback)

    def reject(self):
        """Reject override."""
        # exit the dialog
        QDialog.reject(self)

    def giveHelp(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(self.plugin_dir + "/help/geocodeLd.html"))

class PlaceKakaoDialog(QDialog, FORM_CLASS_Kakao):
    def __init__(self, iface, parent=None):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

        # Constructor
        super(PlaceKakaoDialog, self).__init__(parent)
        self.setupUi(self)

        ok_button = self.dialog_BB.button(QDialogButtonBox.Ok)
        close_button = self.dialog_BB.button(QDialogButtonBox.Close)
        help_button = self.dialog_BB.button(QDialogButtonBox.Help)

        # 검색카테고리 테이블(VWORLD 제공)
        self.category_list = [u'전체', u'대형마트', u'편의점', u'어린이집, 유치원', u'학교', u'학원', u'주차장', u'주유소/충전소', u'지하철역', u'은행', u'문화시설', u'중개업소', u'공공기관', u'관광명소', u'숙박', u'음식점', u'카페', u'병원']
        self.category_code = ['', 'MT1', 'CS2', 'PS3', 'SC4', 'AC5', 'PK6', 'OL7', 'SW8', 'BK9', 'CT1', 'AG2', 'PO3', 'AT4', 'AD5', 'FD6', 'CE7', 'HP8', 'PM9']
        self.categoryCB.addItems(self.category_list)
        self.b_box = QgsRectangle()
	
        # Connect signals
        ok_button.clicked.connect(self.place_kakao)
        close_button.clicked.connect(self.reject)
        help_button.clicked.connect(self.giveHelp)
        self.pushButton.clicked.connect(self.get_extent)
        self.categoryChk.clicked.connect(self.category_search)
	# end of __init__

    def category_search(self):
        if self.categoryChk.isChecked():
            self.searchEdit.setEnabled(False)
        else:
            self.searchEdit.setEnabled(True)

    """ 검색범위 지정 """
    def get_extent(self):
        dlg = ExtentPanel(self)
        if dlg.exec_():
            self.leText.setText(dlg.lineEdit.text())
            r = dlg.extentRect
            source_crs = dlg.crs
            xform = QgsCoordinateTransform(source_crs, QgsCoordinateReferenceSystem("EPSG:4326"), QgsProject.instance())
            r_geom = QgsGeometry.fromRect(r)
            r_geom.transform(xform)
            self.b_box = QgsRectangle.fromWkt(r_geom.asWkt())

    """ 검색시작 """
    def place_kakao(self):
        search_text = self.searchEdit.text()
        category_index = self.categoryCB.currentIndex()
        category = self.category_code[category_index]
        if self.categoryChk.isChecked() == False and search_text == '':
            self.iface.messageBar().pushMessage("Info:", u'검색어를 입력하세요.', level=Qgis.Info,  duration = 5)
            return
        if self.categoryChk.isChecked() and category == '':
            self.iface.messageBar().pushMessage("Info:", u'카테고리를 선택하세요.', level=Qgis.Info,  duration = 5)
            return

        is_end = False
        page_number = 0
        search_results = []
        self.progressLB.setText(u'데이터 검색 중...')
        while is_end == False:
            page_number = page_number + 1
            if self.categoryChk.isChecked():
                result = get_kakao_category(category, self.b_box, page_number)
                layer_name = self.category_list[category_index]
            else:
                result = get_kakao_data(search_text, category, self.b_box, page_number)
                layer_name = search_text
            total_count = result["total_count"]
            searched = result["searched"]
            search_count = result["search_count"]
            is_end = result["is_end"]
            feedback = result["feedback"]

            self.progressBar.setMaximum(total_count)
            search_results = search_results + searched
            self.progressBar.setValue(search_count)
        if total_count == 0:
            self.progressLB.setText(u'검색된 데이터가 없습니다.')
            self.progressBar.setMaximum(100)
            return

        # create a point layer
        project = QgsProject.instance()
        crs = QgsCoordinateReferenceSystem("EPSG:4326")
        #crs.createFromProj4("+proj=tmerc +lat_0=38 +lon_0=128 +k=0.9999 +x_0=400000 +y_0=600000 +ellps=bessel +towgs84=-115.8,474.99,674.11,1.16,-2.31,-1.63,6.43 +units=m +no_defs")
        xform = QgsCoordinateTransform(crs, QgsCoordinateReferenceSystem("EPSG:5179"), QgsProject.instance())
        vLayer = QgsVectorLayer(u"Point?crs=EPSG:5179", layer_name, "memory")

        searchFields = QgsFields()
        searchFields.append(QgsField(u'장소명', QVariant.String))
        searchFields.append(QgsField(u'카테고리', QVariant.String))
        searchFields.append(QgsField(u'도로명주소', QVariant.String))
        searchFields.append(QgsField(u'지번주소', QVariant.String))
        searchFields.append(QgsField(u'URL', QVariant.String))
        vLayer.dataProvider().addAttributes(searchFields)
        vLayer.updateFields()

        self.progressBar.setValue(0)
        self.progressLB.setText(u'데이터 처리 중...')
        for j, search in enumerate(search_results):
            place_name = search['place_name']
            category_name = search['category_group_name']
            road_address_name = search['road_address_name']
            address_name = search['address_name']
            description = search['place_url']
            x = float(search['x'])
            y = float(search['y'])

            pointFeat = QgsFeature()
            pointGeom = QgsGeometry.fromPointXY(QgsPointXY(x,y))
            pointGeom.transform(xform)
            pointFeat.setGeometry(pointGeom)
            attrs = pointFeat.attributes()
            attrs.extend([place_name, category_name, road_address_name, address_name, description])
            pointFeat.setAttributes(attrs)
            vLayer.dataProvider().addFeature(pointFeat)
            self.progressBar.setValue(j+1)

        canvas = self.iface.mapCanvas()
        canvasCrs = canvas.mapSettings().destinationCrs()
        xform2Canvas = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:5179"), canvasCrs, QgsProject.instance())
        canvas.setExtent(xform2Canvas.transform(vLayer.extent()))
        project.addMapLayer(vLayer)
        self.progressLB.setText(feedback)

    def reject(self):
        """Reject override."""
        # exit the dialog
        QDialog.reject(self)

    def giveHelp(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(self.plugin_dir + "/help/geocodeLd.html"))