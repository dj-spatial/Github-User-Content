# -*- coding: utf-8 -*-
import plotly.graph_objs as go
from qgis.core import QgsMessageLog
class buildFigures:
    def buildTraceLine(self, **params):
        traceLine = go.Scatter(
            x=params['x'],
            y=params['y'],
            mode=params['mode'],
            xaxis='x1',
            yaxis='y1',
            text=params['text'],
            textposition='top center',
            hoverinfo='text',
            hoverlabel=dict(bgcolor='white', bordercolor=params['line_color']),
            line=dict(width=params['line_width'], color=params['line_color'], dash=params['dash']),
            name=params['name'],
            legendgroup=params['legendgroup'],
            visible=params['visible']
        )
        return traceLine

    def buildLayoutLine(self, **params):
        x_axis=dict(
            showline=True,
            type=params['type'],
            range=[params['x0'], params['xN']],
            rangeselector=dict(visible=True, buttons=params['buttons']),
            zeroline=False,
            showgrid=False,
            mirror=False,
            tick0=params['x0'],
            tickformat=params['tickformat'],
            nticks=params['nticks'],
            tickfont=dict(size=12),
            showspikes=True, spikecolor='rgb(180,180,180)', spikethickness=1, spikedash='solid'
        )

        y_axis=dict(
            visible=True,
            zeroline=False,
            showline=False,
            tickfont=dict(color='gray'),
            tick0=1,
            nticks=6
        )
        xN_annotations = [
            dict(
                x=params['xN'],
                y=params['yN'],
                xref='x1',
                yref='y1',
                showarrow=True, arrowsize=5, arrowhead=6, arrowwidth=0.5, arrowcolor=params['arrowcolor'], ax=-15, ay=-30,
                font={'size':12},
                align='left',
                text=params['annotText'],
                visible=params['visible']
            )
        ]
        layout = dict(
            annotations=xN_annotations,
            hovermode='closest', hoverlabel=dict(font=dict(color='black')),
            legend=dict(borderwidth = 0, orientation='h', traceorder=params['traceorder'], tracegroupgap = 5, font={'size':11}),
            showlegend=True,
            xaxis1=dict(x_axis, **dict(domain=[0, 1], anchor='y1')),
            yaxis1=dict(y_axis, **dict(domain=[0, 1], anchor='x1')),
            margin=dict(l=35, r=20, t=0, b=0)
        )
        return layout