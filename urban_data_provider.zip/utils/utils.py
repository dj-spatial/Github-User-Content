# -*- coding: utf-8 -*-
import os
import csv
import json
import urllib
import numpy as np
import time
import random
import xml.etree.ElementTree as ET
from datetime import datetime, date
import pandas as pd

from PyQt5.QtCore import Qt
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsMessageLog,
    QgsSettings,
    QgsVectorLayer,
    QgsProject,
    QgsGeometry,
    QgsPointXY,
    QgsGraduatedSymbolRenderer,
    QgsClassificationJenks,
    QgsClassificationQuantile,
    QgsClassificationEqualInterval,
    QgsClassificationPrettyBreaks,
    QgsClassificationLogarithmic,
    QgsClassificationStandardDeviation,
    QgsCategorizedSymbolRenderer,
    QgsSingleSymbolRenderer,
    QgsGradientColorRamp,
    QgsStyle,
    QgsRendererCategory,
    QgsFillSymbol,
)

qst = QgsSettings()
vworld_key = qst.value('urban_data_provider/vworld_key')
road_key = qst.value('urban_data_provider/road_key')
naver_key = qst.value('urban_data_provider/naver_key')
naver_secret = qst.value('urban_data_provider/naver_secret')
kakao_key = qst.value('urban_data_provider/kakao_key')
nsdi_key = qst.value('urban_data_provider/nsdi_key')

# 행안부 도로명 주소
def get_road_address(search_address):
    road_key = qst.value('urban_data_provider/road_key')
    enc_address = urllib.parse.quote(search_address.encode('utf-8'))
    url = 'http://www.juso.go.kr/addrlink/addrLinkApi.do?resultType=json&countPerPage=100&confmKey=' + road_key
    url = url + '&keyword=' + enc_address
    request = urllib.request.Request(url)
    response = urllib.request.urlopen(request)
    response_body = response.read()
    results = json.loads(response_body)['results']
    return results

def get_road_coords(admCd, rnMgtSn, udrtYn, buldMnnm, buldSlno):
    road_key = qst.value('urban_data_provider/road_key')
    url = 'http://www.juso.go.kr/addrlink/addrCoordApi.do?resultType=json&confmKey=' + road_key + '&admCd=' + admCd + \
          '&rnMgtSn=' + rnMgtSn + '&udrtYn=' + udrtYn + '&buldMnnm=' + buldMnnm + '&buldSlno=' + buldSlno
    request = urllib.request.Request(url)
    response = urllib.request.urlopen(request)
    response_body = response.read()
    results = json.loads(response_body)['results']
    return results

def pnu_from_road_cd(admCd, mtYn, lnbrMnnm, lnbrSlno):
    pnu = admCd + str(int(mtYn) + 1) + '0' * (4 - len(lnbrMnnm)) + lnbrMnnm + '0' * (4 - len(lnbrSlno)) + lnbrSlno
    return pnu


def pnu_from_kakao(b_code, mountain_yn, main_address_no, sub_address_no):
    mountain_yn = '1' if mountain_yn == 'N' else '2'
    pnu = b_code + mountain_yn + '0' * (4 - len(main_address_no)) + main_address_no + '0' * (
                4 - len(sub_address_no)) + sub_address_no
    return pnu


# 브이월드 검색엔진에서 장소, 주소 검색 : type('ADDRESS'|'PLACE'), category(type이 'ADDRESS'인 경우 --> 'PARCEL'|'ROAD' 필수)
def get_vworld_search(search_type, search_text, category, b_box, page_number):
    vworld_key = qst.value('urban_data_provider/vworld_key')
    isEnd = False
    search_count = 0
    total_count = 0
    status = ''
    searched = []
    enc_text = urllib.parse.quote(search_text.encode('utf-8'))
    base_url = 'http://api.vworld.kr/req/search?service=search&request=search&key=' + vworld_key + '&'
    base_url = base_url + 'query=' + enc_text + '&size=1000' + '&type=' + search_type + '&crs=EPSG:5179'
    if category is not None:
        base_url = base_url + '&category=' + category
    if not b_box.isEmpty():
        rect = str(b_box.xMinimum()) + ',' + str(b_box.yMinimum()) + ',' + str(b_box.xMaximum()) + ',' + str(
            b_box.yMaximum())
        base_url = base_url + '&bbox=' + rect
    search_url = base_url + '&page=' + str(page_number)
    result_body = urllib.request.urlopen(search_url)
    response_body = json.load(result_body)['response']
    if response_body['status'] == 'ERROR':
        status = 'ERROR'
        feedback = response_body['error']['text']
        isEnd = True
    elif response_body['status'] == 'NOT_FOUND':
        status = u'NOT_FOUND'
        feedback = u'검색 결과가 없습니다'
        isEnd = True
    else:
        status = 'OK'
        search_count = (page_number - 1) * 1000 + int(response_body['record']['current'])
        total_count = int(response_body['record']['total'])
        total_page = int(response_body['page']['total'])
        current_page = int(response_body['page']['current'])
        if total_page == current_page:
            isEnd = True
        searched = response_body['result']['items']
        feedback = str(search_count) + u'개의 데이터가 검색되었습니다.'
    return {"status": status, "feedback": feedback, "isEnd": isEnd, "search_count": search_count,
            "total_count": total_count, "searched": searched}


# 브이월드 공간정보 데이터(지적도 등)
def get_vworld_data(search_data, page, attrs, operators, geom_filter, attr_filters):
    vworld_key = qst.value('urban_data_provider/vworld_key')
    geom_filter_wkt = ''
    total = 0
    current = 0
    feature_collection = {}
    if geom_filter != '':
        geom_filter_wkt = geom_filter.replace('Polygon (', 'Polygon(')
    attr_filter_str = ''
    if attr_filters != '':
        for attr, operator, attrFilter in zip(attrs, operators, attr_filters):
            attr_filter_str = attr_filter_str + attr + ":" + operator + ":" + attrFilter + "|"
    search_url = 'http://api.vworld.kr/req/data?service=data&request=GetFeature&key=' + vworld_key + '&'
    params = {
        'data': search_data,
        'size': 1000,
        'page': page,
        'geomFilter': geom_filter_wkt,
        'attrFilter': urllib.parse.quote(attr_filter_str.encode('utf-8')),
        'crs': 'EPSG:5179'
    }
    enc_url = search_url + urllib.parse.unquote(urllib.parse.urlencode(params))
    result_body = urllib.request.urlopen(enc_url)
    response_body = json.load(result_body)['response']

    if response_body['status'] == 'ERROR':
        status = response_body['error']['text']
    elif response_body['status'] == 'NOT_FOUND':
        status = u'검색된 데이터가 없습니다.'
    else:
        status = 'OK'
        total = response_body['page']['total']
        current = response_body['page']['current']
        feature_collection = response_body['result']['featureCollection']
        feature_collection["crs"] = {"type": "name", "properties": {"name": "urn:ogc:def:crs:EPSG::5179"}}
    return {"status": status, "total": total, "current": current, "featureCollection": feature_collection}


# 네이버 검색
def get_naver_data(search_text, search_index):
    naver_key = qst.value('urban_data_provider/naver_key')
    naver_secret = qst.value('urban_data_provider/naver_secret')
    to_sleep = random.randint(5, 10) / 20
    time.sleep(to_sleep)
    isEnd = False
    start = search_index * 5 + 1  # 최대 5개씩 검색 가능
    enc_text = urllib.parse.quote(search_text.encode('utf-8'))
    base_url = "https://openapi.naver.com/v1/search/local.json?query=" + enc_text
    display = 5
    url = base_url + "&start=" + str(start) + "&display=" + str(display)
    request = urllib.request.Request(url)
    request.add_header("X-Naver-Client-Id", naver_key)
    request.add_header("X-Naver-Client-Secret", naver_secret)
    response = urllib.request.urlopen(request)
    response_body = response.read()
    total_count = json.loads(response_body)['total']
    searched = json.loads(response_body)['items']
    search_count = start - 1 + len(searched)
    feedback = str(search_count) + u'개의 데이터가 검색되었습니다.'
    if search_count >= total_count:
        isEnd = True
        if total_count > 1000:
            feedback = u'1000개 초과!! 검색범위를 좁혀 보세요.'
    return {"isEnd": isEnd, "search_count": search_count, "total_count": total_count, "feedback": feedback,
            "searched": searched}

# 카카오 검색
def get_kakao_data(search_text, category, b_box, page_number):
    kakao_key = qst.value('urban_data_provider/kakao_key')
    enc_text = urllib.parse.quote(search_text.encode('utf-8'))
    base_url = 'https://dapi.kakao.com/v2/local/search/keyword.json?query=' + enc_text
    if category != '':
        base_url = base_url + '&category_group_code=' + category
    if not b_box.isEmpty():
        s = '{},{},{},{}'.format(b_box.xMinimum(), b_box.yMinimum(), b_box.xMaximum(), b_box.yMaximum())
        base_url = base_url + '&rect=' + s
    url = base_url + '&page=' + str(page_number)
    request = urllib.request.Request(url)
    request.add_header("Authorization", "KakaoAK " + kakao_key)
    response = urllib.request.urlopen(request)
    response_body = response.read()
    is_end = json.loads(response_body)['meta']['is_end']
    total_count = json.loads(response_body)['meta']['total_count']
    searched = json.loads(response_body)['documents']
    search_count = (page_number - 1) * 15 + len(searched)
    page_number = page_number + 1
    feedback = str(search_count) + u'개의 데이터가 검색되었습니다.'
    if search_count >= total_count or search_count >= 45:
        is_end = True
        if total_count > 45:
            feedback = u'45개 초과!! 검색범위를 좁혀 보세요.'
    return {"is_end": is_end, "search_count": search_count, "total_count": total_count, "feedback": feedback,
            "searched": searched}

def get_kakao_category(category, b_box, page_number):
    kakao_key = qst.value('urban_data_provider/kakao_key')
    base_url = 'https://dapi.kakao.com/v2/local/search/category.json?&category_group_code=' + category
    if not b_box.isEmpty():
        s = '{},{},{},{}'.format(b_box.xMinimum(), b_box.yMinimum(), b_box.xMaximum(), b_box.yMaximum())
        base_url = base_url + '&rect=' + s
    url = base_url + '&page=' + str(page_number)
    request = urllib.request.Request(url)
    request.add_header("Authorization",  "KakaoAK " + kakao_key)
    response = urllib.request.urlopen(request)
    response_body = response.read()
    is_end = json.loads(response_body)['meta']['is_end']
    total_count = json.loads(response_body)['meta']['total_count']
    searched = json.loads(response_body)['documents']
    search_count = (page_number - 1) * 15 + len(searched)
    page_number = page_number + 1
    feedback = str(search_count) + u'개의 데이터가 검색되었습니다.'
    if search_count >= total_count or search_count >= 45:
        is_end = True
        if total_count > 45:
            feedback = u'45개 초과!! 검색범위를 좁혀 보세요.'
    return {"is_end": is_end, "search_count": search_count, "total_count": total_count, "feedback": feedback,
            "searched": searched}


def get_kakao_address(search_address, page_number, address_size):
    kakao_key = qst.value('urban_data_provider/kakao_key')
    enc_text = urllib.parse.quote(search_address.encode('utf-8'))
    base_url = 'https://dapi.kakao.com/v2/local/search/address.json?query=' + enc_text
    url = base_url + '&page=' + str(page_number) + '&AddressSize=' + str(address_size)
    request = urllib.request.Request(url)
    request.add_header("Authorization",  "KakaoAK " + kakao_key)
    response = urllib.request.urlopen(request)
    response_body = response.read()
    is_end = json.loads(response_body)['meta']['is_end']
    total_count = json.loads(response_body)['meta']['total_count']
    searched = json.loads(response_body)['documents']
    search_count = (page_number - 1) * 15 + len(searched)
    page_number = page_number + 1
    feedback = str(search_count) + u'개의 데이터가 검색되었습니다.'
    if search_count >= total_count or search_count >= 45:
        is_end = True
        if total_count > 45:
            feedback = u'45개 초과!! 검색범위를 좁혀 보세요.'
    return {"is_end": is_end, "search_count": search_count, "total_count": total_count, "feedback": feedback,
            "searched": searched}

# 브이월드 지오코딩(리버스)
def reverse_geocode(current_crs, x, y):
    vworld_key = qst.value('urban_data_provider/vworld_key')
    project = QgsProject.instance()
    geo_code_crs = QgsCoordinateReferenceSystem('EPSG:5179')
    xform = QgsCoordinateTransform(current_crs, geo_code_crs, project)
    point = xform.transform(QgsPointXY(x, y))
    xy = str(point.x()) + ',' + str(point.y())
    base_url = 'http://api.vworld.kr/req/address?service=address&request=getAddress&key=' + vworld_key + '&type=BOTH&'
    url = base_url + 'point=' + xy + '&crs=EPSG:5179'
    result_body = urllib.request.urlopen(url)
    response_body = json.load(result_body)['response']
    status = response_body['status']
    if status == 'NOT_FOUND':
        pnu = '1000000000'
        jibun_full = u'검색결과가 없습니다.'
        roadFull = u'검색결과가 없습니다.'
    elif status == 'ERROR':
        pnu = u'1000000000'
        jibun_full = u'에러가 발생하였습니다.'
        roadFull = u'에러가 발생하였습니다.'

    else:
        # 지번주소
        jibun_juso = response_body['result'][0]
        zipcode = jibun_juso['zipcode']
        jibun_full = jibun_juso['text']
        jibun_sido = jibun_juso['structure']['level1']
        jibun_sgg = jibun_juso['structure']['level2']
        if jibun_sgg == '':
            jibun_sgg = u'시군구'
        jibun_gu = jibun_juso['structure']['level3']
        jibun_emd = jibun_juso['structure']['level4L']
        jibun_bun = jibun_juso['structure']['level5']
        jibun_cd = jibun_juso['structure']['level4LC']

        # PNU
        jibun = jibun_full.split(" ")[-1].split("-")
        bon = jibun[0]
        pnu_bon = '000' + bon
        pnu_bon = pnu_bon[-4:]
        bu = ''
        if len(jibun) > 1:
            bu = jibun[1]
        pnu_bu = '0000' + bu
        pnu_bu = pnu_bu[-4:]
        san = '1'
        if jibun_full.split(" ")[-2] == '산':
            san = '2'
        pnu = jibun_cd + san + pnu_bon + pnu_bu

        # 도로명주소
        if len(response_body['result']) == 1:
            roadFull = u'클릭한 위치에 건물이 없어 도로명 주소가 검색되지 않습니다.'
        else:
            roadJuso = response_body['result'][1]
            roadFull = roadJuso['text']
            roadSido = roadJuso['structure']['level1']
            roadSgg = roadJuso['structure']['level2']
            roadGu = roadJuso['structure']['level3']
            roadNm = roadJuso['structure']['level4L']
            roadEmd = roadJuso['structure']['level4A']
            roadGil = roadJuso['structure']['level5']
            roadNmCd = roadJuso['structure']['level4LC']
            roadBd = roadJuso['structure']['level4AC']

    return pnu, jibun_full, roadFull, jibun_sido, jibun_sgg, jibun_emd, jibun_bun


def decompJibun(full_address):
    jibun = full_address.split(" ")[-1].split("-")

    bon = jibun[0]
    pnu_bon = '000' + bon
    pnu_bon = pnu_bon[-4:]

    bu = ''
    if len(jibun) > 1:
        bu = jibun[1]
    pnu_bu = '0000' + bu
    pnu_bu = pnu_bu[-4:]

    san = '1'
    if full_address.split(" ")[-2] == '산':
        san = '2'
    return [san, pnu_bon, pnu_bu, bon, bu]


def get_land_info(pnu, layer_name):
    vworld_key = qst.value('urban_data_provider/vworld_key')
    base_url = 'https://api.vworld.kr/ned/wfs/getLandCharacteristicsWFS?'
    url = base_url + 'pnu=' + pnu + '&maxFeatures=1000&key=' + vworld_key
    try:
        result = QgsVectorLayer(url, layer_name, 'ogr')
    except:
        result = 'fail'
    else:
        return result

def get_land_attrs(pnu):
    vworld_key = qst.value('urban_data_provider/vworld_key')
    land_char_list = []
    prices = {}
    land_current_usage_cd = ''
    success_message = ''
    baseUrl = 'https://api.vworld.kr/ned/wfs/getLandCharacteristicsWFS?'
    landCharUrl = baseUrl + 'pnu=' + pnu + '&maxFeatures=1000&key=' + vworld_key
    try:
        req = urllib.request.urlopen(landCharUrl)
    except:
        success_message = u'데이터 접속에 오류가 발생하였습니다.'
    else:
        response_body = json.load(req)
        try:
            response_body["landCharacteristicss"]["resultCode"]
        except:
            land_char_list = [u'검색데이터 없음', u'검색데이터 없음', u'검색데이터 없음', u'검색데이터 없음', u'검색데이터 없음', u'검색데이터 없음', u'검색데이터 없음',
                            u'검색데이터 없음', u'검색데이터 없음', u'검색데이터 없음']
            prices = {u'4년전 공시지가': u'검색데이터 없음', u'3년전 공시지가': u'검색데이터 없음', u'2년전 공시지가': u'검색데이터 없음',
                      u'1년전 공시지가': u'검색데이터 없음', u'금년도 공시지가': u'검색데이터 없음'}
            land_current_usage_cd = 'N/A'
            success_message =  'success'
        else:
            if response_body["landCharacteristicss"]["resultCode"] != '':
                success_message =  response_body["landCharacteristicss"]["resultMsg"]
            else:
                success_message = 'success'
                land_char_all = response_body["landCharacteristicss"]['field']
                land_char_last = land_char_all[-1]
                land_purpose = land_char_last['lndcgrCodeNm']
                land_area = land_char_last['lndpclAr']
                land_zone1 = land_char_last['prposArea1Nm']
                land_zone2 = land_char_last['prposArea2Nm']
                land_current_usage_cd = land_char_last['ladUseSittn']
                landCurrentUsage = land_char_last['ladUseSittnNm']
                land_height = land_char_last['tpgrphHgCodeNm']
                land_shape = land_char_last['tpgrphFrmCodeNm']
                road_on = land_char_last['roadSideCodeNm']
                reg_type = land_char_last['regstrSeCodeNm']
                dataYearMonth = land_char_last['stdrYear']
                last_updated = land_char_last['lastUpdtDt']

                land_char_list = [land_purpose, land_area, land_zone1, land_zone2, landCurrentUsage, land_height, land_shape, road_on,
                                reg_type, last_updated]
                announced_year = []
                announced_price = []
                for land_char in land_char_all:
                    announced_year.append(land_char['stdrYear'])
                    announced_price.append(land_char['pblntfPclnd'])
                prices = dict(zip(announced_year[-5::], announced_price[-5::]))
    return land_char_list, prices, land_current_usage_cd, success_message

def get_land_use(pnu):
    base_url = 'https://api.vworld.kr/ned/data/getLandUseAttr?'
    land_use_url = base_url + 'pnu=' + pnu + '&format=json&numOfRows=100&pageNo=1&key=' + vworld_key
    QgsMessageLog.logMessage(str(land_use_url))

    req = urllib.request.urlopen(land_use_url)
    response_body = json.load(req)
    urban_plan = []
    urban_plan_type = []
    land_zone_nm = []
    if response_body["landUses"]["totalCount"] == "0":
        urban_plan.append(u'검색데이터 없음')
        urban_plan_type.append(u'검색데이터 없음')
    else:
        for land_use in response_body["landUses"]['field']:
            urban_plan.append(land_use['prposAreaDstrcCodeNm'])
            urban_plan_type.append(land_use['cnflcAtNm'])
            land_zone_nm.append(land_use['prposAreaDstrcCodeNm'])
    QgsMessageLog.logMessage(str(land_zone_nm))
    '''
    suffix_to_check = ("UQA1", "UQA2", "UQA3", "UQA4", "UQB", "UQC", "UQD")
    land_use_attr = {}
    land_zone_cd = []
    land_zone_nm = []
    if response_body["landUses"]["totalCount"] == "0":
        land_use_attr.update({u'검색데이터 없음': u'검색데이터 없음'})
        land_zone_cd = [u'검색데이터 없음']
        land_zone_nm = [u'검색데이터 없음']
    else:
        land_use_list = response_body["landUses"]['field']
        for land_use in land_use_list:
            land_use_attr.update({land_use['prposAreaDstrcCodeNm']: land_use['cnflcAtNm']})
            if land_use['prposAreaDstrcCode'].startswith(suffix_to_check) and land_use['cnflcAt'] != '3':
                land_zone_cd.append(land_use['prposAreaDstrcCode'])
                land_zone_nm.append(land_use['prposAreaDstrcCodeNm'])
    '''
    return urban_plan, urban_plan_type


def get_land_price(pnu):
    vworld_key = qst.value('urban_data_provider/vworld_key')
    base_url = 'https://api.vworld.kr/ned/data/getIndvdLandPriceAttr?'
    land_price_url = base_url + 'pnu=' + pnu + '&format=json&numOfRows=100&pageNo=1&key=' + vworld_key
    QgsMessageLog.logMessage(str(land_price_url))
    req = urllib.request.urlopen(land_price_url)
    response_body = json.load(req)
    if response_body["indvdLandPrices"]["totalCount"] == "0":
        land_char_list = [u'검색데이터 없음']
        prices = {datetime.today().year: -1}
        acc_index = [0]
    else:
        land_char_all = response_body["indvdLandPrices"]['field']
        land_char_last = land_char_all[-1]
        ldCode = land_char_last['ldCode']
        ldCodeNm = land_char_last['ldCodeNm']
        regstrSeCode = land_char_last['regstrSeCode']
        regstrSeCodeNm = land_char_last['regstrSeCodeNm']
        mnnmSlno = land_char_last['mnnmSlno']
        stdLandAt = land_char_last['stdLandAt']
        lastUpdtDt = land_char_last['lastUpdtDt']
        land_char_list = [ldCode, ldCodeNm, regstrSeCode, regstrSeCodeNm, mnnmSlno, stdLandAt, lastUpdtDt]
        announced_year = []
        announced_price = []
        for land_char in land_char_all:
            announced_year.append(land_char['stdrYear'])
            announced_price.append(int(land_char['pblntfPclnd']))
        prices = dict(zip(announced_year[::], announced_price[::]))

        if '2005' in announced_year:
            start_index = announced_year.index('2005')
        else:
            startYear = announced_year[0]
            start_index = announced_year.index(startYear)
        acc_index = [lp / announced_price[start_index] for lp in announced_price]
    return land_char_list, prices, acc_index


def getLandPriceFluctuation(admCd, stdrYear, stdrMt, scopeDiv, responseBy, zoneUseIdx):
    vworld_key = qst.value('urban_data_provider/vworld_key')
    response = True
    mFactor = 17 if len(admCd) == 2 else 1  # 17개 시도
    numOfRows = (datetime.today().year - 2005 + 1) * 12 * mFactor
    if responseBy == 'byRegions':
        if len(admCd) == 2:
            baseUrl = 'https://api.vworld.kr/ned/data/getLargeCLByRegion?'
        else:
            baseUrl = 'https://api.vworld.kr/ned/data/getByRegion?'
        pclandIndex = 'pclndIndex'
        priceChangeRate = 'pclndChgRt'
    elif responseBy == 'byZonings':
        if len(admCd) == 2:
            baseUrl = 'https://api.vworld.kr/ned/data/getLargeCLByZoning?'
        else:
            baseUrl = 'https://api.vworld.kr/ned/data/getByZoning?'
        # 반환되는 용도지역 지가지수, 지가변동률 중 대상토지의 용도지역 선택
        priceIndexNm = [
            'residePclndIndex',
            'cmrcPclndIndex',
            'indstryPclndIndex',
            'greensPclndIndex',
            'manageAreaPclndIndex',
            'presvManagePclndIndex',
            'prdctnManagePclndIndex',
            'planManagePclndIndex',
            'aglfrsPclndIndex',
            'nrvfPclndIndex',
            'ascityPclndIndex',
            'asaglfrsPclndIndex',
            'noIndex'
        ]
        priceChangeRateNm = [
            'residePclndChgRt',
            'cmrcPclndChgRt',
            'indstryPclndChgRt',
            'greensPclndChgRt',
            'manageAreaPclndChgRt',
            'presvManagePclndChgRt',
            'prdctnManagePclndChgRt',
            'planManagePclndChgRt',
            'aglfrsPclndChgRt',
            'nrvfPclndChgRt',
            'ascityPclndChgRt',
            'asaglfrsPclndChgRt',
            'noChgRt'
        ]
        pclandIndex = priceIndexNm[zoneUseIdx]
        priceChangeRate = priceChangeRateNm[zoneUseIdx]
        QgsMessageLog.logMessage(str(priceChangeRate))
    else:
        if len(admCd) == 2:
            baseUrl = 'https://api.vworld.kr/ned/data/getLargeCLByLandCategory?'
        else:
            baseUrl = 'https://api.vworld.kr/ned/data/getByLandCategory?'
        # 반환되는 이용상황별 지가지수, 지가변동률 중 대상토지의 이용상황 선택
        priceIndexNm = [
            'plotResidePclndIndex',
            'plotCmrcPclndIndex',
            'fctryPclndIndex',
            'fildPclndIndex',
            'ricfldPclndIndex',
            'frtlPclndIndex',
            'etcPclndIndex',
            'noIndex'
        ]
        priceChangeRateNm = [
            'plotResidePclndChgRt',
            'plotCmrcPclndChgRt',
            'fctryPclndChgRt',
            'fildPclndChgRt',
            'ricfldPclndChgRt',
            'frtlPclndChgRt',
            'etcPclndChgRt',
            'noChgRt'
        ]
        pclandIndex = priceIndexNm[zoneUseIdx]
        priceChangeRate = priceChangeRateNm[zoneUseIdx]

    landPriceUrl = (
            baseUrl + 'format=json&numOfRows=' + str(numOfRows) + '&pageNo=1' +
            '&key=' + vworld_key + '&stdrYear=' + str(stdrYear) + '&stdrMt=' + str(stdrMt)
    )
    QgsMessageLog.logMessage(str(landPriceUrl))
    if len(admCd) != 2:
        landPriceUrl = landPriceUrl + '&reqLdCode=' + admCd + '&scopeDiv=' + scopeDiv
    req = urllib.request.urlopen(landPriceUrl)
    response_body = json.load(req)
    if response_body[responseBy]["totalCount"] == "0" or zoneUseIdx == 12:
        stdrDate = [datetime.today()]
        priceIndex = ['100']
        priceRateChange = ['0']
        response = False
    else:
        landCharAll = response_body[responseBy]['field']
        stdrDate = []
        priceIndex = []
        priceRateChange = []
        for landChar in landCharAll:
            if len(admCd) == 2 and landChar['ldCtprvnCode'] != admCd:
                continue
            stdrDate.append(date(int(landChar['stdrYear']), int(landChar['stdrMt']), 1))
            priceIndex.append(landChar[pclandIndex])
            if landChar[priceChangeRate] is None:
                priceRateChange.append('0')
            else:
                priceRateChange.append(landChar[priceChangeRate])
    #### 2020.08.01 = 100으로 지가지수 체계 조정되었으나 데이터는 종전 지수 그대로 반환. 따라서 이전 기간 지가지수를 재조정 #####
    baseIndex = stdrDate.index(date(2020, 8, 1))
    baseValue = float(priceIndex[baseIndex])
    priceIndex = [round(float(pIdx) / baseValue * 100, 3) if i <= baseIndex else float(pIdx) for i, pIdx in
                  enumerate(priceIndex)]
    return stdrDate, priceIndex, priceRateChange, response



def getPolygon(pnu):
    baseUrl = 'http://openapi.nsdi.go.kr/nsdi/IndvdLandPriceService/wfs/getIndvdLandPriceWFS?'
    url = baseUrl + 'typename=F166' '&pnu=' + pnu + '&srsName=EPSG:5174' + '&authkey=670addc99d70b51daf3f16'
    QgsMessageLog.logMessage(str(url))
    feed = urllib.request.urlopen(url)
    tree = ET.parse(feed)
    coords = tree.find('.//{http://www.opengis.net/gml}posList').text
    coords = coords.split(" ")
    coords = np.array(coords, dtype=float)
    xs = coords[::2]
    ys = coords[1::2]
    points = []
    for x, y in zip(xs, ys):
        points.append(QgsPointXY(x, y))
    landPolygon = QgsGeometry.fromPolygonXY([points])
    nsdiCRS = QgsCoordinateReferenceSystem()
    nsdiCRS.createFromProj(
        "+proj=tmerc +lat_0=38 +lon_0=127.0028902777778 +k=1 +x_0=200000 +y_0=500000 +ellps=bessel +towgs84=-115.80,474.99,674.11,1.16,-2.31,-1.63,6.43 +units=m +no_defs")
    xform = QgsCoordinateTransform(nsdiCRS, QgsCoordinateReferenceSystem('EPSG:5179'), QgsProject.instance())
    landPolygon.transform(xform)
    return landPolygon


def getDefacto(accessKey, searchUnit, searchDate, searchHour, searchTypeCd, target_admin):
    baseUrl = 'http://openapi.seoul.go.kr:8088/' + str(accessKey)
    resultType = 'json'
    startIdx = '1'
    if searchUnit == 0:
        searchTypeUnit = '_JACHI'
        endIdx = '25'
    elif searchUnit == 1:
        searchTypeUnit = '_DONG'
        endIdx = '424'
    else:
        searchTypeUnit = ''
        endIdx = '1000'

    if searchTypeCd == 0:
        prefix, suffix = ('pps', 'LocalResd') if searchUnit == 2 else ('SPOP_LOCAL_RESD', searchTypeUnit)
    elif searchTypeCd == 1:
        prefix, suffix = ('pps', 'LongResd') if searchUnit == 2 else ('SPOP_FORN_LONG_RESD', searchTypeUnit)
    else:
        prefix, suffix = ('pps', 'TempResd') if searchUnit == 2 else ('SPOP_FORN_TEMP_RESD', searchTypeUnit)
    searchType = prefix + suffix

    if searchUnit == 2:
        url_suffix = searchHour + '/' # 집계구 API는 당일만 데이터 제공(날짜 입력 x)
    else:
        url_suffix = searchDate + '/' + searchHour + '/'
    requestUrl = baseUrl + '/' + resultType + '/' + searchType + '/' + startIdx + '/' + endIdx + '/' + url_suffix

    if target_admin is not None:
        requestUrl = requestUrl + target_admin
    result = json.load(urllib.request.urlopen(requestUrl))
    try:
        result_rows = result[searchType]['row']
    except:
        resultCd = '-400'
        resultMsg = searchDate + u'-' + searchHour + u'시 요청 데이터가 없거나 오류가 발생했습니다.'
        result_rows = []
    else:
        total_count = int(result[searchType]['list_total_count'])
        if total_count > 1000:
            loop_needed = (total_count - 1) // 1000
            for l in range(0, loop_needed):
                startIdx = str(1000 * l + 1001)
                endIdx = str(int(startIdx) + 999)
                requestUrl = baseUrl + '/' + resultType + '/' + searchType + '/' + startIdx + '/' + endIdx + '/' + url_suffix
                result = json.load(urllib.request.urlopen(requestUrl))
                result_rows += result[searchType]['row']
        resultCd = result[searchType]['RESULT']['CODE']
        resultMsg = result[searchType]['RESULT']['MESSAGE']
    return {'resultCd': resultCd, 'resultMsg': resultMsg, 'rows': result_rows}

def graduated_symbol(target_field, no_pen=False, opacity=1.0, mode='jenks', ramp_type='Spectral', invert=False):
    symbol = QgsFillSymbol()
    if no_pen:
        symbol.symbolLayer(0).setStrokeStyle(Qt.PenStyle(Qt.NoPen))
    symbol.setOpacity(opacity)
    if mode == 'quantile':
        classsification_methods = QgsClassificationQuantile()
    elif mode == 'equal_interval':
        classsification_methods = QgsClassificationEqualInterval()
    elif mode == 'jenks':
        classsification_methods = QgsClassificationJenks()
    elif mode == 'pretty_breaks':
        classsification_methods = QgsClassificationPrettyBreaks()
    elif mode == 'logarithmic':
        classsification_methods = QgsClassificationLogarithmic()
    elif mode == 'standard_deviation':
        classsification_methods = QgsClassificationStandardDeviation()

    if ramp_type is None:
        targetRgb = str(random.randint(0, 255)) + ',' + str(random.randint(0, 255)) + ',' + str(random.randint(0, 255)) + ',' + '255'
        color_ramp = QgsGradientColorRamp.create({'color1': '225,225,225,255', 'color2': targetRgb})
    else:
        color_ramp = QgsStyle().defaultStyle().colorRamp(ramp_type)
    if invert:
        color_ramp.invert()
    renderer = QgsGraduatedSymbolRenderer()
    renderer.setClassAttribute(target_field)
    renderer.setClassificationMethod(classsification_methods)
    renderer.updateColorRamp(color_ramp)
    renderer.updateSymbols(symbol)
    return renderer


def categorized_symbol(unique_values, target_field, ramp_type='Spectral', invert=False):
    categories = []
    for value in unique_values:
        symbol = QgsFillSymbol()
        category = QgsRendererCategory(value, symbol, str(value))
        categories.append(category)
    color_ramp = QgsStyle().defaultStyle().colorRamp(ramp_type)
    if invert:
        color_ramp.invert()
    renderer = QgsCategorizedSymbolRenderer(attrName=target_field, categories=categories)
    renderer.setClassAttribute(target_field)
    renderer.updateColorRamp(color_ramp)
    renderer.updateSymbols(symbol)
    return renderer

def single_symbol():
    symbol = QgsFillSymbol()
    renderer = QgsSingleSymbolRenderer(symbol)
    return renderer
