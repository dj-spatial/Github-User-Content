# -*- coding: utf-8 -*-
from random import randint
from qgis.core import (
    QgsApplication,
    QgsPalLayerSettings,
    QgsVectorLayerSimpleLabeling,
    QgsSymbol,
    QgsGraduatedSymbolRenderer,
    QgsCategorizedSymbolRenderer,
    QgsGradientColorRamp,
    QgsStyle,
    QgsRendererRange,
    QgsRendererCategory,
    QgsFillSymbol,
    QgsMarkerSymbol,
    QgsPointPatternFillSymbolLayer,
    QgsSimpleFillSymbolLayer,
    QgsMessageLog
)
from qgis.PyQt.QtGui import QColor
from qgis.PyQt import QtGui

class LandWfs:

    def __init__(self):
        self.layerCodes = ['F6','F251','F166', 'F166', 'F176', 'F2','F3','F4','F173']

        self.layerKeys=[
            'a3b215beb3a867ebaec995',
            '212048f25486f60b72973c',
            '670addc99d70b51daf3f16',
            'b51ee9e4f34dbda2a39efb',
            '433e4faf00088e7f0fa7fd',
            '8aaaf7b59643e7a08d29b1',
            '8aaaf7b59643e7a08d29b1',
            '8aaaf7b59643e7a08d29b1',
            'b2c2338868c405e26296e3',
            'b51ee9e4f34dbda2a39efb',
            '670addc99d70b51daf3f16'
        ]
				   
        self.baseUrls=[
            'http://openapi.nsdi.go.kr/nsdi/map/CtnlgsSpceService/wfs/getCtnlgsSpceWFS?',
            'http://openapi.nsdi.go.kr/nsdi/LandCharacteristicsService/wfs/getLandCharacteristicsWFS?',
            'http://openapi.nsdi.go.kr/nsdi/IndvdLandPriceService/wfs/getIndvdLandPriceWFS?',
            'http://openapi.nsdi.go.kr/nsdi/ReferLandPriceService/wfs/getReferLandPriceWFS?',
            'http://openapi.nsdi.go.kr/nsdi/LandUseService/wfs/getLandUseWFS?',
            'http://openapi.nsdi.go.kr/nsdi/map/AdresSpceService/wfs/getAdresSpceWFS?',
            'http://openapi.nsdi.go.kr/nsdi/map/AdresSpceService/wfs/getAdresSpceWFS?',
            'http://openapi.nsdi.go.kr/nsdi/map/AdresSpceService/wfs/getAdresSpceWFS?',
            'http://openapi.nsdi.go.kr/nsdi/PossessionService/wfs/getPossessionWFS?'
        ]

        self.gmlNs = ".//{http://www.opengis.net/gml}"

        self.nsdiNs = [
            ".//{http://10.1.17.66:6080/arcgis/services/opend/EiosSpceServiceWFS/MapServer/WFSServer}",
            ".//{http://openapi.nsdi.go.kr}",
            ".//{http://10.1.17.66:6080/arcgis/services/opend/EiosSpceServiceWFS/MapServer/WFSServer}",
            ".//{http://10.1.17.66:6080/arcgis/services/opend/EiosSpceServiceWFS/MapServer/WFSServer}",
            ".//{http://10.1.17.66:6080/arcgis/services/opend/EiosSpceServiceWFS/MapServer/WFSServer}",
            ".//{http://10.1.17.66:6080/arcgis/services/opend/EiosSpceServiceWFS/MapServer/WFSServer}",
            ".//{http://10.1.17.66:6080/arcgis/services/opend/EiosSpceServiceWFS/MapServer/WFSServer}",
            ".//{http://10.1.17.66:6080/arcgis/services/opend/EiosSpceServiceWFS/MapServer/WFSServer}"
        ]

        self.layerRemarks=[
            u': 지적도와 임야도의 경계점을 연결하여 작성한 도면',
            u': 용도지역, 이용상황, 지형, 접도조건 등 토지의 특성',
            u': 개별공시지가',
            u': 표준지의 단위면적당 가격',                          
            u': 토지이용계획',
            u': 시군구 법정 경계구역',
            u': 읍면동 법정 경계구역',
            u': 리의 법정경계구역',
            u': 토지소유정보에 대한 지리데이터'
        ]

        self.fieldNames = [
            [u'PNU', u'지번지목', u'시군구코드', u'읍면동리코드', u'본번', u'부번', u'데이터기준일자'],
            [u'PNU', u'시군구코드', u'읍면동리코드', u'본번', u'부번', u'지번지목', u'기준년도', u'기준월', u'행정동읍면동코드', u'공시지가(기준년도)', u'지목코드', u'지목', u'토지면적(㎡)', u'용도지역코드', u'용도지역', u'용도지역(부)코드', u'용도지역(부)',  u'토지이용상황코드', u'토지이용상황', u'고저', u'형상', u'도로접면', u'데이터기준일자'],
            [u'PNU', u'시군구코드', u'읍면동리코드', u'본번', u'부번', u'지번지목', u'기준년도', u'기준월', u'토지면적(㎡)', u'공시지가(기준년도)', u'공시지가(1년전)', u'공시지가(2년전)', u'공시지가(3년전)', u'공시지가(4년전)', u'표준지여부', u'용도지역코드'],
            [u'PNU', u'시군구코드', u'읍면동리코드', u'본번', u'부번', u'지번지목', u'기준년도', u'기준월', u'토지면적(㎡)', u'공시지가(기준년도)', u'공시지가(1년전)', u'공시지가(2년전)', u'공시지가(3년전)', u'공시지가(4년전)', u'표준지여부', u'지목코드', u'지목', u'용도지역코드', u'용도지역', u'토지이용상황코드', u'토지이용상황'],
            [u'PNU', u'시군구코드', u'읍면동리코드', u'본번', u'부번', u'지번지목', u'도시계획제한', u'저촉여부', u'데이터기준일자'],
            [u'법정구역코드', u'법정구역명', u'최초등록일', u'최종업데이트일'],
            [u'법정구역코드', u'법정구역명', u'최초등록일', u'최종업데이트일'],
            [u'법정구역코드', u'법정구역명', u'최초등록일', u'최종업데이트일'],
            [u'공간자료', u'법정동 시도시군구 코드', u'법정동 읍면동리 코드', u'대장구분코드', u'본번', u'부번', u'지번지목부호', u'원천도형ID', u'원천도형시군구코드', u'등록확인코드', u'소유구분코드', u'STDR_YM', u'공유인수', u'연령대구분코드', u'거주지구분코드', u'국가기관구분코드', u'소유권변동원인코드', u'소유권변동일자', u'지목코드', u'소유구분', u'토지면적(㎡)', u'데이터기준일자', u'토지이용상황코드', u'토지이용상황', u'지형형상코드', u'도로측면코드', u'데이터기준일자']
        ]

        self.fieldCodes = [
            ['PNU', 'LNM_LNDCGR_SMBOL', 'LD_CPSG_CODE', 'LD_EMD_LI_CODE', 'MNNM', 'SLNO', 'LAST_UPDT_DT'],
            ['PNU', 'LD_CPSG_CODE', 'LD_EMD_LI_CODE', 'MNNM', 'SLNO', 'LNM_LNDCGR_SMBOL', 'STDR_YEAR', 'STDR_MT', 'ADSTRD_EMD_CODE', 'PBLNTF_PCLND', 'LNDCGR_CODE', 'LNDCGR_CODE_NM', 'LNDPCL_AR', 'PRPOS_AREA_1', 'PRPOS_AREA_1_NM', 'PRPOS_AREA_2', 'PRPOS_AREA_2_NM', 'LAD_USE_SITTN', 'LAD_USE_SITTN_NM', 'TPGRPH_HG_CODE_NM', 'TPGRPH_FRM_CODE_NM', 'ROAD_SIDE_CODE_NM', 'FRST_REGIST_DT'],
            ['PNU', 'LD_CPSG_CODE', 'LD_EMD_LI_CODE', 'MNNM', 'SLNO', 'LNM_LNDCGR_SMBOL', 'PBLNTF_PCLND_STDR_YEAR', 'PBLNTF_PCLND_STDR_MT', 'LNDPCL_AR', 'PBLNTF_PCLND', 'PSTYR_1_PBLNTF_PCLND', 'PSTYR_2_PBLNTF_PCLND', 'PSTYR_3_PBLNTF_PCLND', 'PSTYR_4_PBLNTF_PCLND', 'STD_LAND_AT', 'PRPOS_AREA'],
            ['PNU', 'LD_CPSG_CODE', 'LD_EMD_LI_CODE', 'MNNM', 'SLNO', 'LNM_LNDCGR_SMBOL', 'PBLNTF_PCLND_STDR_YEAR', 'PBLNTF_PCLND_STDR_MT', 'LNDPCL_AR', 'PBLNTF_PCLND', 'PSTYR_1_PBLNTF_PCLND', 'PSTYR_2_PBLNTF_PCLND', 'PSTYR_3_PBLNTF_PCLND', 'PSTYR_4_PBLNTF_PCLND', 'STD_LAND_AT', 'LNDCGR_CODE', 'LNDCGR_CODE_NM', 'PRPOS_AREA', 'PRPOS_AREA_NM', 'LAD_USE_SITTN', 'LAD_USE_SITTN_NM'],
            ['PNU', 'LD_CPSG_CODE', 'LD_EMD_LI_CODE', 'MNNM', 'SLNO', 'LNM_LNDCGR_SMBOL', 'PRPOS_AREA_DSTRC_NM_LIST', 'CNFLC_AT_NM_LIST', 'FRST_REGIST_DT'],
            ['LD_CPSG_CODE', 'LD_CPSG_CODE_NM', 'FRST_REGIST_DT', 'LAST_UPDT_DT'],
            ['LD_EMD_CODE', 'LD_EMD_CODE_NM', 'FRST_REGIST_DT', 'LAST_UPDT_DT'],
            ['LD_LI_CODE', 'LD_LI_CODE_NM', 'FRST_REGIST_DT', 'LAST_UPDT_DT'],
            ['PNU', 'LD_CPSG_CODE', 'LD_EMD_LI_CODE', 'REGSTR_SE_CODE', 'MNNM', 'SLNO', 'LNM_LNDCGR_SMBOL', 'SRC_OBJECTID', 'SRC_LD_CPSG_CODE', 'ISSU_CONFM_CODE', 'STDR_YEAR', 'STDR_MT', 'ADSTRD_EMD_CODE', 'PBLNTF_PCLND', 'LNDCGR_CODE', 'LNDCGR_CODE_NM', 'LNDPCL_AR', 'PRPOS_AREA_1', 'PRPOS_AREA_1_NM', 'PRPOS_AREA_2', 'PRPOS_AREA_2_NM', 'LAD_USE_SITTN', 'LAD_USE_SITTN_NM', 'TPGRPH_HG_CODE', 'TPGRPH_HG_CODE_NM', 'TPGRPH_FRM_CODE', 'TPGRPH_FRM_CODE_NM', 'ROAD_SIDE_CODE', 'ROAD_SIDE_CODE_NM', 'FRST_REGIST_DT']
        ]

        self.themeNames = [
            u'연속지적도',
            u'토지특성정보',
            u'개별공시지가',
            u'표준지공시지가',
            u'토지이용계획',
            u'법정구역도:시군구',
            u'법정구역도:읍면동',
            u'법정구역도:리',
            u'토지소유정보'
        ]

        self.themeClasses = [
            u'개별공시지가',
            u'용도지역',
            u'지목',
            u'토지이용상황'
        ]

        self.landZoneNm = {
            '11':u'제1종전용주거지역', '12':u'제2종전용주거지역', '13':u'제1종일반주거지역', '14':u'제2종일반주거지역', '15':u'제3종일반주거지역', '16':u'준주거지역',
            '21':u'중심상업지역', '22':u'일반상업지역', '23':u'근린상업지역', '24':u'유통상업지역',
            '31':u'전용공업지역', '32':u'일반공업지역', '33':u'준공업지역',
            '41':u'보전녹지지역', '42':u'생산녹지지역', '43':u'자연녹지지역', '44':u'개발제한구역',
            '51':u'용도미지정지역', '61':u'관리지역', '62':u'보전관리지역', '63':u'생산관리지역', '64':u'계획관리지역',
            '71':u'농림지역', '81':u'자연환경보전지역', 'N/A':'N/A'
        }

        self.landZoneFill = {
            u'제1종전용주거지역':{'color':'255,255,102,255'},
            u'제2종전용주거지역':{'color':'255,255,0,255'},
            u'제1종일반주거지역':{'color':'255,255,102,255'},
            u'제2종일반주거지역':{'color':'255,255,0,255'},
            u'제3종일반주거지역':{'color':'255,204,0,255'},
            u'준주거지역':{'color':'255,255,0,255'},
            u'중심상업지역':{'color':'255,102,204,255'},
        	u'일반상업지역':{'color':'255,102,204,255'},
            u'근린상업지역':{'color':'255,102,204,255'},
            u'유통상업지역':{'color':'255,102,204,255'},
            u'전용공업지역':{'color':'204,102,255,255'},
            u'일반공업지역':{'color':'204,102,255,255'},
            u'준공업지역':{'color':'204,102,255,255'},
            u'보전녹지지역':{'color':'204,255,102,255'},
            u'생산녹지지역':{'color':'204,255,102,255'},
            u'자연녹지지역':{'color':'204,255,102,255'},
            u'개발제한구역':{'color':'102,255,255,255'},
            u'용도미지정지역':{'color':'192,192,192,255'},
            u'관리지역':{'color':'255,255,255,255'},
            u'보전관리지역':{'color':'204,255,102,255'},
            u'생산관리지역':{'color':'204,255,102,255'},
            u'계획관리지역':{'color': '255,255,255,255'},
            u'농림지역':{'color':'204,255,102,255'},
            u'자연환경보전지역':{'color':'204,255,255,255'},
            'N/A':{'color': '192,192,192,255'}
        }

        self.landZonePattern =  {
            u'제1종전용주거지역':{'color':'255,0,0,0', 'outline_color':'255,0,0,255', 'size':'3.6'},
            u'제2종전용주거지역':{'color':'255,0,0,0', 'outline_color':'255,0,0,255', 'size':'3.6'},
            u'제1종일반주거지역':None, 
            u'제2종일반주거지역':None,
            u'제3종일반주거지역':None,
            u'준주거지역':{'color':'255,0,0,255', 'outline_color':'255,0,0,0', 'style':'b_diagonal'},
            u'중심상업지역':{'color':'255,0,0,0', 'outline_color':'255,0,0,255', 'size':'3.6'},
            u'일반상업지역':None,
            u'근린상업지역':{'color':'255,0,0,255', 'outline_color':'255,0,0,0', 'style':'b_diagonal'},
            u'유통상업지역':None,
            u'전용공업지역':{'color':'0,0,0,0', 'outline_color':'0,0,0,255', 'size':'3.6'},
            u'일반공업지역':None,
            u'준공업지역':{'color':'255,0,0,255', 'outline_color':'255,0,0,0', 'style':'b_diagonal'},
            u'보전녹지지역':{'color':'120,192,81,0', 'outline_color':'120,192,81,255', 'size':'3.6'},
            u'생산녹지지역':{'color':'120,192,81,255', 'outline_color':'120,192,81,255', 'style':'b_diagonal'},
            u'자연녹지지역':None,
            u'개발제한구역':None,
            u'용도미지정지역':None,
            u'관리지역':None,
            u'보전관리지역':{'color':'255,0,0,0', 'outline_color':'255,0,0,255', 'size':'3.6'},
            u'생산관리지역':{'color':'255,0,0,255', 'outline_color':'255,0,0,0', 'style':'b_diagonal'},
            u'계획관리지역':{'color':'255,0,0,255', 'outline_color':'255,0,0,0', 'style':'b_diagonal'},
            u'농림지역':{'color':'120,192,81,255', 'outline_color':'120,192,81,255', 'style':'b_diagonal'},
            u'자연환경보전지역':{'color':'120,192,81,0', 'outline_color':'120,192,81,255', 'size':'3.6'},
            'N/A':None
        }

        self.landCatNm = {
            '01':u'전', '02':u'답', '03':u'과수원', '04':u'목장용지', '05':u'임야',
            '06':u'광천지', '07':u'염전', '08':u'대', '09':u'공장용지', '10':u'학교용지',
            '11':u'주차장', '12':u'주유소용지', '13':u'창고용지', '14':u'도로', '15':u'철도용지',
            '16':u'제방', '17':u'하천', '18':u'구거', '19':u'유지', '20':u'양어장',
            '21':u'수도용지', '22':u'공원', '23':u'체육용지', '24':u'유원지', '25':u'종교용지',
            '26':u'사적지', '27':u'묘지', '28':u'잡종지', 'N/A':'N/A'
        }

        self.landCatFill = {
            u'전':{'color':'204,153,0,255'},
            u'답':{'color':'0,204,102,255'},
            u'과수원':{'color':'255,0,102,255'},
            u'목장용지':{'color':'0,153,0,255'},
            u'임야':{'color':'0,102,0,255'},
            u'광천지':{'color':'102,255,255,255'},
            u'염전':{'color':'0,102,255,255'},
            u'대':{'color':'255,255,0,255'},
            u'공장용지':{'color':'102,0,51,255'},
            u'학교용지':{'color':'51,204,204,255'},
            u'주차장':{'color':'128,128,128,255'},
            u'주유소용지':{'color':'204,51,0,255'},
            u'창고용지':{'color':'153,153,102,255'},
            u'도로':{'color':'179,179,179,255'},
            u'철도용지':{'color':'102,102,102,255'},
            u'제방':{'color':'0,102,102,255'},
            u'하천':{'color':'0,153,204,255'},
            u'구거':{'color':'153,204,255,255'},
            u'유지':{'color':'51,102,153,255'},
            u'양어장':{'color':'0,102,153,255'},
            u'수도용지':{'color':'0,0,255,255'},
            u'공원':{'color':'153,255,51,255'},
            u'체육용지':{'color':'255,153,255,255'},
            u'유원지':{'color':'204,255,102,255'},
            u'종교용지':{'color':'102,0,204,255'},
            u'사적지':{'color':'102,102,51,255'},
            u'묘지':{'color':'51,51,0,255'},
            u'잡종지':{'color':'204,204,0,255'},
            u'N/A':{'color':'217,217,217,255'}
        }

        self.landUseFill = {
            u'주거용':{'color':'255,255,0,255'},
            u'단독':{'color':'255,255,179,255'},
            u'연립':{'color':'255,255,153,255'},
            u'다세대':{'color':'255,255,102,255'},
            u'아파트':{'color':'255,255,51,255'},
            u'주거나지':{'color':'204,204,0,255'},
            u'주거기타':{'color':'153,153,0,255'},
            u'상업업무용':{'color':'102,0,255,255'},
            u'상업용':{'color':'255,102,204,255'},
            u'업무용':{'color':'0,102,255,255'},
            u'상업나지':{'color':'255,179,230,255'},
            u'상업기타':{'color':'153,0,102,255'},
            u'주상복합용':{'color':'255,102,0,255'},
            u'주상용':{'color':'255,0,102,255'},
            u'주상나지':{'color':'255,153,102,255'},
            u'주상기타':{'color':'204,102,0,255'},
            u'공업용':{'color':'204,102,255,255'},
            u'공업나지':{'color':'230,179,255,255'},
            u'공업기타':{'color':'153,0,230,255'},
            u'전':{'color':'204,255,102,255'},
            u'과수원':{'color':'255,51,0,255'},
            u'전기타':{'color':'179,255,26,255'},
            u'전창고':{'color':'198,236,121,255'},
            u'전축사':{'color':'182,190,167,255'},
            u'답':{'color':'102,255,179,255'},
            u'답기타':{'color':'0,255,128,255'},
            u'답창고':{'color':'204,255,230,255'},
            u'답축사':{'color':'0,77,38,255'},
            u'임야':{'color':'0,204,0,255'},
            u'조림':{'color':'0,255,0,255'},
            u'자연림':{'color':'0,128,0,255'},
            u'토지임야':{'color':'102,153,0,255'},
            u'목장용지':{'color':'179,255,179,255'},
            u'임야기타':{'color':'204,255,204,255'},
            u'특수토지':{'color':'0,51,102,255'},
            u'광천지':{'color':'0,89,179,255'},
            u'광업용지':{'color':'51,51,0,255'},
            u'염전':{'color':'0,153,153,255'},
            u'양어양식':{'color':'0,128,128,255'},
            u'유원지':{'color':'102,255,153,255'},
            u'야영':{'color':'204,255,221,255'},
            u'공원묘지':{'color':'0,77,26,255'},
            u'회원제골프장':{'color':'0,179,60,255'},
            u'대중제골프장':{'color':'0,230,77,255'},
            u'간이골프장':{'color':'26,255,102,255'},
            u'스키장':{'color':'204,255,255,255'},
            u'경마장':{'color':'102,102,51,255'},
            u'승마장':{'color':'92,92,61,255'},
            u'터미널':{'color':'82,92,122,255'},
            u'콘도':{'color':'112,82,122,255'},
            u'공항':{'color':'61,82,143,255'},
            u'휴게소':{'color':'199,199,5,255'},
            u'매립':{'color':'107,107,97,255'},
            u'발전소':{'color':'77,0,0,255'},
            u'특수기타':{'color':'0,51,102,255'},
            u'공공용지 등':{'color':'15,59,189,255'},
            u'도로등':{'color':'128,128,128,255'},
            u'하천등':{'color':'77,166,255,255'},
            u'공원등':{'color':'51,204,51,255'},
            u'운동장등':{'color':'153,153,102,255'},
            u'주차장등':{'color':'89,89,89,255'},
            u'위험시설':{'color':'153,0,0,255'},
            u'유해혐오시설':{'color':'255,26,26,255'},
            u'기타':{'color':'51,51,153,255'},
            u'N/A':{'color':'192,192,192,255'}
        }

        self.landUseNm = {
            '100':u'주거용', '110':u'단독', '120':u'연립', '130':u'다세대', '140':u'아파트', '150':u'주거나지', '160':u'주거기타',
            '200':u'상업업무용', '210':u'상업용', '220':u'업무용', '230':u'상업나지', '240':u'상업기타',
            '300':u'주상복합용', '310':u'주상용', '320':u'주상나지', '330':u'주상기타',
            '400':u'공업용', '410':u'공업용', '420':u'공업나지', '430':u'공업기타',
            '500':u'전', '510':u'전', '520':u'과수원', '530':u'전기타', '540':u'전창고', '550':u'전축사',
            '600':u'답', '610':u'답', '620':u'답기타', '630':u'답창고', '640':u'답축사',
            '700':u'임야', '710':u'조림', '720':u'자연림', '730':u'토지임야', '740':u'목장용지', '750':u'임야기타',
            '800':u'특수토지', '810':u'광천지', '820':u'광업용지', '830':u'염전', '831':u'양어양식', '840':u'유원지', '841':u'야영',
            '850':u'공원묘지', '860':u'회원제골프장', '861':u'대중제골프장', '862':u'간이골프장', '870':u'스키장', '880':u'경마장', '881':u'승마장',
            '890':u'터미널', '891':u'콘도', '892':u'공항', '893':u'휴게소', '894':u'매립', '895':u'발전소', '899':u'특수기타',
            '900':u'공공용지등', '910':u'도로등', '920':u'하천등', '930':u'공원등', '940':u'운동장등',
            '950':u'주차장등', '960':u'위험시설', '970':u'유해혐오시설', '990':u'기타', 'N/A':'N/A'
        }

    def showLabels(self, vLayer, targetField):
        palLayer = QgsPalLayerSettings()
        palLayer.fieldName = targetField
        palLayer.placement = QgsPalLayerSettings.OverPoint
        palLayer.MultiLineAlign = 1
        palLayer.wrapChar = ' '
        labels = QgsVectorLayerSimpleLabeling(palLayer)
        return labels
  
    def graduatedSymbol(self, vLayer, targetField, predefined, color_classes, opacity):
        symbol = QgsFillSymbol()
        symbol.setOpacity(opacity)
        if predefined is None:
            targetRgb = str(randint(0, 255)) + ',' + str(randint(0, 255)) + ',' + str(randint(0, 255))  + ',' + '255'
            colorRamp = QgsGradientColorRamp.create({'color1':'225,225,225,255', 'color2':targetRgb})
        else:
            colorRamp = QgsStyle().defaultStyle().colorRamp(predefined)
            colorRamp.invert()
        renderer = QgsGraduatedSymbolRenderer.createRenderer(vLayer, targetField, color_classes, QgsGraduatedSymbolRenderer.Jenks, symbol, colorRamp)
        return renderer

    def categorizedSymbol(self, classifiedBy, uIds, opacity, outline_style):
        uFills = []
        uPatterns = []
        for uId in uIds:
            if classifiedBy == u'용도지역' or classifiedBy == 'uname':
                try:
                    self.landZoneFill[uId]
                except:
                    uFills.append(self.landZoneFill['N/A'])
                    uPatterns.append(None)
                else:
                    uFills.append(self.landZoneFill[uId])
                    uPatterns.append(self.landZonePattern[uId])
            elif classifiedBy == u'지목':
                try:
                    self.landCatFill[uId]
                except:
                    uFills.append(self.landCatFill['N/A'])
                    uPatterns.append(None)
                else:
                    uFills.append(self.landCatFill[uId])
                    uPatterns.append(None)
            elif classifiedBy == u'토지이용상황':
                try:
                    self.landUseFill[uId]
                except:
                    uFills.append(self.landUseFill['N/A'])
                    uPatterns.append(None)
                else:
                    uFills.append(self.landUseFill[uId])
                    uPatterns.append(None)

        categories = []
        for uId, uFill, uPattern in zip(uIds, uFills, uPatterns):
            symbol = QgsFillSymbol()
            symbol.deleteSymbolLayer(0)
            symbol.setOpacity(opacity)
            uFill['outline_style'] = outline_style
            bgFill = QgsSimpleFillSymbolLayer.create(uFill)
            symbol.appendSymbolLayer(bgFill)
            if uPattern is not None:
                if 'style' in uPattern:
                    patternFill = QgsSimpleFillSymbolLayer.create(uPattern)
                    symbol.appendSymbolLayer(patternFill)
                else:
                    marker = QgsMarkerSymbol.createSimple(uPattern)
                    filledMarker = QgsPointPatternFillSymbolLayer()
                    filledMarker.setDistanceX(5.0)
                    filledMarker.setDistanceY(5.0)
                    filledMarker.setSubSymbol(marker)
                    symbol.appendSymbolLayer(filledMarker)
            category = QgsRendererCategory(uId, symbol, str(uId))
            categories.append(category)
        renderer = QgsCategorizedSymbolRenderer(classifiedBy, categories)
        return renderer
