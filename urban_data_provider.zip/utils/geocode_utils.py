# -*- coding: utf-8 -*-

from .utils import (
    get_vworld_search,
    get_road_address,
    get_kakao_address,
    pnu_from_kakao,
    pnu_from_road_cd
)

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,QgsMessageLog,
    QgsRectangle,
    QgsGeometry,
    QgsPointXY
)

def getGeoCode(searchAddress):
    total_count = 0
    pnu = []
    emd_cd = []
    road_addr = []
    jibun_addr = []
    rd_nm = []
    buld_no = []
    bd_nm = []
    bd_nm_det = []
    req_type = []
    x = []
    y = []
    crs = []
    feedback = ''
    req_src = ''
    geo_attr = []
 
    #지번 주소 - Vworld
    if total_count == 0:
        try:
            results = get_vworld_search('ADDRESS', searchAddress, 'PARCEL', QgsRectangle(), page_number= 1)
        except:
            pass
        else:
            total_count = results["total_count"]
            juso_list = results["searched"]
            req_src = u'Vworld'

    #도로명 주소 - Vworld
    if total_count == 0:
        try:
            results = get_vworld_search('ADDRESS', searchAddress, 'ROAD', QgsRectangle(), page_number= 1)
        except:
            pass
        else:
            total_count = results["total_count"]
            juso_list = results["searched"]
            req_src = u'Vworld'

    #주소 - 카카오
    if total_count == 0:
        try:
            results = get_kakao_address(searchAddress, 1, 30)
        except:
            total_count = -1
            feedback = u'주소 요청도중 장애가 발생하였습니다!'
        else:
            total_count = results["total_count"]
            juso_list = results["searched"]
            req_src = 'Kakao'

    #도로명 주소 - 행안부
    if total_count == 0:
        try:
            results = get_road_address(searchAddress)
        except:
            pass
        else:
            total_count = int(results['common']['totalCount'])
            juso_list = results['juso']
            req_src = u'Mois'

    if total_count > 0:
        if req_src == 'Vworld':
            for juso in juso_list:
                pnu.append(juso['id'])
                emd_cd.append(juso['id'][:8])
                road_addr.append(juso['address']['road'])
                jibun_addr.append(juso['address']['parcel'])
                try:
                    rd_nm.append(juso['address']['road'].split(' (')[0].split(' ')[-2])
                except:
                    rd_nm.append('')

                try:
                    buld_no.append(juso['address']['road'].split(' (')[0].split(' ')[-1])
                except:
                    buld_no.append('')
                try:
                    bd_nm.append(juso['address']['bldnm'])
                except:
                    bd_nm.append('')
                try:
                    bd_nm_det.append(juso['address']['bldnmdc'])
                except:
                    bd_nm_det.append('')
                req_type.append(juso['address']['category'])
                x.append(juso['point']['x'])
                y.append(juso['point']['y'])
                crs.append('EPSG:5179')
        elif req_src == 'Kakao':
            for juso in juso_list:
                pnu.append(pnu_from_kakao(juso['address']['b_code'], juso['address']['mountain_yn'], juso['address']['main_address_no'], juso['address']['sub_address_no']) if juso['address'] is not None else '')
                emd_cd.append(juso['address']['b_code'][:8] if juso['address'] is not None else '')
                road_addr.append(juso['road_address']['address_name'] if juso['road_address'] is not None else '')
                jibun_addr.append(juso['address']['address_name'] if juso['address'] is not None else '')
                rd_nm.append(juso['road_address']['road_name'] if juso['road_address'] is not None else '')
                bn = juso['road_address']['main_building_no'] if juso['road_address'] is not None else ''
                sn = juso['road_address']['sub_building_no'] if juso['road_address'] is not None else ''
                if sn != '':
                    buld_no.append(bn + '-' + sn)
                else:
                    buld_no.append(bn)
                bd_nm.append(juso['road_address']['building_name'] if juso['road_address'] is not None else '')
                bd_nm_det.append('')
                req_type.append('PARCEL' if juso['address_type'] == 'REGION_ADDR' else 'ROAD')
                geom = QgsGeometry.fromPointXY(QgsPointXY(float(juso['x']), float(juso['y'])))
                xform = QgsCoordinateTransform(QgsCoordinateReferenceSystem('EPSG:4326'), QgsCoordinateReferenceSystem('EPSG:5179'), QgsProject.instance())
                geom.transform(xform)
                x.append(str(geom.asPoint().x()))
                y.append(str(geom.asPoint().y()))
                crs.append('EPSG:5179')
        elif req_src == 'Mois':
            for juso in juso_list:
                emd_cd.append(juso['admCd'][:8])
                pnu.append(pnu_from_road_cd(juso['admCd'][:10], juso['mtYn'], juso['lnbrMnnm'], juso['lnbrSlno']))
                road_addr.append(juso['roadAddr'])
                jibun_addr.append(juso['jibunAddr'])
                rd_nm.append(juso['rn'])
                if juso['buldSlno'] != '0':
                    buld_no.append(juso['buldMnnm'] + '-' + juso['buldSlno'])
                else:
                    buld_no.append(juso['buldMnnm'])
                bd_nm.append(juso['bdNm'])
                bd_nm_det.append('')
                req_type.append('ROAD')
                #행안부 도로명주소 api 요청 시 좌표는 포함되지 않고 별도 좌표 API 요청 필요 - 다수의 좌표 API 요청에 따라 서버 에러 발생 --> 좌표요청을 위한 파라미터만 넘겨서 최종적으로 요청하는 주소에 대해서만 좌표요청
                geo_attr.append([juso['admCd'], juso['rnMgtSn'], juso['udrtYn'], juso['buldMnnm'], juso['buldSlno']])
                crs.append('EPSG:5179')
        feedback = str(total_count)  + u'개의 주소가 검색되었습니다. 가장 가까운 주소를 1개를 선택하세요'
    elif total_count == 0:
        feedback = u'해당되는 주소가 없습니다.'
    return {
            "total_count":total_count,
            "x":x,
            "y":y,
            "pnu":pnu,
            "emdCd":emd_cd,
            "roadAddr":road_addr,
            "jibunAddr":jibun_addr,
            "rd_nm":rd_nm,
            "buld_no":buld_no,
            "bdNm":bd_nm,
            "bdNmDet":bd_nm_det,
            "reqType":req_type,
            "reqSrc":req_src,
            "crs":crs,
            "geoAttr":geo_attr,
            "feedback":feedback
    }