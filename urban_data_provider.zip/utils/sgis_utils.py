import json
import os
import os.path
import sqlite3
import urllib
from datetime import datetime

from qgis.core import QgsMessageLog


def get_access_token(cKey, cSecret, **args):
    args.update({
        'consumer_key': cKey,
        'consumer_secret': cSecret
    })

    auth_url = "https://sgisapi.kostat.go.kr/OpenAPI3/auth/authentication.json?" + urllib.parse.urlencode(args)
    result = urllib.request.urlopen(auth_url)
    accessResult = result.read()
    result_body = json.loads(accessResult)

    errMsg = result_body['errMsg']
    errCd = result_body['errCd']
    if errMsg == 'Success':
        accessToken = result_body['result']['accessToken']
        accessTimeout = float(result_body['result']['accessTimeout']) / 1000
    else:
        accessToken = '0'
        accessTimeout = 0
    return accessToken, accessTimeout, errMsg, errCd


def get_user_area(accessToken, bBox, unitSearch, **args):
    args.update({
        'accessToken': accessToken,
        'minx': bBox.xMinimum(),
        'miny': bBox.yMinimum(),
        'maxx': bBox.xMaximum(),
        'maxy': bBox.yMaximum()
    })
    if unitSearch is not '':
        args.update({
            'cd': unitSearch
        })
    url = "https://sgisapi.kostat.go.kr/OpenAPI3/boundary/userarea.geojson?" + urllib.parse.urlencode(args)
    result_body = urllib.request.urlopen(url)
    userArea = json.load(result_body)
    userArea["crs"] = {"type": "name", "properties": {"name": "urn:ogc:def:crs:EPSG::5179"}}
    return userArea


def get_user_admin(accessToken, point, unitSearch, **args):
    args.update({
        'accessToken': accessToken,
        'x_coor': point.x(),
        'y_coor': point.y()
    })
    url = "https://sgisapi.kostat.go.kr/OpenAPI3/personal/findcodeinsmallarea.json?" + urllib.parse.urlencode(args)
    result_body = urllib.request.urlopen(url)
    userAdmin = json.load(result_body)
    errMsg = userAdmin['errMsg']
    errCd = userAdmin['errCd']
    adm_list = [userAdmin['tot_reg_cd'][:2], userAdmin['tot_reg_cd'][:5], userAdmin['tot_reg_cd'][:7],
                userAdmin['tot_reg_cd']]
    admIdx = int(unitSearch) - 1
    adm = adm_list[admIdx]
    return adm


def get_admin_area(accessToken, admSearch, lowSearch, year, **args):
    if lowSearch == '':
        lowSearch = '0'
    args.update({
        'accessToken': accessToken,
        'year': year,
        'low_search': lowSearch
    })
    if admSearch is not '0':
        args.update({
            'adm_cd': admSearch,
        })
    url = "https://sgisapi.kostat.go.kr/OpenAPI3/boundary/hadmarea.geojson?" + urllib.parse.urlencode(args)
    result_body = urllib.request.urlopen(url)
    adminArea = json.load(result_body)
    adminArea["crs"] = {"type": "name", "properties": {"name": "urn:ogc:def:crs:EPSG::5179"}}
    return adminArea


def get_admin_stage(accessToken, cd, pg_yn, **args):
    args.update({
        'accessToken': accessToken,
        'cd': cd,
        'pg_yn': pg_yn
    })
    url = "https://sgisapi.kostat.go.kr/OpenAPI3/addr/stage.json?" + urllib.parse.urlencode(args)

    result = urllib.request.urlopen(url)
    result_body = json.load(result)
    return result_body


def admin_from_boundary(userarea, unitSearch):
    adm = []
    if unitSearch == 4:  # 집계구인 경우 2단계 상위(시군구) 코드 반환
        for f in userarea['features']:
            adm.append(f['properties']['adm_cd'][:5])
    elif unitSearch == 3:  # 읍면동인 경우 2단계 상위(시도) 코드 반환
        for f in userarea['features']:
            adm.append(f['properties']['adm_cd'][:2])
    elif unitSearch == 2:  # 시군구인 경우 1단계 상위(시도) 코드 반환
        for f in userarea['features']:
            adm.append(f['properties']['adm_cd'][:2])
    else:
        for f in userarea['features']:
            adm.append(f['properties']['adm_cd'])
    adm = list(set(adm))
    return adm


def join_census(feature, popDict, fNames):
    feature['properties'].pop('y', None)
    feature['properties'].pop('x', None)
    for (fName, v) in zip(fNames, popDict):
        try:
            feature['properties'][str(fName)] = float(v)
        except:
            feature['properties'][str(fName)] = None


def available_years(accessToken, searchCategory):
    searchUrl = [
        "https://sgisapi.kostat.go.kr/OpenAPI3/stats/population.json?accessToken=" + accessToken + "&adm_cd=11&low_search=0&year=",
        "https://sgisapi.kostat.go.kr/OpenAPI3/stats/company.json?accessToken=" + accessToken + "&adm_cd=11&low_search=0&theme_cd=5001&year=",
        "https://sgisapi.kostat.go.kr/OpenAPI3/stats/forestryhousehold.json?accessToken=" + accessToken + "&adm_cd=11010&low_search=0&year=",
        "https://sgisapi.kostat.go.kr/OpenAPI3/boundary/hadmarea.geojson?accessToken=" + accessToken + "&adm_cd=11010&low_search=0&year="
    ]

    thisYear = datetime.now().year
    latestYear = False
    i = 0
    if searchCategory == 2:  # 농림어업총조사
        baseYear = 2015 + (thisYear - 2015) // 5 * 5
        while latestYear == False:
            url = searchUrl[searchCategory]
            url = url + str(baseYear - i * 5)
            result = urllib.request.urlopen(url)
            result_body = json.load(result)
            if result_body['errCd'] == 0:
                initYear = baseYear - i * 5
                latestYear = True
            i = i + 1
    else:
        if searchCategory == 0 or searchCategory == 1:  # 인구-가구-주택(0), 사업체(1)
            i = i + 1
        while latestYear == False:
            url = searchUrl[searchCategory]
            url = url + str(thisYear - i)
            result = urllib.request.urlopen(url)
            result_body = json.load(result)
            if searchCategory == 1:
                if result_body['result'] and result_body['errCd'] == 0:
                    latestYear = True
                    initYear = thisYear - i
            else:
                if result_body['errCd'] == 0:
                    latestYear = True
                    initYear = thisYear - i
            i = i + 1
    return initYear


def get_census(
        accessToken,
        searchUrl,
        yearSearch,
        lowSearch,
        admSearch,
        typeSearch,
        typeSearchVal,
        subSearch,
        subSearchVal,
        baseEngs,
        subFeatCd,
        **args
):
    census = []
    args.update({
        'accessToken': accessToken,
    })

    if admSearch is not '0':
        args.update({
            'adm_cd': admSearch
        })
    if yearSearch is not '':
        args.update({
            'year': yearSearch
        })
    if lowSearch is not '':
        args.update({
            'low_search': lowSearch
        })
    # Type Search
    for search, searchVal in zip(typeSearch, typeSearchVal):
        if searchVal is not '00':
            args.update({
                search: searchVal
            })
    # Sub Search
    if subSearchVal is not '':
        args.update({
            subSearch: subSearchVal
        })
    census_url = searchUrl + urllib.parse.urlencode(args)
    result = urllib.request.urlopen(census_url)
    result_body = json.load(result)
    if result_body['errCd'] is not 0:
        # 모든 피쳐에 대해 데이터가 반환되지 않는 경우(errCd != 0) 모든 피쳐에 admin 코드 생성하고 0값 입력
        result_body['result'] = []
        for cd in subFeatCd:
            dummyKeys = ['adm_cd']
            dummyKeys.extend(baseEngs)
            Nas = [0] * len(baseEngs)
            dummyVals = [cd]
            dummyVals.extend(Nas)
            dummyDict = dict(zip(dummyKeys, dummyVals))
            result_body['result'].append(dummyDict)
    else:
        # 일부 피쳐에 대해서만 데이터가 반환되지 않는 경우(errCd == 0) 해당 피쳐 admin 코드가 누락되어 반환되므로 해당 피쳐의 admin 코드 생성하고 NA값 입력
        adm_cd_list = [r['adm_cd'] for r in list(filter(None, result_body['result']))]
        for cd in subFeatCd:
            if cd not in adm_cd_list:
                dummyKeys = ['adm_cd']
                dummyKeys.extend(baseEngs)
                Nas = [0] * len(baseEngs)
                dummyVals = [cd]
                dummyVals.extend(Nas)
                dummyDict = dict(zip(dummyKeys, dummyVals))
                result_body['result'].append(dummyDict)
    return result_body


def get_industry(accessToken, class_deg, class_code, **args):
    args.update({
        'accessToken': accessToken,
        'class_deg': class_deg
    })

    if class_code is not '':
        args.update({
            'class_code': class_code
        })

    url = "https://sgisapi.kostat.go.kr/OpenAPI3/stats/industrycode.json?" + urllib.parse.urlencode(args)
    result = urllib.request.urlopen(url)
    result_body = json.load(result)
    if result_body['errCd'] is not 0:
        result_body.update({'result': [{"class_code": '00000', "class_nm": 'None'}]})
    return result_body['result']


def get_census_fields(census_id):
    eng_field_list = []
    kor_field_list = []
    conn = sqlite3.connect(os.path.join(os.path.dirname(__file__), '../sgis/census_field.sqlite'))
    with conn:
        cur = conn.cursor()
        if census_id == 'corpdistsummary':
            sql = "select eng, kor from census_field where (oid = 'corpdistsummary') and (gr_id <> 'A' and " \
                  "gr_id <> 'B' and gr_id <> 'E' and gr_id <> '99')"
            cur.execute(sql)
        else:
            sql = "select eng, kor from census_field where oid = :N1"
            cur.execute(sql, {"N1": census_id})
        rows = cur.fetchall()
        for row in rows:
            eng_field_list.append(row[0])
            kor_field_list.append(row[1])
    return eng_field_list, kor_field_list


def get_base_years(census_id, initYear):
    baseYears = []
    if census_id == 'company':
        baseYears.extend(range(int(initYear), 1999, -1))
    elif census_id == 'farmhousehold' or census_id == 'householdmember':
        baseYears.extend(range(int(initYear), 1995, -5))
    elif census_id == 'forestryhousehold' or census_id == 'fisheryhousehold':
        baseYears.extend(range(int(initYear), 2000, -5))
    elif census_id == 'corpindecrease':
        baseYears.extend(range(int(initYear), 2006, -1))
    else:
        baseYears.extend(range(int(initYear), 2015, -1))
        baseYears.extend(range(2015, 1995, -5))
    baseYears = list(map(str, baseYears))
    return baseYears
