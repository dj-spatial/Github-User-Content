# -*- coding: utf-8 -*-
"""
/***************************************************************************
 NSearchDialog
                                 A QGIS plugin
 .
                             -------------------
        begin                : 2017_02-06
        git sha              : $Format:%H$
        copyright            : (C) 2017 by D.J Paek
        email                : dj.paek1@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os.path
from pathlib import Path
import pandas as pd
from datetime import datetime
from time import sleep
from threading import Thread
import os.path
import tempfile
import sqlite3
from PyQt5 import uic
from PyQt5.QtCore import QDate
from PyQt5.QtGui import QIcon, QImage, QColor, QPainter, QPixmap, QFont
from PyQt5.QtWidgets import QFileDialog, QLabel, QGraphicsTextItem, QTableWidgetItem, QProgressBar, QToolButton, \
    QPushButton, QWidget
from qgis.core import (
    Qgis,
    QgsProject,
    QgsApplication,
    QgsMessageLog,
    QgsVectorLayer,
    QgsField,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsExpression,
    QgsFeatureRequest,
    QgsNetworkAccessManager,
    QgsSettings,
    QgsMapSettings,
    QgsRectangle,
    QgsMapRendererCustomPainterJob,
    QgsObjectCustomProperties
)

from qgis.PyQt.QtWidgets import QDockWidget, QDialogButtonBox
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtCore import QUrl, Qt, QVariant
from qgis.PyQt.QtWebKit import QWebSettings
from qgis.PyQt.QtWebKitWidgets import QWebView
from qgis.PyQt.QtWidgets import QVBoxLayout, QGridLayout
from .defacto_worker import DefactoLayerWorker, MapOnCanvas
from .graph_worker import PlotlyWorker
from .data_loading import DataLoading
from .graph_panel import GraphPanel
from ..utils.maptool import SelectTool
from ..utils.utils import graduated_symbol
from ..forms.seoul.defacto_setting import DefactoSetting

FORM_CLASS_SeoulDefacto, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), '../forms/seoul/defacto_span_widget.ui'))


class DefactoSpanDialog(QDockWidget, FORM_CLASS_SeoulDefacto):
    def __init__(self, iface):
        # Constructor
        QDockWidget.__init__(self)
        self.iface = iface
        self.setupUi(self)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self)
        census_dock = self.iface.mainWindow().findChild(QDockWidget, 'censusDock')
        site_dock = self.iface.mainWindow().findChild(QDockWidget, 'siteDock')
        if census_dock and census_dock.isVisible():
            self.iface.mainWindow().tabifyDockWidget(self, census_dock)
        elif site_dock and site_dock.isVisible():
            self.iface.mainWindow().tabifyDockWidget(self, site_dock)
        self.raise_()
        icon = QIcon(os.path.dirname(__file__) + '../../icons/setting.svg')
        self.settingBtn.setIcon(icon)
        self.ok_button = self.dialog_BB.button(QDialogButtonBox.Ok)
        self.cancel_button = self.dialog_BB.button(QDialogButtonBox.Cancel)
        self.ok_button.setEnabled(False)
        self.cancel_button.setEnabled(False)

        # Init Setting
        self.defacto_key = None
        self.consumer_key = None
        self.consumer_secret = None
        self.db_path = None
        self.qst = QgsSettings()
        self.init_setting()
        self.current_layer = None
        self.ignore_missing = False
        self.search_unit = 0
        self.search_hour_range = [
            '00',
            '01',
            '02',
            '03',
            '04',
            '05',
            '06',
            '07',
            '08',
            '09',
            '10',
            '11',
            '12',
            '13',
            '14',
            '15',
            '16',
            '17',
            '18',
            '19',
            '20',
            '21',
            '22',
            '23'
        ]
        self.timeSpanCB.addItems(self.search_hour_range)
        self.timeSpanCB.setCurrentIndex(9)
        self.agg_range = [
            u'평균',
            u'표준편차',
            u'최소값',
            u'1/4분위',
            u'중앙값',
            u'3/4분위',
            u'최대값',
            u'표준오차',
            u'IQR',
            u'범위',
            u'왜도',
            u'합계'
        ]
        self.aggCB.addItems(self.agg_range)

        # 컬럼명/컬럼타입
        self.col_names_local = [
            u"keyAdmin",
            u"00_09세",
            u"10_14세",
            u"15_19세",
            u"20_24세",
            u"25_29세",
            u"30_34세",
            u"35_39세",
            u"40_44세",
            u"45_49세",
            u"50_54세",
            u"55_59세",
            u"60_64세",
            u"65_69세",
            u"70세이상",
        ]
        self.col_names_foreign = [
            "keyAdmin",
            "Chinese",
            "non_Chinese"
        ]

        # 행정구역 대조표
        # sgg_table_path = os.path.join(os.path.dirname(__file__), '../utils/', 'adm_sgg.csv')
        # self.sgg_table = pd.read_csv(sgg_table_path, header=0, encoding='cp949', dtype=str)

        sggNm = [u'강남구', u'강동구', u'강북구', u'강서구', u'관악구', u'광진구', u'구로구', u'금천구', u'노원구', u'도봉구', u'동대문구', u'동작구',
                 u'마포구', u'서대문구', u'서초구', u'성동구', u'성북구', u'송파구', u'양천구', u'영등포구', u'용산구', u'은평구', u'종로구', u'중구',
                 u'중랑구']
        defacto_cd = ['11680', '11740', '11305', '11500', '11620', '11215', '11530', '11545', '11350', '11320', '11230',
                      '11590', '11440', '11410', '11650', '11200', '11290', '11710', '11470', '11560', '11170', '11380',
                      '11110', '11140', '11260']
        adm_cd = ['11230', '11250', '11090', '11160', '11210', '11050', '11170', '11180', '11110', '11100', '11060',
                  '11200', '11140', '11130', '11220', '11040', '11080', '11240', '11150', '11190', '11030', '11120',
                  '11010', '11020', '11070']

        self.sgg_table = pd.DataFrame(list(zip(sggNm, defacto_cd, adm_cd)), columns=['sggNm', 'defacto_cd', 'adm_cd'])
        self.sgg_nm_list = self.sgg_table.sggNm.tolist()
        self.sgg_cd_list = self.sgg_table.adm_cd.tolist()
        self.guCB.addItems(self.sgg_nm_list)
        self.guCB.setCurrentIndex(-1)

        if datetime.now().hour >= 9:
            self.max_date = QDate.currentDate().addDays(-5)
        else:
            self.max_date = QDate.currentDate().addDays(-6)
        min_date = QDate(2017, 1, 1)
        self.dateFrom.setDate(self.max_date.addDays(-7))
        self.dateFrom.setDateRange(min_date, self.max_date)
        self.dateTo.setDate(self.max_date)
        self.dateTo.setDateRange(min_date, self.max_date)

        on_panel_icon = QIcon(os.path.dirname(__file__) + '../../icons/histogram.svg')
        self.onPanelBtn.setIcon(on_panel_icon)
        on_browser_icon = QIcon(os.path.dirname(__file__) + '../../icons/browser.svg')
        self.onBrowserBtn.setIcon(on_browser_icon)
        export_icon = QIcon(os.path.dirname(__file__) + '../../icons/csv.svg')
        self.exportBtn.setIcon(export_icon)
        flash_icon = QIcon(os.path.dirname(__file__) + '../../icons/flash.svg')
        self.flashBtn.setIcon(flash_icon)
        self.graph_dlg = None

        # load the webview of the population plot
        self.pop_webview_layout = QVBoxLayout()
        self.pop_webview_layout.setContentsMargins(0, 0, 0, 0)
        self.pop_panel.setLayout(self.pop_webview_layout)
        self.pop_webview = QWebView()
        self.pop_webview.page().setNetworkAccessManager(QgsNetworkAccessManager.instance())
        pop_webview_settings = self.pop_webview.settings()
        pop_webview_settings.setAttribute(QWebSettings.WebGLEnabled, True)
        pop_webview_settings.setAttribute(QWebSettings.DeveloperExtrasEnabled, True)
        pop_webview_settings.setAttribute(QWebSettings.Accelerated2dCanvasEnabled, True)
        self.pop_webview_layout.addWidget(self.pop_webview)

        # Connect signals
        self.weekSB.valueChanged.connect(lambda val: self.change_span('w', val))
        self.monthSB.valueChanged.connect(lambda val: self.change_span('m', val))
        self.quarterSB.valueChanged.connect(lambda val: self.change_span('q', val))
        self.yearSB.valueChanged.connect(lambda val: self.change_span('y', val))
        self.settingBtn.clicked.connect(self.defacto_setting)
        self.unitCB.currentIndexChanged.connect(self.change_sgg)
        self.loadMapPB.clicked.connect(self.map_worker)

        # 데이터 로딩
        self.ageRangeChk.toggled.connect(self.toggle_age)
        self.timeRangeChk.toggled.connect(self.toggle_time)
        self.timeSpanCB.currentIndexChanged.connect(self.change_time)
        self.popMeasureCB.currentIndexChanged.connect(self.change_time)
        self.aggCB.currentIndexChanged.connect(self.change_time)
        self.cancel_button.clicked.connect(self.kill_worker)
        self.ok_button.clicked.connect(self.layer_worker)

        self.iface.layerTreeView().currentLayerChanged.connect(self.change_active_layer)
        self.onPanelBtn.clicked.connect(self.launch_graph)
        self.onBrowserBtn.clicked.connect(self.load_plot_browser)
        self.rampCB.currentIndexChanged.connect(self.change_time)
        self.invertChk.toggled.connect(self.change_time)
        self.trellisBtn.clicked.connect(lambda: self.trellis('screen'))
        self.trellisSave.clicked.connect(self.trellis_save)
        self.playPB.clicked.connect(self.init_change_time)
        self.stopPB.clicked.connect(self.terminate_change_time)
        self.sggCB.currentIndexChanged.connect(self.sgg_change)
        self.emdCB.currentIndexChanged.connect(self.emd_change)
        self.trackCB.currentIndexChanged.connect(lambda: self.get_target_admin(2))
        self.flashBtn.clicked.connect(self.flash_feat)
        self.exportBtn.clicked.connect(self.export_csv)
        self.getFeatureBtn.clicked.connect(self.get_clicked_features)

    # end of __init__

    def change_span(self, unit, val):
        self.dateTo.setDate(self.max_date)
        if unit == 'w':
            self.dateFrom.setDate(self.max_date.addDays(-7*val))
        elif unit == 'm':
            self.dateFrom.setDate(self.max_date.addMonths(-val))
        elif unit == 'q':
            self.dateFrom.setDate(self.max_date.addMonths(-3*val))
        elif unit == 'y':
            self.dateFrom.setDate(self.max_date.addYears(-val))

    def init_setting(self):
        if_ready = [False, False, False, False, False]
        # consumer key, consumer secret
        self.consumer_key = self.qst.value('urban_data_provider/consumerKey')
        if self.consumer_key:
            if_ready[0] = True
        self.consumer_secret = self.qst.value('urban_data_provider/consumerSecret')
        if self.consumer_secret:
            if_ready[1] = True

        # defacto key
        self.defacto_key = self.qst.value('urban_data_provider/defactoKey')
        if self.defacto_key:
            if_ready[2] = True

        # db Root
        self.db_path = self.qst.value('urban_data_provider/dbPath')
        admin_boundary = ''
        if self.db_path and os.path.isdir(self.db_path):
            if_ready[3] = True
            admin_boundary = os.path.join(self.db_path, 'seoul.gpkg')
        if if_ready[3] and os.path.isfile(admin_boundary):
            conn = sqlite3.connect(admin_boundary)
            cursor = conn.cursor()
            sql = """Select table_name from gpkg_contents"""
            cursor.execute(sql)
            rows = cursor.fetchall()
            if len(rows) == 3:
                if_ready[4] = True
            cursor.close()
            conn.close()
        if False in if_ready:
            self.loadMapPB.setEnabled(False)
            self.mapGB.setTitle(u'오른쪽 버튼을 눌러 설정을 완료하세요!')
        else:
            self.loadMapPB.setEnabled(True)
            self.mapGB.setTitle(u'새 지도 레이어 추가')

    def defacto_setting(self):
        dlg = DefactoSetting(self)
        if dlg.exec_():
            self.init_setting()

    def change_sgg(self, current_idx):
        if current_idx is not 2:
            self.guCB.setCurrentIndex(-1)
            self.guCB.setEnabled(False)
        else:
            self.guCB.setCurrentIndex(0)
            self.guCB.setEnabled(True)

    def toggle_age(self, checked):
        if checked:
            self.ageRangeCB.setEnabled(True)
            self.ageUnitCB.setEnabled(False)
            self.ageUnitCB.deselectAllOptions()
        else:
            self.ageRangeCB.setEnabled(False)
            self.ageUnitCB.setEnabled(True)

    def toggle_time(self, checked):
        if checked:
            self.timeRangeCB.setEnabled(True)
            self.timeUnitCB.setEnabled(False)
            self.timeUnitCB.deselectAllOptions()
        else:
            self.timeRangeCB.setEnabled(False)
            self.timeUnitCB.setEnabled(True)

    def data_loading(self, search_table, search_type, search_unit, search_date, db_path):
        dlg = DataLoading('span', self.current_layer, parent=self)
        if dlg.exec_():
            self.ignore_missing = dlg.ignore_missing
            self.map_worker()
        else:
            self.loadMapPB.setEnabled(True)

    def map_worker(self):
        self.loadMapPB.setEnabled(False)
        date_from = self.dateFrom.date().toString("yyyyMMdd")
        date_to = self.dateTo.date().toString("yyyyMMdd")
        search_date = date_from + '~' + date_to
        defacto_db = os.path.join(self.db_path, 'defacto.db')
        search_type = self.typeCB.currentIndex()
        search_unit = self.unitCB.currentIndex()
        if search_type == 0:
            profile = self.col_names_local[1:]
            search_type_nm = u'내국인'
            suffix = '_local'
        elif search_type == 1:
            profile = self.col_names_foreign[1:]
            search_type_nm = u'외국인(장기)'
            suffix = '_foreign_long'
        else:
            profile = self.col_names_foreign[1:]
            search_type_nm = u'외국인(단기)'
            suffix = '_foreign_temp'
        if search_unit == 0:
            prefix = 'sgg'
            base_name = search_type_nm + "_" + u'자치구'
        elif search_unit == 1:
            prefix = 'emd'
            base_name = search_type_nm + "_" + u'행정동'
        else:
            prefix = 'track'
            base_name = search_type_nm + "_" + u'집계구' + '(' + self.guCB.currentText() + ')'
        search_table = prefix + suffix
        sql = 'select distinct date from ' + search_table + ' where date >= ? and date <=?'
        date_range = pd.date_range(date_from, date_to, name='date').to_frame(index=False)
        date_range['date'] = date_range['date'].dt.strftime('%Y%m%d')
        conn = sqlite3.connect(defacto_db)
        try:
            date_table = pd.read_sql(sql, conn, params=(date_from, date_to,))
            conn.close()
        except Exception:
            self.data_loading(search_table, search_type, search_unit, date_range['date'].to_list(), self.db_path)
        else:
            date_missing = date_range[~date_range['date'].isin(date_table['date'])]
            date_missing = date_missing['date'].to_list()
            QgsMessageLog.logMessage(str(date_missing))
            if len(date_missing) > 0 and self.ignore_missing is False:
                self.data_loading(search_table, search_type, search_unit, date_missing, self.db_path)
            else:
                if self.graph_dlg is not None:
                    self.graph_dlg.close()
                self.ok_button.setEnabled(False)
                self.cancel_button.setEnabled(True)

                # progressBar
                progressMessageBar = self.iface.messageBar().createMessage(u"새 지도 추가:", "연결 중...")
                progress = QProgressBar()
                progress.setMaximum(100)
                progress.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                progress_cancel = QPushButton()
                progress_cancel.setText('Cancel')
                progress_cancel.clicked.connect(self.kill_worker)
                progressMessageBar.layout().addWidget(progress)
                progressMessageBar.layout().addWidget(progress_cancel)
                self.msg_bar = self.iface.messageBar()
                self.msg_bar.pushWidget(progressMessageBar, Qgis.Info)
                self.msg_bar.findChildren(QToolButton)[0].setHidden(True)

                # start the worker in a new thread
                params = {
                    'search_date': search_date,
                    'layer_name': base_name + '_' + date_to,
                    'profile': profile,
                    'db_path': self.db_path,
                    'search_type': search_type,
                    'search_unit': search_unit,
                    'sgg_idx': self.guCB.currentIndex(),
                    'sgg_cd': self.sgg_cd_list[self.guCB.currentIndex()],
                    'search_table': search_table
                }
                self.worker = MapOnCanvas(params)
                self.worker.step_changed.connect(progressMessageBar.setText)
                self.worker.progressChanged.connect(progress.setValue)
                self.worker.layerCompleted.connect(self.add_map)
                self.worker.taskCompleted.connect(lambda: self.finish_map_worker(True))
                self.worker.taskTerminated.connect(lambda: self.finish_map_worker(False))
                QgsApplication.taskManager().addTask(self.worker)

    def finish_map_worker(self, status):
        self.msg_bar.findChildren(QToolButton)[0].setHidden(False)
        self.msg_bar.clearWidgets()
        if status:
            self.iface.messageBar().pushSuccess(u'새 지도 추가', u'완료')
        else:
            self.iface.messageBar().pushMessage("Critical:", u'취소 완료', level=Qgis.Critical, duration=5)
        self.loadMapPB.setEnabled(True)

    def add_map(self, feats, params):
        vlayer = QgsVectorLayer("Polygon?crs=epsg:5179", params['layer_name'], "memory")

        # setting custom properties
        layer_properties = QgsObjectCustomProperties()
        layer_properties.setValue('defacto_time', '')
        layer_properties.setValue('current_layer_id', vlayer.id())
        layer_properties.setValue('db_path', params['db_path'])
        layer_properties.setValue('search_table', params['search_table'])
        layer_properties.setValue('search_type', params['search_type'])
        layer_properties.setValue('search_unit', params['search_unit'])
        layer_properties.setValue('search_date', params['search_date'])
        layer_properties.setValue('sgg_idx', params['sgg_idx'])
        layer_properties.setValue('sgg_cd', params['sgg_cd'])
        layer_properties.setValue('layer_name', params['layer_name'])
        layer_properties.setValue('profile', params['profile'])
        layer_properties.setValue('age_type', 0 if params['search_type'] == 0 else 1)
        layer_properties.setValue('age_range', 0)
        layer_properties.setValue('age_unit', [])
        layer_properties.setValue('gender_type', 0)
        layer_properties.setValue('time_type', 0)
        layer_properties.setValue('time_range', 0)
        layer_properties.setValue('time_unit', [])
        layer_properties.setValue('time_agg', 0)
        layer_properties.setValue('target_age', '')
        layer_properties.setValue('target_hours', self.search_hour_range)
        layer_properties.setValue('agg_type', 'time')
        layer_properties.setValue('first_admin', feats[0].attributes()[2])
        layer_properties.setValue('dates_available', True)
        layer_properties.setValue('defacto_loaded', False)
        layer_properties.setValue('admin_sgg', self.guCB.currentText())
        layer_properties.setValue('admin_emd', '')
        layer_properties.setValue('admin_track', '')
        vlayer.setCustomProperties(layer_properties)

        # start editing
        vlayer.startEditing()
        pr = vlayer.dataProvider()
        pr.truncate()
        defacto_fields = [QgsField(u'adm_cd', QVariant.String),
                          QgsField(u'adm_nm', QVariant.String),
                          QgsField(u'defacto_cd', QVariant.String)
                          ]
        pr.addAttributes(defacto_fields)
        vlayer.updateFields()
        pr.addFeatures(feats)
        vlayer.commitChanges()
        self.zoom_to_layer(vlayer)
        # self.toggle_buttons(vlayer.id())

    def zoom_to_layer(self, vlayer):
        project = QgsProject.instance()
        project.addMapLayer(vlayer)
        canvas = self.iface.mapCanvas()
        canvas_crs = canvas.mapSettings().destinationCrs()
        xform2_canvas = QgsCoordinateTransform(QgsCoordinateReferenceSystem('EPSG:5179'), canvas_crs,
                                               QgsProject.instance())
        canvas.setExtent(xform2_canvas.transform(vlayer.extent()))
        canvas.refresh()

    def layer_worker(self):
        current_layer = QgsProject.instance().mapLayer(self.current_layer['id'])
        current_properties = current_layer.customProperties()
        if not current_properties.contains('defacto_time'):
            return
        search_date = self.dateFrom.date().toString("yyyyMMdd")
        profile = current_properties.value('profile')
        age_type = 0 if self.ageRangeChk.isChecked() else 1
        age_range = self.ageRangeCB.currentIndex()
        age_unit = self.ageUnitCB.checkedItems()
        gender_type = (self.genderBG.checkedId() * -1) - 2
        time_type = 0 if self.timeRangeChk.isChecked() else 1
        time_range = self.timeRangeCB.currentIndex()
        time_unit = self.timeUnitCB.checkedItems()
        time_agg = (self.time_aggBG.checkedId() * -1) - 2

        if age_type == 1 and not age_unit:
            self.iface.messageBar().pushMessage("Info:", u'연령범위를 선택해주세요.', level=Qgis.Info, duration=5)
            return
        if time_type == 1 and not time_unit:
            self.iface.messageBar().pushMessage("Info:", u'시간범위를 선택해주세요.', level=Qgis.Info, duration=5)
            return

        # target_age
        search_type = current_properties.value('search_type')
        if search_type == 0:
            if age_type == 0:
                if age_range == 0:
                    target_age = profile
                elif age_range == 1:
                    target_age = profile[2:12]
                elif age_range == 2:
                    target_age = profile[:2]
                elif age_range == 3:
                    target_age = profile[12:]
                elif age_range == 4:
                    target_age = profile[1:4]
                elif age_range == 5:
                    target_age = profile[3:6]
            else:
                target_age = self.ageUnitCB.checkedItems()
            male = [u'남' + m for m in target_age]
            female = [u'여' + f for f in target_age]
            if gender_type == 0:
                target_age = male + female
            elif gender_type == 1:
                target_age = male
            elif gender_type == 2:
                target_age = female
        else:
            checked = self.ageUnitCB.checkedItems()
            if checked == [u'중국인', u'비중국인']:
                target_age = ['Chinese', 'non_Chinese']
            elif checked == [u'중국인']:
                target_age = ['Chinese']
            else:
                target_age = ['non_Chinese']

        # target_hours
        if time_type == 0:
            if time_range == 0:
                target_hours = self.search_hour_range
            elif time_range == 1:
                target_hours = self.search_hour_range[9:18]
            elif time_range == 2:
                target_hours = self.search_hour_range[18:]
            elif time_range == 3:
                target_hours = self.search_hour_range[:5]
        else:
            target_hours = self.timeUnitCB.checkedItems()

        # agg_type
        agg_type = 'time' if time_agg == 0 else 'agg'

        # set currnet layer properties
        current_layer.setCustomProperty('search_date', search_date)
        current_layer.setCustomProperty('profile', profile)
        current_layer.setCustomProperty('age_type', age_type)
        current_layer.setCustomProperty('age_range', age_range)
        current_layer.setCustomProperty('age_unit', age_unit)
        current_layer.setCustomProperty('gender_type', gender_type)
        current_layer.setCustomProperty('time_type', time_type)
        current_layer.setCustomProperty('time_range', time_range)
        current_layer.setCustomProperty('time_unit', time_unit)
        current_layer.setCustomProperty('time_agg', time_agg)
        current_layer.setCustomProperty('target_age', target_age)
        current_layer.setCustomProperty('target_hours', target_hours)
        current_layer.setCustomProperty('agg_type', agg_type)
        current_layer.setCustomProperty('admin_sgg', self.sggCB.currentText())
        current_layer.setCustomProperty('admin_emd', self.emdCB.currentText())

        params = {
            'current_layer_id': self.current_layer['id'],
            'db_path': current_properties.value('db_path'),
            'search_type': current_properties.value('search_type'),
            'search_unit': current_properties.value('search_unit'),
            'search_date': search_date,
            'search_table': current_properties.value('search_table'),
            'sgg_cd': current_properties.value('sgg_cd'),
            'target_age': target_age,
            'target_hours': target_hours,
            'agg_type': agg_type
        }

        self.ok_button.setEnabled(False)
        self.cancel_button.setEnabled(True)
        self.trellisBtn.setEnabled(False)

        # start the worker in a new thread
        self.worker = DefactoLayerWorker(params)
        QgsApplication.taskManager().addTask(self.worker)
        self.worker.step_changed.connect(self.stepLB.setText)
        self.worker.progressChanged.connect(self.progressBar.setValue)
        self.worker.layerCompleted.connect(self.fill_defacto)
        self.worker.taskCompleted.connect(self.worker_finished)
        self.worker.taskTerminated.connect(self.worker_finished)

    def fill_defacto(self, feats, current_layer_id):
        vlayer = QgsProject.instance().mapLayer(current_layer_id)
        agg_type = vlayer.customProperty('agg_type')
        if agg_type == 'time':
            field_range = vlayer.customProperty('target_hours')
            self.timeSpanCB.blockSignals(True)
            self.timeSpanCB.clear()
            self.timeSpanCB.addItems(field_range)
            self.timeSpanCB.blockSignals(False)
            self.stackedWidget.setCurrentIndex(0)
        else:
            field_range = self.agg_range
            self.stackedWidget.setCurrentIndex(1)
        fields_to_delete = vlayer.attributeList()
        vlayer.startEditing()
        pr = vlayer.dataProvider()
        pr.truncate()
        pr.deleteAttributes(fields_to_delete)
        vlayer.updateFields()
        field = [QgsField(h, QVariant.Int) for h in field_range]
        defacto_fields = [QgsField(u'adm_cd', QVariant.String),
                          QgsField(u'adm_nm', QVariant.String),
                          QgsField(u'defacto_cd', QVariant.String)
                          ] + field
        pr.addAttributes(defacto_fields)
        vlayer.updateFields()
        pr.addFeatures(feats)
        vlayer.commitChanges()
        if vlayer.customProperty('defacto_loaded'):
            self.change_time()
        else:
            vlayer.setCustomProperty('defacto_loaded', True)
            self.change_active_layer(vlayer)
        self.zoom_to_layer(vlayer)

    def worker_finished(self):
        self.ok_button.setEnabled(True)
        self.cancel_button.setEnabled(False)
        self.trellisBtn.setEnabled(True)
        self.progressBar.setValue(0)
        self.stepLB.setText(u'완료!')

    def change_active_layer(self, vlayer):
        if vlayer is None:
            return
        else:
            current_properties = vlayer.customProperties()
            if not current_properties.contains('defacto_time'):
                self.popSpanGB.setEnabled(False)
                self.timeGB.setEnabled(False)
                self.aggGB.setEnabled(False)
                self.gradGB.setEnabled(False)
                self.trellisGB.setEnabled(False)
                self.adminGB.setEnabled(False)
                self.trellisBtn.setEnabled(False)
                self.ok_button.setEnabled(False)
                self.cancel_button.setEnabled(False)
                return
            else:
                self.popSpanGB.setEnabled(True)
                self.current_layer = {
                    'id': vlayer.id(),
                    'db_path': current_properties.value('db_path'),
                    'search_type': current_properties.value('search_type'),
                    'search_unit': current_properties.value('search_unit'),
                    'search_date': current_properties.value('search_date'),
                    'search_table': current_properties.value('search_table'),
                    'profile': current_properties.value('profile'),
                    'age_type': current_properties.value('age_type'),
                    'age_range': current_properties.value('age_range'),
                    'age_unit': current_properties.value('age_unit'),
                    'gender_type': current_properties.value('gender_type'),
                    'time_type': current_properties.value('time_type'),
                    'time_range': current_properties.value('time_range'),
                    'time_unit': current_properties.value('time_unit'),
                    'time_agg': current_properties.value('time_agg'),
                    'target_age': current_properties.value('target_age'),
                    'target_hours': current_properties.value('target_hours'),
                    'agg_type': current_properties.value('agg_type'),
                    'sgg_cd': current_properties.value('sgg_cd'),
                    'sgg_idx': current_properties.value('sgg_idx'),
                    'layer_name': vlayer.name(),
                    'first_admin': current_properties.value('first_admin'),
                    'dates_available': current_properties.value('dates_available'),
                    'defacto_loaded': current_properties.value('defacto_loaded'),
                    'admin_sgg': current_properties.value('admin_sgg'),
                    'admin_emd': current_properties.value('admin_emd'),
                    'admin_track': current_properties.value('admin_track')
                }

                # reset data selection buttons and CB
                # 내국인-외국인 구분
                self.ageUnitCB.clear()
                if self.current_layer['search_type'] == 0:
                    self.ageRangeChk.setEnabled(True)
                    self.ageUnitCB.setDefaultText(u'연령별 선택')
                    self.ageUnitCB.addItems(current_properties.value('profile'))
                    self.gender_all.setEnabled(True)
                    self.gender_male.setEnabled(True)
                    self.gender_female.setEnabled(True)
                else:
                    self.ageRangeChk.setEnabled(False)
                    self.ageUnitCB.setDefaultText(u'국적별 선택')
                    self.ageUnitCB.addItems([u'중국인', u'비중국인'])
                    self.gender_all.setEnabled(False)
                    self.gender_male.setEnabled(False)
                    self.gender_female.setEnabled(False)

                # 연령-성별 구분
                if self.current_layer['age_type'] == 0:
                    self.ageRangeChk.setChecked(True)
                    self.ageUnitCB.setEnabled(False)
                else:
                    self.ageUnitChk.setChecked(True)
                    self.ageRangeCB.setEnabled(False)
                self.ageRangeCB.setCurrentIndex(self.current_layer['age_range'])
                self.ageUnitCB.setCheckedItems(self.current_layer['age_unit'])
                self.genderBG.button(self.current_layer['gender_type'] * -1 - 2).setChecked(True)

                # 시간-집계 구분
                self.timeUnitCB.clear()
                self.timeUnitCB.addItems(self.search_hour_range)
                self.timeRangeChk.setChecked(self.current_layer['time_type'])
                if self.current_layer['time_type'] == 0:
                    self.timeRangeChk.setChecked(True)
                    self.timeUnitCB.setEnabled(False)
                else:
                    self.timeUnitChk.setChecked(True)
                    self.timeRangeCB.setEnabled(False)
                self.timeRangeCB.setCurrentIndex(self.current_layer['time_range'])
                self.timeUnitCB.setCheckedItems(self.current_layer['time_unit'])
                self.time_aggBG.button(self.current_layer['time_agg'] * -1 - 2).setChecked(True)

                # Toggle Result View Group Boxed
                if not current_properties.value('defacto_loaded'):
                    # self.iface.messageBar().pushMessage(u"완료:", u'새 지도가 추가되었습니다.', level=Qgis.Info, duration=5)
                    self.timeGB.setEnabled(False)
                    self.aggGB.setEnabled(False)
                    self.gradGB.setEnabled(False)
                    self.trellisGB.setEnabled(False)
                    self.adminGB.setEnabled(False)
                    self.trellisBtn.setEnabled(False)
                else:
                    agg_type = current_properties.value('agg_type')
                    # self.timeSpanGB.setEnabled(True)
                    self.stackedWidget.setCurrentIndex(0) if agg_type == 'time' else self.stackedWidget.setCurrentIndex(
                        1)
                    self.timeGB.setEnabled(True) if agg_type == 'time' else self.timeGB.setEnabled(False)
                    self.aggGB.setEnabled(True) if agg_type == 'time' else self.aggGB.setEnabled(False)
                    self.gradGB.setEnabled(True)
                    self.trellisGB.setEnabled(True)
                    self.adminGB.setEnabled(True)
                    self.trellisBtn.setEnabled(True)
                    self.timeSpanCB.blockSignals(True)
                    self.timeSpanCB.clear()
                    self.timeSpanCB.addItems(self.current_layer['target_hours'])
                    self.timeSpanCB.blockSignals(False)
                    self.change_time()
                    self.adminGB.setTitle(u'생활인구 통계:' + self.current_layer['layer_name'])
                    self.iface.messageBar().pushMessage(u"완료:", u'데이터가 업데이트 되었습니다.', level=Qgis.Info, duration=5)
                self.ok_button.setEnabled(True)
                self.load_table()

    def change_time(self):
        vlayer = QgsProject.instance().mapLayer(self.current_layer['id'])
        current_properties = vlayer.customProperties()
        if not current_properties.contains('defacto_time'):
            return
        target_field = self.timeSpanCB.currentText() if current_properties.value(
            'agg_type') == 'time' else self.aggCB.currentText()
        pop_measure = self.popMeasureCB.currentIndex()
        expression = target_field if pop_measure == 0 else '"' + target_field + '"' + '/area($geometry)'
        ramp_type = self.rampCB.currentText()
        invert = True if self.invertChk.isChecked() else False
        style_renderer = graduated_symbol(target_field=expression, ramp_type=ramp_type, invert=invert, opacity=1.0,
                                          mode='jenks')
        style_renderer.updateClasses(vlayer, 10)
        vlayer.setRenderer(style_renderer)
        vlayer.triggerRepaint()
        self.iface.layerTreeView().refreshLayerSymbology(vlayer.id())

    def change_time_cb(self):
        self.timeSpanCB.blockSignals(True)
        self.timeSpanCB.setCurrentIndex(-1)
        self.timeSpanCB.blockSignals(False)
        canvas = self.iface.mapCanvas()
        interval = self.spinBox.value()
        for i in range(self.timeSpanCB.count()):
            if not self.time_flag:
                break
            self.timeSpanCB.setCurrentIndex(i)
            sub_txt = QGraphicsTextItem(self.timeSpanCB.currentText() + u'시')
            font = sub_txt.font()
            font.setPointSize(30)
            sub_txt.setFont(font)
            canvas.scene().addItem(sub_txt)
            sleep(interval)
            canvas.scene().removeItem(sub_txt)
        self.stopPB.click()

    def init_change_time(self):
        self.playPB.setEnabled(False)
        self.time_flag = True
        th = Thread(target=self.change_time_cb)
        th.start()

    def terminate_change_time(self):
        self.playPB.setEnabled(True)
        self.time_flag = False

    def trellis(self, target):
        vlayer = QgsProject.instance().mapLayer(self.current_layer['id'])
        current_properties = vlayer.customProperties()
        layer_name = vlayer.customProperty('layer_name')
        agg_type = vlayer.customProperty('agg_type')
        if not current_properties.contains('defacto_time'):
            return
        w_h_ratio = vlayer.extent().width() / vlayer.extent().height()
        screen_width = self.screen().size().width()
        screen_height = self.screen().size().height()
        n_cells = len(vlayer.customProperty('target_hours'))
        if w_h_ratio > 1:
            cell_width = screen_width / 6 * 0.9
            cell_height = cell_width / w_h_ratio
        else:
            cell_height = screen_height / 4 * 0.9
            cell_width = cell_height * w_h_ratio
        cols = 6 if n_cells >= 6 else n_cells
        rows = (n_cells - 1) // 6 + 1
        if agg_type == 'agg':
            cols = 4
            rows = 3
        self.trellis_dlg = QWidget(parent=None)
        self.trellis_dlg.setWindowTitle(layer_name)
        layout = QGridLayout()
        layout.setHorizontalSpacing(1)
        layout.setVerticalSpacing(1)
        self.trellis_dlg.resize(cell_width * cols, cell_height * rows)

        # map setting
        ms = QgsMapSettings()
        ms.setLayers([vlayer])
        rect = QgsRectangle(ms.fullExtent())
        rect.scale(1.1)
        ms.setExtent(rect)
        if target == 'screen':
            mult = 1
        else:
            mult = 10
            # progressBar
            self.iface.messageBar().pushSuccess(u'저장:', u'Start')
            progress_message_bar = self.iface.messageBar().createMessage(u"저장: ", "저장 중...")
            progress = QProgressBar()
            progress.setMaximum(100)
            progress.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            progress_message_bar.layout().addWidget(progress)
            self.msg_bar = self.iface.messageBar()
            self.msg_bar.pushWidget(progress_message_bar, Qgis.Info)
            self.msg_bar.findChildren(QToolButton)[0].setHidden(True)

        img = QImage(cell_width * mult, cell_height * mult, QImage.Format_ARGB32_Premultiplied)

        color = QColor(0, 0, 0, 255)
        ms.setBackgroundColor(color)
        img.fill(color.rgba())
        p = QPainter()
        ms.setOutputSize(img.size())

        to_loop = vlayer.customProperty('target_hours') if agg_type == 'time' else self.agg_range
        for i, lp in enumerate(to_loop):
            r = i // cols + 1
            c = i % cols + 1
            if agg_type == 'time':
                self.timeSpanCB.setCurrentIndex(i)
            else:
                self.aggCB.setCurrentIndex(i)
            render = QgsMapRendererCustomPainterJob(ms, p)
            p.begin(img)
            p.setRenderHint(QPainter.Antialiasing)
            render.start()
            render.waitForFinished()
            p.setPen(Qt.white)
            p.setFont(QFont('Courier New', 10 * mult))
            p.drawText(3 * mult, 15 * mult, str(lp))
            p.end()
            pmap = QPixmap(img)
            if target == 'screen':
                label = QLabel()
                label.resize(cell_width, cell_height)
                label.setStyleSheet("QLabel { background-color : black; }")
                label.setPixmap(pmap)
                label.setAlignment(Qt.AlignCenter)
                layout.addWidget(label, r, c)
                layout.setAlignment(Qt.AlignTop)
            else:
                pmap.save(target + '/' + layer_name + '_' + str(lp) + ".png", "PNG")
                progress.setValue(int((i + 1) / n_cells * 100))

        if target == 'screen':
            self.trellis_dlg.setLayout(layout)
            self.trellis_dlg.show()
        else:
            self.msg_bar.findChildren(QToolButton)[0].setHidden(False)
            self.msg_bar.clearWidgets()
            self.iface.messageBar().pushSuccess(u'저장:', u'완료')

    def trellis_save(self):
        export_to = str(QFileDialog.getExistingDirectory(self, "Select Directory"))
        if export_to:
            self.trellis(export_to)
            self.qst.setValue('urban_data_provider/defactoGraphPath', export_to)

    def load_table(self):
        vlayer = QgsProject.instance().mapLayer(self.current_layer['id'])
        self.current_unit = self.current_layer['search_unit']
        self.sggCB.blockSignals(True)
        self.emdCB.blockSignals(True)
        self.trackCB.blockSignals(True)
        self.sggCB.clear()
        self.emdCB.clear()
        self.trackCB.clear()
        self.sggCB.addItems(self.sgg_nm_list)
        self.sggCB.setCurrentIndex(-1)
        if not self.current_layer['defacto_loaded']:
            self.defactoTbl.clear()
            self.adminGB.setEnabled(False)
            return

        # adm_table
        rows = []
        for f in vlayer.getFeatures():
            attrs = [f.attributes()[2]]
            adm_split = f.attributes()[1].split(' ')
            if self.current_unit == 0:
                attrs.append(adm_split[1])
            elif self.current_unit == 1:
                attrs.append(adm_split[1])
                attrs.append(adm_split[2])
            else:
                attrs.append(adm_split[0])
            rows.append(attrs)
        if self.current_unit == 0:
            columns = ['defacto_cd', 'sgg_nm']
            self.sggCB.setEnabled(True)
            self.emdCB.setEnabled(False)
            self.trackCB.setEnabled(False)
        elif self.current_unit == 1:
            columns = ['defacto_cd', 'sgg_nm', 'emd_nm']
            self.sggCB.setEnabled(True)
            self.emdCB.setEnabled(True)
            self.trackCB.setEnabled(False)
        else:
            columns = ['defacto_cd', 'emd_nm']
            self.sggCB.setEnabled(False)
            self.emdCB.setEnabled(True)
            self.trackCB.setEnabled(True)
        self.adm_table = pd.DataFrame(data=rows, columns=columns)
        self.sggCB.blockSignals(False)
        self.emdCB.blockSignals(False)
        self.trackCB.blockSignals(False)

        # trigger populating CBs and launch_table()
        current_sgg_idx = 0 if self.current_unit != 2 else self.current_layer['sgg_idx']
        self.sggCB.setCurrentIndex(current_sgg_idx)
        self.adminGB.setEnabled(True)

    def sgg_change(self):
        self.sgg_nm = self.sggCB.currentText()
        if self.current_unit == 0:
            self.get_target_admin(0)
        elif self.current_unit == 1:
            self.emdCB.blockSignals(True)
            self.emdCB.clear()
            self.emdCB.blockSignals(False)
            emd_nm_list = self.adm_table.loc[(self.adm_table['sgg_nm'] == self.sgg_nm)]['emd_nm'].tolist()
            self.emdCB.addItems(emd_nm_list)
        else:
            emd_nm_list = self.adm_table['emd_nm'].unique().tolist()
            self.emdCB.addItems(emd_nm_list)

    def emd_change(self):
        self.emd_nm = self.emdCB.currentText()
        if self.current_unit == 1:
            self.get_target_admin(1)
        elif self.current_unit == 2:
            self.trackCB.blockSignals(True)
            self.trackCB.clear()
            self.trackCB.blockSignals(False)
            track_nm_list = self.adm_table.loc[(self.adm_table['emd_nm'] == self.emd_nm)]['defacto_cd'].tolist()
            self.trackCB.addItems(track_nm_list)

    def get_clicked_features(self):
        self.select_tool = SelectTool(self.iface)
        self.iface.mapCanvas().setMapTool(self.select_tool)
        self.select_tool.featureClicked.connect(self.changed_admin)

    def changed_admin(self, feat):
        if len(feat) == 0:
            self.iface.mapCanvas().unsetMapTool(self.select_tool)
            return
        else:
            clicked_admin = feat[0].mFeature.attributes()[1]
            if self.current_unit == 0:
                sgg = clicked_admin.split()[1]
                self.sggCB.setCurrentText(sgg)
            elif self.current_unit == 1:
                self.sgg_nm = clicked_admin.split()[1]
                self.emd_nm = clicked_admin.split()[2]
                self.sggCB.blockSignals(True)
                self.emdCB.blockSignals(True)
                self.sggCB.setCurrentText(self.sgg_nm)
                self.emdCB.clear()
                emd_nm_list = self.adm_table.loc[(self.adm_table['sgg_nm'] == self.sgg_nm)]['emd_nm'].tolist()
                self.emdCB.addItems(emd_nm_list)
                self.emdCB.setCurrentIndex(-1)  # 첫번째 행정구역 클릭 시에도 액션될 수 있도록
                self.emdCB.blockSignals(False)
                self.sggCB.blockSignals(False)
                self.emdCB.setCurrentText(self.emd_nm)
            else:
                self.emd_nm = clicked_admin.split()[0]
                track = feat[0].mFeature.attributes()[2]
                self.emdCB.blockSignals(True)
                self.trackCB.blockSignals(True)
                self.emdCB.setCurrentText(self.emd_nm)
                self.trackCB.clear()
                track_nm_list = self.adm_table.loc[(self.adm_table['emd_nm'] == self.emd_nm)]['defacto_cd'].tolist()
                self.trackCB.addItems(track_nm_list)
                self.trackCB.setCurrentIndex(-1)  # 첫번째 행정구역 클릭 시에도 액션될 수 있도록
                self.trackCB.blockSignals(False)
                self.emdCB.blockSignals(False)
                self.trackCB.setCurrentText(track)
            self.iface.mapCanvas().unsetMapTool(self.select_tool)

    def get_target_admin(self, current_unit):
        if current_unit == 0:
            self.target_admin = self.adm_table.loc[self.adm_table['sgg_nm'] == self.sgg_nm].iloc[0, 0]
            self.target_admin_nm = self.sgg_nm
        elif current_unit == 1:
            # emd_nm = self.emdCB.currentText()
            self.target_admin = \
                self.adm_table.loc[
                    (self.adm_table['sgg_nm'] == self.sgg_nm) & (self.adm_table['emd_nm'] == self.emd_nm)].iloc[0, 0]
            self.target_admin_nm = self.sgg_nm + ' ' + self.emd_nm
        elif current_unit == 2:
            self.target_admin = self.trackCB.currentText()
            self.target_admin_nm = self.sgg_nm + ' ' + self.emd_nm + ' ' + self.target_admin
        self.launch_table()

    def launch_table(self):
        current_table = self.current_layer['search_table']
        current_date = self.current_layer['search_date']
        conn = sqlite3.connect(self.db_path + '/defacto.db')
        sql = 'select * from ' + current_table + ' where keyAdmin = ? and date = ?'
        self.defacto_pop = pd.read_sql(sql, conn, params=(self.target_admin, current_date))
        conn.close()
        self.defacto_pop.drop(['date', 'keyAdmin'], axis=1, inplace=True)
        rows = self.defacto_pop.shape[0]
        if rows < 24:
            time_list = list(self.defacto_pop['time'])
            dummy_cols = list(self.defacto_pop.columns)
            r = []
            for h in self.search_hour_range:
                if h not in time_list:
                    zeros = [h] + [0] * (len(dummy_cols) - 1)
                    r.append(zeros)
                else:
                    pass
            dummy_df = pd.DataFrame(data=r, columns=dummy_cols)
            self.defacto_pop = pd.concat([self.defacto_pop, dummy_df])
            self.defacto_pop.sort_values('time', inplace=True, ignore_index=True)
        cols = self.defacto_pop.shape[1] - 1  # 첫 컬럼(time) 제외
        self.defactoTbl.setRowCount(24)
        self.defactoTbl.setColumnCount(cols)
        self.defactoTbl.setHorizontalHeaderLabels(self.defacto_pop.columns[1:])
        self.defactoTbl.setVerticalHeaderLabels(self.search_hour_range)
        for row in self.defacto_pop.iloc[:, 1:].itertuples():
            for col in range(0, cols):
                item = QTableWidgetItem('{:,.0f}'.format(row[col + 1]))  # index 컬럼 제외
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.defactoTbl.setItem(row.Index, col, item)
        self.tabWidget.setTabText(0, u'생활인구표(' + self.target_admin_nm + ')')
        self.tabWidget.setCurrentIndex(0)
        self.onPanelBtn.setEnabled(True)
        self.exportBtn.setEnabled(True)
        self.flash_feat()

    def flash_feat(self):
        layer = QgsProject.instance().mapLayer(self.current_layer['id'])
        expression = QgsExpression(u'defacto_cd=' + self.target_admin)
        request = QgsFeatureRequest(expression)
        f_ids = [f.id() for f in layer.getFeatures(request)]
        self.iface.mapCanvas().flashFeatureIds(layer, f_ids, QColor(255, 255, 0, 255),
                                               QColor(255, 255, 0, 0), flashes=5, duration=500)

    def launch_graph(self):
        search_date = self.current_layer['search_date']
        search_type = self.current_layer['search_type']
        self.onPanelBtn.setEnabled(False)
        self.graph_dlg = GraphPanel(search_date, search_type, parent=self)
        self.graph_dlg.graph_launched.connect(self.create_graph)
        self.graph_dlg.closing_panel.connect(self.activate_button)

    def activate_button(self):
        self.onPanelBtn.setEnabled(True)

    def create_graph(self, params):
        self.tabWidget.setTabText(1, u'그래프(' + self.target_admin_nm + ')')
        self.tabWidget.setCurrentIndex(1)
        title = params["title"]
        search_type = params["search_type"]
        time_span = params["time_span"]
        age_range = params["age_range"]
        chart_type = params["chart_type"]
        flip_xy = params["flip_xy"]
        profile_type = params["profile_type"]
        age_male = range(age_range.start + 2, age_range.stop + 2)  # ['time', '총생활인구']
        age_female = range(age_range.start + 16, age_range.stop + 16)

        if search_type == 0:
            defacto_male = self.defacto_pop.iloc[time_span, age_male]
            defacto_female = self.defacto_pop.iloc[time_span, age_female]
            if profile_type == 0:
                graph_pop = [defacto_male, defacto_female]
            elif profile_type == 1:
                # 합산을 위한 컬럼명 일치
                defacto_male.columns = [sub[1:] for sub in defacto_male.columns]
                defacto_female.columns = defacto_male.columns
                graph_pop = [defacto_male.add(defacto_female, fill_value=0)]
            elif profile_type == 2:
                graph_pop = [defacto_male]
            elif profile_type == 3:
                graph_pop = [defacto_female]
        else:
            defacto_china = self.defacto_pop.iloc[time_span, 2:3]
            defacto_others = self.defacto_pop.iloc[time_span, 3:4]
            if profile_type == 0:
                graph_pop = [defacto_china, defacto_others]
            elif profile_type == 1:
                defacto_china.columns = [u'외국인(장기)'] if search_type == 1 else [u'외국인(단기)']
                defacto_others.columns = defacto_china.columns
                graph_pop = [defacto_china.add(defacto_others, fill_value=0)]
            elif profile_type == 2:
                graph_pop = [defacto_china]
            elif profile_type == 3:
                graph_pop = [defacto_others]

        loader_path = os.path.join(os.path.dirname(__file__), '../utils/plot/', 'loader.html')
        self.load_graph(loader_path)

        # start the worker in a new thread
        self.graph_worker = PlotlyWorker(graph_pop, title, search_type, chart_type, flip_xy, profile_type)
        QgsApplication.taskManager().addTask(self.graph_worker)
        self.graph_worker.graphChanged.connect(self.load_graph)
        self.graph_worker.taskCompleted.connect(lambda: self.graph_worker_finished('complete'))
        self.graph_worker.taskTerminated.connect(lambda: self.graph_worker_finished('terminated'))

    def load_graph(self, path):
        widget_layout = self.pop_webview_layout
        webview = self.pop_webview
        self.plot_url = QUrl.fromLocalFile(path)
        webview.load(self.plot_url)
        widget_layout.addWidget(webview)

    def graph_worker_finished(self, status):
        self.graph_worker.deleteLater()
        if status == 'complete':
            self.onBrowserBtn.setEnabled(True)
            self.graph_dlg.flipChk.setEnabled(True)
        else:
            self.onBrowserBtn.setEnabled(False)

    def load_plot_browser(self):
        QDesktopServices.openUrl(self.plot_url)

    def export_csv(self):
        init_path = self.qst.value('urban_data_provider/defactoGraphPath', tempfile.gettempdir())
        layer_name = self.current_layer['layer_name']
        export_to = \
            QFileDialog.getSaveFileName(self, 'Save File',
                                        os.path.join(init_path, layer_name + '_' + self.target_admin_nm),
                                        'CSV files (*.csv)')[0]
        if export_to:
            self.defacto_pop.to_csv(export_to, index=False, header=True, encoding='utf-8-sig')
            self.qst.setValue('urban_data_provider/defactoGraphPath', str(Path(export_to).parent))

    def kill_worker(self):
        """Kill the worker thread."""
        if self.worker is not None:
            self.worker.cancel()

    # Implement the accept method to avoid exiting the dialog when starting the work
    def accept(self):
        pass

    def reject(self):
        """Reject override."""
        # exit the dialog
        QDockWidget.reject(self)
