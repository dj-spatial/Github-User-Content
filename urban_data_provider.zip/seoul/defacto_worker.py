# -*- coding: utf-8 -*-
import pandas as pd
import geopandas as gpd
import os
import os.path
import sys
import sqlite3
from pandas.tseries.offsets import MonthEnd
import zipfile
import requests
from PyQt5.QtCore import pyqtSignal, QDate
from qgis.core import (
    Qgis,
    QgsProject,
    QgsTask,
    QgsSettings,
    QgsMessageLog,
    QgsFeature,
    QgsGeometry,
)
from qgis.utils import iface
from ..utils.utils import getDefacto

class DefactoTimeWorker(QgsTask):
    step_changed = pyqtSignal(str)

    def __init__(self, params):
        QgsTask.__init__(self)
        self.qst = QgsSettings()
        self.defacto_key = self.qst.value('urban_data_provider/defactoKey')
        self.db_path = self.qst.value('urban_data_provider/dbPath')
        self.search_unit = params['search_unit']
        self.search_date = params['search_date']
        self.search_hour_range = params['search_hour_range']
        self.search_type = params['search_type']
        self.search_table = params['search_table']
        self.col_types = params['col_types']
        self.exception = None

    def run(self):
        step_string = u'데이터 수집 중...'
        self.step_changed.emit(step_string)
        progress = 0
        # API REQUEST
        total = len(self.search_hour_range)
        census_rows = []
        for date in self.search_date:
            self.step_changed.emit(date + u' DB Collecting...')
            progress = 0
            for h in self.search_hour_range:
                census_response = getDefacto(self.defacto_key, self.search_unit, date, h, self.search_type, None)
                result_cd = census_response['resultCd']
                result_msg = census_response['resultMsg']
                if result_cd != 'INFO-000':
                    self.exception_msg = result_msg
                    self.exception = Exception(self.exception_msg)
                    self.step_changed.emit(result_msg)
                    continue
                census_rows += census_response['rows']
                progress += 1
                self.calculate_progress(progress, total)

        # API result to dataframe
        census = pd.DataFrame(census_rows)
        if self.search_unit == 2:
            census.drop(census.columns[[2]], axis=1, inplace=True)
        census.replace('*', 0, inplace=True)
        census.fillna(0, inplace=True)

        # dataframe to database
        self.step_changed.emit(u'DB Updating...')
        vals = list(census.to_records(index=False))
        if self.search_type == 0:
            field_count = ",?"*31
        elif self.search_type == 1:
            field_count = ",?" * 5
        else:
            field_count = ",?" * 5

        db_columns = "(" + ",\n".join(["{} {}".format(k, v) for k, v in self.col_types.items()]) + ")"
        conn = sqlite3.connect(self.db_path + '/defacto.db')
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE if not exists " + self.search_table + "\n" + db_columns)
        conn.executemany(
            "INSERT INTO " + self.search_table + " VALUES(?" + field_count + ")", vals
        )
        conn.commit()
        cursor.close()
        conn.close()
        return True

    def finished(self, result):
        if result:
            self.step_changed.emit(u'완료')
            return
        else:
            if self.exception is None:
                iface.messageBar().pushMessage("Warning:", u'오류 발생', level=Qgis.Warning, duration=5)
            else:
                iface.messageBar().pushMessage("Critical:", self.exception_msg, level=Qgis.Critical, duration=5)

    def calculate_progress(self, processed, total):
        processed = processed + 1
        percentage = int((processed * 100) / total)
        self.setProgress(percentage)

class DefactoTimeFileWorker(QgsTask):
    step_changed = pyqtSignal(str)
    remote_changed = pyqtSignal(str)

    def __init__(self, params):
        QgsTask.__init__(self)
        self.qst = QgsSettings()
        self.db_path = self.qst.value('urban_data_provider/dbPath')
        self.search_unit = params['search_unit']
        self.search_type = params['search_type']
        self.search_date = params['search_date']
        self.search_table = params['search_table']
        self.csv_path = params['csv_path']
        self.col_types = params['col_types']
        self.temp_dir = params['temp_dir']
        if self.temp_dir:
            self.search_date = [csv_file.split('.')[0].split('_')[-1] for csv_file in self.csv_path]
        else:
            self.search_date = [self.search_date]
            self.csv_path = [self.csv_path]
        self.exception = None

    def run(self):
        self.remote_changed.emit(u'시작...')
        db_columns = "(" + ",\n".join(["{} {}".format(k, v) for k, v in self.col_types.items()]) + ")"
        conn = sqlite3.connect(self.db_path + '/defacto.db')
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE if not exists " + self.search_table + "\n" + db_columns)
        total_csv = len(self.csv_path)
        for i, (s_date, csv) in enumerate(zip(self.search_date, self.csv_path)):
            self.step_changed.emit(u'DB Updating...')
            step_string = 'Updating ' + s_date + ' : '
            if self.search_unit == 0:
                district = 25
            elif self.search_unit == 1:
                district = 424
            else:
                district = 19153

            if self.temp_dir:
                csv = os.path.join(self.temp_dir, csv)
                if len(s_date) == 4:
                    req_date = QDate.fromString(s_date, 'yyyy')
                    dates = req_date.daysInYear()
                    to_delete = 4
                elif len(s_date) == 6:
                    req_date = QDate.fromString(s_date, 'yyyyMM')
                    dates = req_date.daysInMonth()
                    to_delete = 6
                else:
                    dates = 1
                    to_delete = 8
                to_delete_dates = s_date
            else:
                req_date = QDate.fromString(s_date, 'yyyyMMdd')
                if self.search_unit == 0:
                    dates = req_date.daysInYear()
                    to_delete = 4
                elif self.search_unit == 1:
                    dates = req_date.daysInMonth()
                    to_delete = 6
                else:
                    to_delete = 8
                to_delete_dates = s_date[:to_delete]
            row_count = district * dates * 24
            chunk_size = int(row_count / 100) if row_count >= 100 else 1
            try:
                chunk = pd.read_csv(csv, chunksize=chunk_size, low_memory=False, header=0, na_values=["*"], dtype=str, encoding='cp949', index_col=False)
            except Exception:
                chunk = pd.read_csv(csv, chunksize=chunk_size, low_memory=False, header=0, na_values=["*"], dtype=str, encoding='utf-8', index_col=False)
            chunk = list(chunk)
            for j, data_source in enumerate(chunk):
                remote_progress = int(j * chunk_size / row_count * 100)
                if remote_progress >= 95:
                    remote_progress = 100
                self.remote_changed.emit(step_string + ' : ' + str(remote_progress) + '%')
                data_source = pd.concat(chunk)
            self.remote_changed.emit(u'다음 DB...')
            if self.search_unit == 2:
                data_source.drop(data_source.columns[[2]], axis=1, inplace=True)
            data_source.fillna(0, inplace=True)
            cursor.execute("DELETE from " + self.search_table + " where substr(date, 1, " + str(to_delete) + ")=?", (to_delete_dates,))
            data_source.columns = [k for k in self.col_types.keys()]
            data_source.to_sql(name=self.search_table, con=conn, if_exists='append', index=False)
            self.calculate_progress(i, total_csv)
        cursor.close()
        conn.commit()
        conn.close()
        return True

    def finished(self, result):
        if result:
            self.remote_changed.emit(u'완료되었습니다.')
            self.step_changed.emit(u'완료!')
            return
        else:
            if self.exception is None:
                iface.messageBar().pushMessage("Warning:", u'오류 발생', level=Qgis.Warning, duration=5)
                self.step_changed.emit(u'오류 발생!')
            else:
                iface.messageBar().pushMessage("Critical:", self.exceptionMsg, level=Qgis.Critical, duration=5)
                self.step_changed.emit(self.exceptionMsg)

    def calculate_progress(self, processed, total):
        percentage = int(processed / total * 100)
        self.setProgress(percentage)

    def step_progress(self):
        self.step = str(self.step) + '.'
        self.step_changed.emit(self.step)

class DefactoRequestWorker(QgsTask):
    step_changed = pyqtSignal(str)
    remote_changed = pyqtSignal(str)
    csv_completed = pyqtSignal(object)

    def __init__(self, params):
        QgsTask.__init__(self)
        self.temp_dir = params['temp_dir']
        self.zip_path = params['zip_path']
        self.search_unit = params['search_unit']
        self.search_type = params['search_type']
        self.search_date = params['search_date']
        self.current_date = QDate.currentDate().addDays(-5).toString('yyyyMMdd')
        self.current_month = self.current_date[:6]
        self.current_year = self.current_date[:4]

        if self.search_unit == 0:
            if self.search_type == 0:
                self.inf_id = 'OA-15439'
            elif self.search_type == 1:
                self.inf_id = 'OA-15440'
            else:
                self.inf_id = 'OA-15441'
            self.inf_seq = '3'
        elif self.search_unit == 1:
            if self.search_type == 0:
                self.inf_id = 'OA-14991'
            elif self.search_type == 1:
                self.inf_id = 'OA-14992'
            else:
                self.inf_id = 'OA-14993'
            self.inf_seq = '3'
        else:
            if self.search_type == 0:
                self.inf_id = 'OA-14979'
            elif self.search_type == 1:
                self.inf_id = 'OA-14978'
            else:
                self.inf_id = 'OA-14980'
            self.inf_seq = '1'
        self.exception = None

    def run(self):
        # 일간데이터 리스트로 쌀것!!!!!!! [] 안그러면 첫번째 숫자만 남음
        self.step_changed.emit(u'데이터 요청...')
        total = len(self.search_date)
        extracted_dates = []
        self.csv_list = []
        QgsMessageLog.logMessage(str(self.search_date))
        for date_missing in self.search_date:
            if date_missing in extracted_dates:
                continue
            target_year = int(date_missing[:4])
            target_month = int(date_missing[:6])
            target_date = int(date_missing[:8])
            if self.search_unit == 0:
                # 2017-->1, 2018-->2, .... ; this year --> csv download
                if target_year < int(self.current_year):
                    seq = str(int(date_missing[:4]) - 2016)
                    range_from = str(target_year) + '0101'
                    range_to = str(target_year) + '1231'
                else:
                    seq = ''
                    range_from = str(target_month) + '01'
                    range_to = (pd.to_datetime(target_month, format="%Y%m") + MonthEnd(1)).strftime('%Y%m%d')
            elif self.search_unit == 1:
                if target_month >= 202301:
                    # 202301 ~ 직전월까지 월간 데이터
                    seq = date_missing[2:6] if target_month < int(self.current_month) else ''
                    range_from = str(target_month) + '01'
                    range_to = (pd.to_datetime(target_month, format="%Y%m") + MonthEnd(1)).strftime('%Y%m%d')
                else:
                    if self.search_unit == 0:
                        range_from = str(target_year) + '0101' if int(str(target_month)[5:6]) <= 6 else str(target_year) + '0701'
                        range_to = str(target_year) + '0630' if int(str(target_month)[5:6]) <= 6 else str(target_year) + '1231'
                    else:
                        range_from = str(target_year) + '0101'
                        range_to = str(target_year) + '1231'
                    # 2017.01 ~ 2022.12 반기 데이터
                    if target_month >= 201701 and target_month <= 201706:
                        if self.search_unit == 0:
                            seq = '2213'
                        else:
                            seq = '2213'
                    elif target_month >= 201707 and target_month <= 201712:
                        if self.search_unit == 0:
                            seq = '2214'
                        else:
                            seq = '2213'
                    elif target_month >= 201801 and target_month <= 201806:
                        if self.search_unit == 0:
                            seq = '2215'
                        else:
                            seq = '2214'
                    elif target_month >= 201807 and target_month <= 201812:
                        if self.search_unit == 0:
                            seq = '2216'
                        else:
                            seq = '2214'
                    elif target_month >= 201901 and target_month <= 201906:
                        if self.search_unit == 0:
                            seq = '2217'
                        else:
                            seq = '2215'
                    elif target_month >= 201907 and target_month <= 201912:
                        if self.search_unit == 0:
                            seq = '2218'
                        else:
                            seq = '2215'
                    elif target_month >= 202001 and target_month <= 202006:
                        if self.search_unit == 0:
                            seq = '2219'
                        else:
                            seq = '2216'
                    elif target_month >= 202007 and target_month <= 202012:
                        if self.search_unit == 0:
                            seq = '2220'
                        else:
                            seq = '2216'
                    elif target_month >= 202101 and target_month <= 202106:
                        if self.search_unit == 0:
                            seq = '2221'
                        else:
                            seq = '2217'
                    elif target_month >= 202107 and target_month <= 202112:
                        if self.search_unit == 0:
                            seq = '2222'
                        else:
                            seq = '2217'
                    elif target_month >= 202201 and target_month <= 202206:
                        if self.search_unit == 0:
                            seq = '2223'
                        else:
                            seq = '2218'
                    elif target_month >= 202207 and target_month <= 202212:
                        if self.search_unit == 0:
                            seq = '2224'
                        else:
                            seq = '2218'
            elif self.search_unit == 2:
                # 직전월까지 월간 데이터
                if target_month < int(self.current_month):
                    seq = date_missing[2:6]
                    range_from = str(target_month) + '01'
                    range_to = (pd.to_datetime(target_month, format="%Y%m") + MonthEnd(1)).strftime('%Y%m%d')
                # 직전월까지 월간 데이터
                else:
                    date_missing[2:]
                    range_from = str(target_date)
                    range_to = str(target_date)
            step_string = range_from + '-' + range_to

            self.step_changed.emit(u'다운로드...')
            if seq == '':
                # zip 다운로드 안되는 경우 csv로 조회(자치구=금년도, 행정동=이번 달, 집계구는 모든 날짜를 request로 조회가능)
                n_days = 30 if str(target_month) != self.current_month else int(self.current_date[6:8])
                local_to_foreign = 1 if self.search_type == 0 else 7
                csv_name = str(target_month) + '.csv'
                csv_path = os.path.join(self.temp_dir, csv_name)
                url = 'https://datafile.seoul.go.kr/bigfile/iot/sheet/csv/download.do?'
                data = {'infId': self.inf_id, 'filterCol': 'STDR_DE_ID', 'txtFilter': str(target_month)}
                response = requests.post(url, data=data, stream=True)
                file_size = 230 * n_days * 1024 if self.search_unit == 0 else 3500 * n_days * 1024
                file_size = int(file_size / local_to_foreign)
                chunked = 0
                with open(csv_path, 'wb') as fd:
                    for chunk in response.iter_content(chunk_size=file_size // 20):
                        chunked = chunked + len(chunk)
                        remote_progress = int(chunked/file_size*100)
                        if remote_progress >= 95:
                            remote_progress = 100
                        self.remote_changed.emit(step_string + ' : ' + str(remote_progress) + '%')
                        fd.write(chunk)
                self.csv_list.append(csv_name)
                self.remote_changed.emit(u'다음 요청...')
            else:
                # zip 파일 다운로드
                url = 'https://datafile.seoul.go.kr/bigfile/iot/inf/nio_download.do?&useCache=false'
                data = {'infId': self.inf_id, 'seqNo': '', 'seq': seq, 'infSeq': self.inf_seq}
                response = requests.post(url, data=data, stream=True)
                file_size = int(response.headers['Content-Length'])
                chunked = 0
                with open(self.zip_path, 'wb') as fd:
                    for chunk in response.iter_content(chunk_size=file_size // 100):
                        chunked = chunked + len(chunk)
                        remote_progress = int(chunked/file_size*100)
                        self.remote_changed.emit(step_string + ' : ' + str(remote_progress) + '%')
                        fd.write(chunk)
                self.remote_changed.emit(u'다음 요청...')
                # extract downloaded zip file
                with zipfile.ZipFile(self.zip_path, "r") as zf:
                    zf.extractall(self.temp_dir)
                self.csv_list.extend(zf.namelist())
                os.remove(self.zip_path)
            date_range = pd.date_range(range_from, range_to, name='date').to_frame(index=False)
            date_range['date'] = date_range['date'].dt.strftime('%Y%m%d')
            extracted_dates.extend(date_range['date'].to_list())
            progress = int((1 - len(list(set(self.search_date) - set(extracted_dates))) / total) * 100)
            self.setProgress(progress)
        return True

    def finished(self, result):
        if result:
            self.remote_changed.emit(u'완료되었습니다. DB를 등록하세요.')
            self.step_changed.emit(u'완료!')
            self.csv_completed.emit(self.csv_list)
            return
        else:
            if self.exception is None:
                iface.messageBar().pushMessage("Warning:", u'오류 발생', level=Qgis.Warning, duration=5)
            else:
                iface.messageBar().pushMessage("Critical:", self.exception_msg, level=Qgis.Critical, duration=5)


class DefactoLayerWorker(QgsTask):
    step_changed = pyqtSignal(str)
    layerCompleted = pyqtSignal(object, str)  # For final result and field name for style

    def __init__(self, params):
        QgsTask.__init__(self)
        self.current_layer_id = params['current_layer_id']
        self.db_path = params['db_path']
        self.search_unit = params['search_unit']
        self.search_date = params['search_date']
        self.search_table = params['search_table']
        self.sgg_cd = params['sgg_cd']
        self.target_age = params['target_age']
        self.target_hours = params['target_hours']
        self.agg_type = params['agg_type']
        self.exception = None

    def run(self):
        self.step_changed.emit(u'데이터 연결...')
        # 생활인구 데이터 추출
        self.step_changed.emit(u'데이터 추출...')
        conn = sqlite3.connect(self.db_path + '/defacto.db')
        sql = "SELECT * FROM " + self.search_table

        if self.search_unit == 2:
            sql = sql + ' WHERE date = ? and substr(keyAdmin, 1, 5) = ?'
            df = pd.read_sql_query(sql, conn, params=(self.search_date, self.sgg_cd,))
        else:
            sql = sql + ' WHERE date = ?'
            df = pd.read_sql_query(sql, conn, params=(self.search_date,))
        conn.commit()
        conn.close()
        df = df[df['time'].isin(self.target_hours)]
        if len(self.target_age) == 28:
            df = df[['keyAdmin', 'time', u'총생활인구']].rename(columns={u'총생활인구':u'생활인구'})
        else:
            df = pd.concat([df[['keyAdmin', 'time']], df.loc[:, self.target_age].sum(axis=1).rename(u'생활인구')], axis=1)

        if self.agg_type == 'time':
            cols = len(self.target_hours)
            age_pivot = df.pivot_table(index=['keyAdmin'], columns=['time'], fill_value=0)
        elif self.agg_type == 'agg':
            cols = 12
            grouped = df.groupby("keyAdmin")[u'생활인구']
            age_pivot = pd.concat([
                grouped.describe().iloc[:, 1:],  # drop count
                grouped.sem().rename(u'sem'),
                (grouped.quantile(q=0.75, interpolation='midpoint') - grouped.quantile(q=0.25, interpolation='midpoint')).rename(u'iqr'),
                (grouped.max() - grouped.min()).rename(u'range'),
                grouped.skew().rename(u'skew'),
                grouped.sum().rename(u'sum')], axis=1
            )

        # 레이어 생성
        self.step_changed.emit(u'레이어 생성...')
        boundary = QgsProject.instance().mapLayer(self.current_layer_id)
        if self.search_unit == 0:
            total = 25
        elif self.search_unit == 1:
            total = 424
        else:
            total = boundary.featureCount()
        feats = []
        processed = 0
        for f in boundary.getFeatures():  # row[adm_cd, adm_nm, defacto_cd]
            key_admin = f.attributes()[2]
            try:
                defacto_attr = age_pivot.loc[(key_admin)].to_list()
            except Exception:
                defacto_attr = [0] * cols
            f.setAttributes([f.attributes()[0], f.attributes()[1], f.attributes()[2]] + defacto_attr)
            feats.append(f)
            processed += 1
            self.calculate_progress(processed, total)
        self.step_changed.emit(u'레이어 로딩...')
        self.layerCompleted.emit(feats, self.current_layer_id)
        return True

    def finished(self, result):
        if result:
            self.step_changed.emit(u'완료!')
            return
        else:
            if self.exception is None:
                iface.messageBar().pushMessage("Warning:", u'오류 발생', level=Qgis.Warning, duration=5)
            else:
                iface.messageBar().pushMessage("Critical:", self.exception_msg, level=Qgis.Critical, duration=5)

    def calculate_progress(self, processed, total):
        processed = processed + 1
        percentage = int((processed * 100) / total)
        self.setProgress(percentage)

class MapOnCanvas(QgsTask):
    step_changed = pyqtSignal(str)
    layerCompleted = pyqtSignal(object, object)  # For final result and field name for style

    def __init__(self, params):
        QgsTask.__init__(self)
        self.params = params
        self.db_path = self.params['db_path']
        self.search_unit = self.params['search_unit']
        self.sgg_cd = self.params['sgg_cd']
        self.exception = None

    def run(self):
        seoul_boundary = self.db_path + "/seoul.gpkg"
        if self.search_unit == 0:
            boundary = gpd.read_file(seoul_boundary, layer="sgg")
            total = 25
        elif self.search_unit == 1:
            boundary = gpd.read_file(seoul_boundary, layer="emd")
            total = 424
        else:
            boundary = gpd.read_file(seoul_boundary, layer="track")
            boundary = boundary[(boundary["adm_cd"].str[:5] == self.sgg_cd)]
            total = len(boundary.index)

        # 레이어 생성
        self.step_changed.emit(u'레이어 생성...')
        self.feats = []
        processed = 0
        for row in boundary.itertuples():  # row[id, adm_cd, adm_nm, defacto_cd, geometry]
            if self.isCanceled():
                return False
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromWkt(row[4].wkt))
            f.setAttributes([row[1], row[2], row[3]])
            self.feats.append(f)
            self.calculate_progress(processed, total)
            processed += 1
        self.step_changed.emit(u'레이어 로딩...')
        return True

    def finished(self, result):
        self.calculate_progress(-1, 100)
        if result:
            self.layerCompleted.emit(self.feats, self.params)
            return
        else:
            if self.exception is None:
                iface.messageBar().pushMessage("Warning:", u'오류 발생', level=Qgis.Warning, duration=5)
            else:
                return

    def cancel(self):
        self.step_changed.emit(u'취소 중...')
        super().cancel()

    def calculate_progress(self, processed, total):
        percentage = int((processed * 100) / total)
        self.setProgress(int(min(percentage, 100)))
