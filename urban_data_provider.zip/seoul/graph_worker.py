# -*- coding: utf-8 -*-
import os.path
import json
import pandas as pd
import numpy as np
import tempfile
from PyQt5.QtCore import pyqtSignal

from qgis.core import (
    Qgis,
    QgsTask,
    QgsFeatureRequest,
    QgsExpression,
    QgsJsonExporter,
    QgsMessageLog,
    QgsVectorLayer
)
import plotly
import plotly.graph_objs as go
import plotly.express as px
from qgis.utils import iface
from ..utils.sgis_utils import (
    get_access_token,
    get_admin_area
)
from ..utils.utils import getDefacto


class PlotlyWorker(QgsTask):
    graphChanged = pyqtSignal(str)

    def __init__(self, graph_pop, title, search_type, chart_type, flip_xy, profile_type):
        QgsTask.__init__(self)
        self.defacto_pop = graph_pop
        self.title = title
        self.search_type = search_type
        self.chart_type = chart_type  # 0:Bar, 1:Heatmap, 2:Line
        self.flip_xy = flip_xy
        self.profile_type = profile_type  # 0:남|여, 1:남+여, 2:남, 3:여

        # 그래프 경로
        self.plot_path = os.path.join(tempfile.gettempdir(), 'defacto' + '.html')
        self.error_path = os.path.join(os.path.dirname(__file__), '../utils/plot/', 'error.html')

    def run(self):
        defacto_trace_list = []
        if self.chart_type != 2:
            if not self.flip_xy:
                self.defacto_pop = [pop.T for pop in self.defacto_pop]
        else:
            if self.flip_xy:
                self.defacto_pop = [pop.T for pop in self.defacto_pop]

        # y axis range
        defacto_sum = [defacto.sum(axis=0) for defacto in self.defacto_pop]
        defacto_min = min([min(p.min()) for p in self.defacto_pop])
        defacto_max = max([max(p.max()) for p in self.defacto_pop])
        defacto_sum_max = max([d.max() for d in defacto_sum])
        defacto_sum_div = 10 ** (len(str(int(defacto_sum_max))) - 2)

        # x axis
        x_axis = {
            # 'type': 'category',
            'dtick': 2 if len(defacto_sum[0]) > 5 else 1,
            'ticks': '',
            'side': 'bottom',
            'tickfont': dict(size=10),
            'showline': False,
            'showgrid': False,
            # 'tickformat': '%H' if self.chart_type == 0 or self.chart_type == 2 else "",
            'autorange': True,
            'rangemode': 'nonnegative',
            'visible': True
        }

        # y axis
        if self.chart_type == 0:
            y_range = [[0, defacto_sum_max], [defacto_sum_max, 0]]
            autorange = [False, False]
        elif self.chart_type == 1:
            y_range = [None, None]
            autorange = [True, 'reversed']
        elif self.chart_type == 2:
            y_range = [None, None]
            autorange = [True, 'reversed']
        elif self.chart_type == 3:
            y_range = [[defacto_min, defacto_max], [defacto_min, defacto_max]]
            autorange = [False, False]

        y_axis1 = {
            'range': y_range[0],
            'autorange': autorange[0],
            'rangemode': 'nonnegative',
            'visible': False if self.chart_type == 0 or self.chart_type == 2 else True,
            'mirror': False
        }
        y_axis2 = {
            'range': y_range[1],
            'autorange': autorange[1],
            'rangemode': 'nonnegative',
            'visible': False if self.chart_type == 0 or self.chart_type == 2 else True,
            'mirror': False
        }
        y_domain = 0.525 if self.profile_type == 0 and self.chart_type != 3 else 0
        defacto_layout = {
            'title': dict(yanchor='top', y=0.98, xanchor='center', x=0.5, text=self.title, font=dict(size=12)),
            'barmode': 'stack',
            'plot_bgcolor': 'white' if self.chart_type != 2 else 'rgb(245,245,245)',
            'coloraxis': dict(colorscale='Magma', colorbar={'thickness': 5}),
            'margin': dict(l=0, r=0, t=55, b=55),
            'xaxis1': dict(x_axis, **dict(domain=[0.0, 1.0], anchor='y1')),
            'yaxis1': dict(y_axis1, **dict(domain=[y_domain, 0.990]), anchor='x'),
            'yaxis2': dict(y_axis2, **dict(domain=[0.000, 0.465]), anchor='x')
            }

        # prfix, suffix
        prefix = ['', '']
        suffix_1, suffix_2 = (u'시', '') if self.flip_xy else ('', u'시')

        # trace color
        color_from_list = [['195', '330'], ['260', '260'], ['195', '195'], ['330', '330']]
        color_from = color_from_list[self.profile_type]

        # BAR CHART
        if self.chart_type == 0:
            # trace
            for i, defacto in enumerate(self.defacto_pop):
                xs = list(defacto.columns)
                if self.search_type == 0 and self.profile_type == 0 and self.flip_xy:
                    xs = [sub[1:] for sub in xs]
                    prefix = [u'남', u'여']
                if self.search_type == 1 and self.profile_type == 0 and self.flip_xy:
                    xs = [u' ']
                    prefix = [u'중국인', u'비중국인']
                if self.search_type == 2 and self.profile_type == 0 and self.flip_xy:
                    xs = [u' ']
                    prefix = [u'중국인', u'비중국인']

                ys = list(defacto.index)
                color_rank = defacto.transform(pd.Series.rank, ascending=False).astype(int)
                trace_list = []
                for row_idx, row in enumerate(defacto.itertuples(index=False)):
                    color_list = ['hsl(' + color_from[i] + ', 100%, ' + str(72 - col * 3) + '%)' for col in
                                  color_rank.iloc[row_idx, :]]
                    trace_bar = go.Bar(
                        xaxis='x',
                        yaxis='y' + str(i + 1),
                        x=xs,
                        y=row,
                        orientation='v',
                        hoverlabel=dict(bgcolor='white', namelength=0),
                        hovertemplate='<b>' + str(ys[row_idx]) + suffix_1 + '<br>' + prefix[i] + '%{x}' + suffix_2 + ':%{y:,.0f}명</b>',
                        marker=dict(color=color_list, line=dict(width=0.5, color='white')),
                        showlegend=False,
                        visible=True
                        # name=ys[j][i],
                        # customdata=[ys[i]] * len(xs),
                    )
                    trace_list.append(trace_bar)
                defacto_trace_list = defacto_trace_list + trace_list

                # annotations
                annot_list = []
                xanchor = ['right', 'left']
                textangle = [90, 90]
                yshift = [5, -5]
                # xs = [sub[1:] for sub in xs] if self.profile_type == 0 and self.flip_xy else xs
                for i, d_sum in enumerate(defacto_sum):
                    annot = [
                        dict(
                            x=x,
                            y=ds,
                            xref='x',
                            yref='y' + str(i + 1),
                            xanchor=xanchor[i],
                            yanchor='middle',
                            textangle=textangle[i],
                            font={'size': 9},
                            borderwidth=3,
                            align='center',
                            showarrow=True,
                            arrowsize=2,
                            arrowhead=6,
                            arrowwidth=0.5,
                            arrowcolor='black',
                            yshift=yshift[i],
                            ax=0,
                            ay=0,
                            text='{0:,.1f}'.format(ds / defacto_sum_div) if defacto_sum_div > 99 else '{0:,.1f}'.format(
                                ds),
                            hovertext=u'<b>총생활인구' + '<br>' + str(x) + suffix_2 + ' : ' + '{0:,.0f}'.format(
                                ds) + u'명</b>',
                            hoverlabel=dict(bgcolor='white'),
                            visible=True
                        ) for ds, x in zip(d_sum, xs)
                    ]
                    annot_list = annot_list + annot
                defacto_layout.update({'annotations': annot_list})

        # HEAT MAP
        elif self.chart_type == 1:
            for i, defacto in enumerate(self.defacto_pop):
                xs = list(defacto.columns)
                if self.search_type == 0 and self.profile_type == 0 and self.flip_xy:
                    xs = [sub[1:] for sub in xs]
                    prefix = [u'남', u'여']
                if self.search_type == 1 and self.profile_type == 0 and self.flip_xy:
                    xs = [u' ']
                    prefix = [u'중국인', u'비중국인']
                if self.search_type == 2 and self.profile_type == 0 and self.flip_xy:
                    xs = [u' ']
                    prefix = [u'중국인', u'비중국인']
                ys = list(defacto.index)
                trace_list = []
                trace_heat = go.Heatmap(
                    x=xs,
                    y=ys,
                    z=defacto,
                    zsmooth=False,
                    connectgaps=True,
                    yaxis='y' + str(i + 1),
                    showscale=True,
                    # name='prefix',
                    hovertemplate='<b>' + prefix[i] + '%{x}' + suffix_2 + '</b><br>' + '%{y}' + suffix_1 + ': %{z:,.0f}명',
                    hoverlabel=dict(namelength=0),
                    coloraxis='coloraxis'
                )
                trace_list.append(trace_heat)
                defacto_trace_list = defacto_trace_list + trace_list

        # BOX PLOT
        elif self.chart_type == 2:
            # trace
            clist = [
                ['hsl(195, 100%, 33%)', 'hsl(330, 100%, 33%)'],
                ['hsl(260, 100%, 33%)'],
                ['hsl(195, 100%, 33%)'],
                ['hsl(330, 100%, 33%)']
            ]
            color_list = clist[self.profile_type]
            for i, defacto in enumerate(self.defacto_pop):
                xs = list(defacto.index)
                if self.search_type == 0 and self.profile_type == 0 and self.flip_xy:
                    xs = [sub[1:] for sub in xs]
                    prefix = [u'남', u'여']
                if self.search_type == 1 and self.profile_type == 0 and self.flip_xy:
                    xs = [u' ']
                    prefix = [u'중국인', u'비중국인']
                if self.search_type == 2 and self.profile_type == 0 and self.flip_xy:
                    xs = [u' ']
                    prefix = [u'중국인', u'비중국인']
                ys = list(defacto.columns)
                trace_list = []
                for row_idx, row in enumerate(defacto.itertuples(index=False)):
                    trace_box = go.Box(
                        yaxis='y' + str(i + 1),
                        name=xs[row_idx],
                        text=ys,
                        y=row,
                        boxmean=True,
                        boxpoints='all',
                        marker=dict(color=color_list[i], size=2, symbol='circle-open'),
                        jitter=0,
                        pointpos=-1.5,
                        whiskerwidth=0.2,
                        showlegend=False,
                        hoverlabel=dict(bgcolor='white', namelength=0),
                        hovertemplate='<b>' + prefix[i] + str(xs[row_idx]) + suffix_2 + '<br>' + str('%{text}') + suffix_1 + ':%{y:,.0f}명</b>',
                    )
                    trace_list.append(trace_box)
                defacto_trace_list = defacto_trace_list + trace_list
        # ANIMATION
        elif self.chart_type == 3:
            sliders_dict = {
                "active": 0,
                "yanchor": "top",
                "xanchor": "left",
                "currentvalue": {
                    "font": {"size": 14},
                    "prefix": "시간:",
                    "visible": True,
                    "xanchor": "right"
                },
                "transition": {"duration": 300, "easing": "cubic-in-out"},
                "pad": {"b": 10, "t": 20},
                "len": 0.875,
                "x": 0.125,
                "y": 0,
                "steps": []
            }
            defacto_frames_list = []
            trace_list = []
            for i, defacto in enumerate(self.defacto_pop):
                xs = list(defacto.columns)
                if self.search_type == 0 and self.profile_type == 0 and self.flip_xy:
                    xs = [sub[1:] for sub in xs]
                    prefix = [u'남', u'여']
                ys = list(defacto.index)
                z_vals = [0] * len(xs)
                data_dict = dict(
                    x=xs,
                    y=z_vals,
                    mode='lines',
                    fill='tozeroy',
                    line=dict(shape='spline', smoothing=1.3),
                    showlegend=False,
                    visible=True
                )
                trace_list.append(data_dict)
                defacto_trace_list = defacto_trace_list + trace_list
            for i, y in enumerate(ys):
                defacto_frames = self.get_frames(i, y, self.defacto_pop, prefix, xs, color_from)
                defacto_frames_list.append(defacto_frames[0])
                sliders_dict["steps"].append(defacto_frames[1])
            frm_start = {
                "frame": {
                    "duration": 500,
                    "redraw": False
                },
                "fromcurrent": True,
                "transition": {
                    "duration": 300,
                    "easing": "quadratic-in-out"
                }
            }
            frm_pause = {
                "frame": {
                    "duration": 0,
                    "redraw": False
                },
                "mode": "immediate",
                "transition": {
                    "duration": 0
                }
            }
            btns = [
                dict(
                    label='▷',
                    method='animate',
                    args=[None, frm_start]
                ),
                dict(
                    label='||',
                    method='animate',
                    args=[[None], frm_pause],
                )
            ]
            updatemenus = list([
                dict(
                    type='buttons',
                    showactive=False,
                    buttons=btns,
                    direction='left',
                    pad={'r': 5, 't': 30},
                    x=0.125,
                    xanchor='right',
                    y=-0.05,
                    yanchor='top'

                )
            ])

            # 애니메이션 프레임 구성
            defacto_layout.update({'updatemenus': updatemenus, 'sliders': [sliders_dict]})

        # create graph
        fig = {'data': defacto_trace_list, 'layout': defacto_layout}
        if self.chart_type == 3:
            fig.update({'frames': defacto_frames_list})
        config = {'scrollZoom': True, 'editable': False, 'displayModeBar': 'True', 'displaylogo': False,
                  'modeBarButtonsToRemove': ['lasso2d',
                                             'zoom2d',
                                             'zoomIn2d',
                                             'zoomOut2d',
                                             'pan2d',
                                             'autoScale2d',
                                             'toggleSpikelines',
                                             'hoverClosestCartesian',
                                             'hoverCompareCartesian',
                                             ]}
        raw_plot = plotly.offline.plot(fig, output_type='div', config=config, show_link=False)
        with open(self.plot_path, "w") as f:
            f.write(raw_plot)
        return True

    def finished(self, result):
        if result:
            self.graphChanged.emit(self.plot_path)
            return
        else:
            self.graphChanged.emit(self.error_path)
            iface.messageBar().pushMessage("Warning:", u'오류 발생', level=Qgis.Warning, duration=5)

    def get_frames(self, i, y, defacto_pop, prefix, xs, color_from):
        frame = dict(data=[], name=y)
        for j, defacto in enumerate(defacto_pop):
            z_vals = defacto.iloc[i, :]
            data_dict = dict(
                x=xs,
                y=z_vals,
                mode='lines',
                fill='tozeroy',
                name=prefix[j],
                hovertemplate='<b>%{x}</b> %{y:,.0f}명',
                hoverlabel=dict(bgcolor='white', namelength=10),
                line=dict(color='hsl(' + color_from[j] + ', 100%, ' + str(72 - i * 3) + '%)', shape='spline', smoothing=1.3),
                showlegend=False,
                visible=True
            )
            frame['data'].append(data_dict)
        slider_step = {"args": [
            [y],
            {"frame": {"duration": 300, "redraw": False},
             "mode": "immediate",
             "transition": {"duration": 300}}
        ],
            "label": y,
            "method": "animate"}
        return frame, slider_step
