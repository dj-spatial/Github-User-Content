# -*- coding: utf-8 -*-
"""
/***************************************************************************
 NSearchDialog
                                 A QGIS plugin
 .
                             -------------------
        begin                : 2017-02-06
        git sha              : $Format:%H$
        copyright            : (C) 2017 by D.J Paek
        email                : 1002jeen@daum.net
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import sys, os, os.path
from qgis.core import (Qgis,
                       QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform,
                       QgsProject,
                       QgsVectorLayer,
                       QgsFeature,
                       QgsRectangle,
                       QgsField,
                       QgsFields,
                       QgsGeometry)
from qgis.utils import iface					   
from qgis.PyQt.QtWidgets import QDialog, QDialogButtonBox
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtCore import QUrl
from PyQt5 import uic

import json
import sqlite3

from ..utils.utils import get_vworld_data
from ..utils.wfs_params import LandWfs
from ..forms.extent_panel import ExtentPanel
from ..utils.sgis_utils import get_access_token, get_admin_area

FORM_CLASS_Vworld, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), '../forms/sdata/spatialVworld_dialog_base.ui'))

class VworldDialog(QDialog, FORM_CLASS_Vworld):
    def __init__(self, iface, parent=None):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

        # Constructor
        super(VworldDialog, self).__init__(parent)
        self.setupUi(self)

        okButton = self.dialog_BB.button(QDialogButtonBox.Ok)
        closeButton = self.dialog_BB.button(QDialogButtonBox.Close)
        helpButton = self.dialog_BB.button(QDialogButtonBox.Help)

        # 검색카테고리 테이블(VWORLD 제공)
        groupTable = [u'경계', u'교통', u'기타권역', u'기타시설', u'기타장소', u'농업·농촌', u'도시계획', u'사회복지', u'산업단지', u'수자원', u'용도구역', u'용도기타', u'용도지구', u'용도지역', u'임업·산촌', u'자연', u'체육', u'항공·공항', u'해양·수산·어촌', u'환경보호']
        self.groupCB.addItems(groupTable)
        self.groupChange()

        # Connect signals
        self.groupCB.currentIndexChanged.connect(self.groupChange) 
        okButton.clicked.connect(self.spatialDataVworld)
        closeButton.clicked.connect(self.reject)
        helpButton.clicked.connect(self.giveHelp)
        self.pushButton.clicked.connect(self.getExtent)

	# end of __init__

    """ 검색범위 지정 """
    def getExtent(self):
        dlg = ExtentPanel(self)
        if dlg.exec_():
            self.leText.setText(dlg.lineEdit.text())
            r = dlg.extentRect
            sourceCrs = dlg.crs
            xform = QgsCoordinateTransform(sourceCrs, QgsCoordinateReferenceSystem("EPSG:5179"), QgsProject.instance())
            self.rGeom = QgsGeometry.fromRect(r)
            self.rGeom.transform(xform)
            self.bBox = QgsRectangle.fromWkt(self.rGeom.asWkt())

    """ 검색 카테고리 지정 """
    def groupChange(self):
        self.subCB.clear() 
        self.codeTable = []
        conn = sqlite3.connect(os.path.join(os.path.dirname(__file__), '../forms/sdata/vworld2d.db'))
        with conn:
            cur = conn.cursor()
            self.selectedGroup = self.groupCB.currentText()
            sql = "select sub_group, group_cd from vworld where group_nm = :GN"
            cur.execute(sql, {"GN" : self.selectedGroup})
            rows = cur.fetchall()
            for row in rows:
                self.subCB.addItem(row[0])
                self.codeTable.append(row[1])

    """ 검색시작 """
    def spatialDataVworld(self):
        searchData = self.codeTable[self.subCB.currentIndex()]
        isEnd = False
        pageNumber = 0
        featList = []
        featureCollection = {
            "type": "FeatureCollection",
            "crs": {
                "type": "name",
                "properties": {
                    "name": "urn:ogc:def:crs:EPSG::5179"
                }
            }
        }
        self.progressLB.setText(u'데이터 검색 중...')
        while isEnd == False:
            pageNumber = pageNumber + 1
            result = get_vworld_data(searchData, pageNumber, '', '', self.rGeom.asWkt(), '')
            status = result["status"]
            total = result["total"]
            current = result["current"]
            searched = result["featureCollection"]
            if status != 'OK':
                self.iface.messageBar().pushMessage("Info:", status, level=Qgis.Info,  duration = 5)
                self.progressLB.setText(status)
                return
            for f in searched["features"]:
                featList.append(f)
            self.progressBar.setMaximum(int(total))
            self.progressBar.setValue(int(current))
            if total == current:
                isEnd = True
        if total == 0:
            self.progressLB.setText(status)
            self.progressBar.setMaximum(100)
            return
        featureCollection.update({"features":featList})
        featureJsonBd = json.dumps(featureCollection)

        # create a layer
        project = QgsProject.instance()
        vLayer = QgsVectorLayer(featureJsonBd, self.selectedGroup + ':' + self.subCB.currentText(), "ogr")
        if self.subCB.currentText() == u'지적도':
            landWfs = LandWfs()
            labels = landWfs.showLabels(vLayer, 'jibun')
            vLayer.setLabeling(labels)
            vLayer.setLabelsEnabled(True)
            vLayer.setOpacity(0.75)
        if self.selectedGroup == u'용도지역':
            fieldIdx = vLayer.fields().indexOf('uname')
            uIds = vLayer.uniqueValues(fieldIdx)
            landWfs = LandWfs()
            styleRenderer = landWfs.categorizedSymbol('uname', uIds, opacity = 0.75, outline_style = 'no')
            vLayer.setRenderer(styleRenderer)
        project.addMapLayer(vLayer)
        self.progressLB.setText(str(len(featList)) + u'개 데이터가 검색되었습니다.')

    def reject(self):
        """Reject override."""
        # exit the dialog
        QDialog.reject(self)

    def giveHelp(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(self.plugin_dir + "/help/geocodeLd.html"))