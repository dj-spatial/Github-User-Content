# -*- coding: utf-8 -*-
import os
import plotly
from datetime import date
import tempfile
import numpy as np
from qgis.core import QgsTask, QgsMessageLog
from ..utils.utils import getLandPriceFluctuation
from ..utils.plot.plot_factory import buildFigures

class PriceWorker(QgsTask):
    def __init__(self, params):
        QgsTask.__init__(self)
        self.plot_path = None

        self.prices = params

    def run(self):
        # Create Trace
        priceYears = []
        landPrices = []
        colorStyle = 'orange'
        for y, p in self.prices.items():
            priceYears.append(date(int(y),1,1))
            landPrices.append(p)
        if landPrices == [-1]:
            hoverTextPrice = [u'데이터 없음']
        else:
            hoverTextPrice = [u'<b>개별공시지가</b><br>' + str(priceYear.year) + u'년: ' + '{0:,}'.format(landPrice) for priceYear, landPrice in zip(priceYears, landPrices)]
        traceParams = {
            'x': priceYears, 
            'y': landPrices, 
            'mode': 'lines', 
            'text': hoverTextPrice, 
            'line_width': 2, 
            'line_color': colorStyle, 
            'dash': 'solid', 
            'name': u'개별공시지가', 
            'legendgroup': '', 
            'visible': True
        }

        fig = buildFigures()
        self.priceTrace = [fig.buildTraceLine(**traceParams)]

        # Create Layout
        layoutParams = {
            'x0': priceYears[0],
            'xN': priceYears[-1],
            'yMax': max(landPrices),
            'yN': landPrices[-1],
            'type': 'date',
            'tickformat': '%Y',
            'nticks': 6,
            'arrowcolor': colorStyle,
            'traceorder': 'normal',
            'visible': True
        }
        annotText = str(u'데이터 없음') if landPrices[-1] == -1 else '{0:,.0f}'.format(landPrices[-1])
        buttonCount = [3, 5, 10, 15, 20, priceYears[-1].year-priceYears[0].year]
        buttons = [dict(count=c, label=str(c) + 'Y', step='year', stepmode='backward') for c in buttonCount]
        buttons[-1]['label'] = 'All'
        layoutParams['annotText'] = annotText
        layoutParams['buttons'] = buttons
        self.priceLayout = fig.buildLayoutLine(**layoutParams)
        return True

    def finished(self, result):
        if result:
            fig = dict(data=self.priceTrace, layout = self.priceLayout)
            config = {'scrollZoom': True, 'editable': False, 'displayModeBar': False}
            raw_plot = plotly.offline.plot(fig, output_type='div', config=config, show_link = False)
            self.plot_path = os.path.join(tempfile.gettempdir(), 'Price'+'.html')
            with open(self.plot_path, "w") as f:
                f.write(raw_plot)
        else:
            self.plot_path = os.path.join(os.path.dirname(__file__), '../utils/plot/', 'error.html')

class PriceFlucWorker(QgsTask):
    def __init__(self, **params):
        QgsTask.__init__(self)
        self.plot_path = None
        sidoCd = params['sidoCd']
        sggCd = params['sggCd']
        emdCd = params['emdCd']
        sido = params['sido']
        sgg = params['sgg']
        emd = params['emd']
        useIdx = params['useIdx']
        useNm = params['useNm']
        zoneIdx = params['zoneIdx']
        zoneNm = params['zoneNm']
        self.indexYears = []
        self.priceFluc = []
        self.hoverTextList = []
        self.admCdList = []
        self.scopeDivList = []
        self.responseByList = []
        self.zoneUseIdxList = []
        self.legendGroupList = []
        self.legendList = []
        self.widthList = []
        self.colorList = []
        self.dashList = []
        self.visibilityList = []
        self.modeList = []
        self.plotCat = params['plotCat']

        if self.plotCat == 0:
            self.admCdList = [sidoCd, sggCd, emdCd]
            self.scopeDivList = ['Z', 'A', 'B']
            self.responseByList = ['byRegions', 'byRegions', 'byRegions']
            self.zoneUseIdxList = [99, 99, 99]
            self.legendGroupList = [sido, sgg, emd]
            self.legendList = [sido, sgg, emd]
            self.widthList = [2, 2, 2]
            self.colorList = ['rgba(102,102,102,1)', 'rgba(191,191,191,1)', 'rgba(255,153,0,1)']
            self.dashList = ['solid', 'solid', 'solid']
            self.visibilityList = [True, True, True]
            self.modeList = ['lines', 'lines', 'lines']
        elif self.plotCat == 1:
            self.admCdList = [sidoCd, sggCd]
            self.scopeDivList = ['Z', 'A']
            self.responseByList = ['byLandCategorys', 'byLandCategorys']
            self.zoneUseIdxList = [useIdx, useIdx]
            self.legendGroupList = [sido, sgg]
            self.legendList = [sido + ' ' + useNm, sgg + ' ' + useNm]
            self.widthList = [2, 2]
            self.colorList = ['rgba(102,102,102,1)', 'rgba(255,153,0,1)']
            self.dashList = ['solid', 'solid']
            self.visibilityList = [True, True, True]
            self.modeList = ['lines', 'lines']
        else:
            dashStyleList = ['solid', 'dashdot', 'longdashdot', 'dash', 'longdash']

            # Price Trace parameters for 시군구 용도지역(2이상의 용도지역에 걸친 토지가 있을 수 있음)
            for i, (idx, nm) in enumerate(zip(zoneIdx, zoneNm)):
                self.admCdList.append(sidoCd)
                self.scopeDivList.append('Z')
                self.responseByList.append('byZonings')
                self.zoneUseIdxList.append(idx)
                self.legendGroupList.append(sido)
                self.legendList.append(sido + ' ' + nm)
                self.widthList.append(2)
                self.colorList.append('rgba(102,102,102,1)')
                self.dashList.append(dashStyleList[i])
                self.visibilityList.append(True)
                self.modeList.append('lines')

            # Price Trace parameters for 시군구 용도지역(2이상의 용도지역에 걸친 토지가 있을 수 있음)
            for i, (idx, nm) in enumerate(zip(zoneIdx, zoneNm)):
                self.admCdList.append(sggCd)
                self.scopeDivList.append('A')
                self.responseByList.append('byZonings')
                self.zoneUseIdxList.append(idx)
                self.legendGroupList.append(sgg)
                self.legendList.append(sgg + ' ' + nm)
                self.widthList.append(2)
                self.colorList.append('rgba(255,153,0,1)')
                self.dashList.append(dashStyleList[i])
                self.visibilityList.append(True)
                self.modeList.append('lines')

    def run(self):
        # Parameters for Price Trace
        for i, (admCd, scopeDiv, responseBy, zoneUseIdx) in enumerate(zip(self.admCdList, self.scopeDivList, self.responseByList, self.zoneUseIdxList)):
            indexYear, priceIndex, priceRateChange, response = getLandPriceFluctuation(
                admCd, '', '', scopeDiv = scopeDiv, responseBy = responseBy, zoneUseIdx = zoneUseIdx
            )
            priceRateChange[0] = '0'
            accPriceRateChange = np.cumprod(list(map(lambda x:round(float(x)/100+1,3), priceRateChange)))
            if i == 1:
                dongStart = indexYear.index(date(2014, 11, 1))
                accDongStart = accPriceRateChange[dongStart]
            if i == 2:
                priceRateChange[0] = (accDongStart - 1)*100
                accPriceRateChange = np.cumprod(list(map(lambda x:round(float(x)/100+1,3), priceRateChange)))

            self.indexYears.append(indexYear)
            self.priceFluc.append(accPriceRateChange)
            if response == False:
                self.legendList[i] = self.legendList[i] + '(No Data)'
                self.hoverTextList.append('')
                self.visibilityList[i] = 'legendonly'
            else:
                hoverText=[
                    str(year.year) + '.' + str(year.month) + '<br>' + self.legendList[i] + ' : ' + 
                    '{0:.3f}'.format(idx) for year, idx in zip(indexYear, accPriceRateChange)
                ]
                self.hoverTextList.append(hoverText)

        self.traceParams = zip(
            self.indexYears,
            self.priceFluc,
            self.hoverTextList,
            self.legendList,
            self.widthList,
            self.colorList,
            self.dashList,
            self.visibilityList,
            self.legendGroupList,
            self.modeList
        )

        # Create Trace
        self.priceFlucTrace = []
        fig = buildFigures()
        for indexYear, accPriceRateChange, hoverText, legendNm, width, colorStyle, dashStyle, visibility, legendGroup, mode in self.traceParams:
            traceParams = {
                'x': indexYear, 
                'y': accPriceRateChange, 
                'text': hoverText, 
                'line_width': width, 
                'line_color': colorStyle, 
                'dash': dashStyle, 
                'name': legendNm, 
                'legendgroup': legendGroup, 
                'visible': visibility,
                'mode': mode
            }
            self.priceFlucTrace.append(fig.buildTraceLine(**traceParams))

        # Create Layout
        layoutParams = {
            'x0': self.indexYears[0][0],
            'xN': self.indexYears[0][-1],
            'yMax': max(accPriceRateChange),
            'yN': accPriceRateChange[-1],
            'type': 'date',
            'tickformat': '%Y',
            'nticks': 6,
            'arrowcolor': colorStyle,
            'traceorder': 'grouped',
            'visible': True
        }
        annotText = str(u'데이터 없음') if accPriceRateChange[-1] == -1 else '{0:,.3f}'.format(accPriceRateChange[-1])
        buttonCount = [1, 3, 5, 10, 15, self.indexYears[0][-1].year - 2005]
        buttons = [dict(count=c, label=str(c) + 'Y', step='year', stepmode='backward') for c in buttonCount]
        buttons[-1]['label'] = 'All'

        
        layoutParams['annotText'] = annotText
        layoutParams['buttons'] = buttons
        self.priceFlucLayout = fig.buildLayoutLine(**layoutParams)
        return True

    def finished(self, result):
        if result:
            fig = dict(data=self.priceFlucTrace, layout = self.priceFlucLayout)
            config = {'scrollZoom': True, 'editable': False, 'displayModeBar': False}
            raw_plot = plotly.offline.plot(fig, output_type='div', config=config, show_link = False)
            self.plot_path = os.path.join(tempfile.gettempdir(), 'price_fluctuation' + str(self.plotCat) + '.html')
            with open(self.plot_path, "w") as f:
                f.write(raw_plot)
        else:
            self.plot_path = os.path.join(os.path.dirname(__file__), '../utils/plot/', 'error.html')