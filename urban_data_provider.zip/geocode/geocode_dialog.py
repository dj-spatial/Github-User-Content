# -*- coding: utf-8 -*-
"""
/***************************************************************************
 NSearchDialog
                                 A QGIS plugin
 .
                             -------------------
        begin                : 2017-02-06
        git sha              : $Format:%H$
        copyright            : (C) 2017 by D.J Paek
        email                : 1002jeen@daum.net
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os, os.path
from qgis.core import (Qgis,
                       QgsApplication,
                       QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform,
                       QgsProject,QgsMessageLog,
                       QgsRectangle,
                       QgsVectorLayer,
                       QgsFeature,
                       QgsField,
                       QgsGeometry,
                       QgsPointXY)
from qgis.PyQt.QtGui import QDesktopServices 
from qgis.PyQt.QtCore import QUrl

from PyQt5 import uic
from PyQt5.QtCore import QVariant
from PyQt5.QtWidgets import QDialog, QDialogButtonBox, QTableWidgetItem

import csv
import json

from itertools import islice
from ..utils.utils import get_vworld_data, get_road_coords
from ..utils.geocode_utils import getGeoCode
from .geocode_procedure import Worker

FORM_CLASS_Land, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), '../forms/geocode/geocodeLd_dialog_base.ui'))

FORM_CLASS_Land_FILE, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), '../forms/geocode/geocodeFile_dialog_base.ui'))


class GeocodeDialog(QDialog, FORM_CLASS_Land):
    def __init__(self, iface, parent=None):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

        # Constructor
        super(GeocodeDialog, self).__init__(parent)
        self.setupUi(self)
        okButton = self.dialog_BB.button(QDialogButtonBox.Ok)
        closeButton = self.dialog_BB.button(QDialogButtonBox.Close)
        helpButton = self.dialog_BB.button(QDialogButtonBox.Help)

        self.addressTable.setColumnWidth(0, 245)
        self.addressTable.setColumnWidth(1, 245)
        self.addressTable.setColumnWidth(2, 135)

        self.bdNameTable.setColumnWidth(0, 110)
        self.bdNameTable.setColumnWidth(1, 100)
        self.bdNameTable.setColumnWidth(2, 95)

        # Connect signals
        okButton.clicked.connect(self.geocode_land)
        closeButton.clicked.connect(self.reject)
        helpButton.clicked.connect(self.giveHelp)
        self.addressButton.clicked.connect(self.get_address)
        self.addressTable.itemSelectionChanged.connect(self.change_land)
        self.showBdPolygon.clicked.connect(self.get_buildings)
        self.bdButtonGroup.buttonClicked.connect(self.change_selection_mode)

        # Set instance variables
        self.currentCRS = self.iface.mapCanvas().mapSettings().destinationCrs()
        self.currentIdx = -1

	# end of __init__

    def get_address(self):
        self.addressTable.setCurrentIndex(self.addressTable.model().index(-1,-1))
        self.addressTable.clearContents()
        self.addressTable.setRowCount(0)
        self.showBdPolygon.setChecked(False)
        self.bdNameTable.setCurrentIndex(self.bdNameTable.model().index(-1,-1))
        self.bdNameTable.clearContents()
        self.bdNameTable.setRowCount(0)
        self.landUnit.setChecked(True)

        self.search_address = self.addressEdit.text()
        if self.search_address == '':
            self.iface.messageBar().pushMessage("Info:", u'입력된 주소가 없습니다.', level=Qgis.Info,  duration=5)
            return

        geocode_list = getGeoCode(self.search_address)

        if geocode_list["total_count"] < 1:
            self.iface.messageBar().pushMessage("Info:", geocode_list["feedback"], level=Qgis.Info, duration=5)
            return
        self.pnu = geocode_list["pnu"]
        self.emdCd = geocode_list["emdCd"]
        self.roadAddr = geocode_list["roadAddr"]
        self.jibunAddr = geocode_list["jibunAddr"]
        self.rd_nm = geocode_list["rd_nm"]
        self.buld_no = geocode_list["buld_no"]
        self.bdNm = geocode_list["bdNm"]
        self.bdNmDet = geocode_list["bdNmDet"]
        self.reqType = geocode_list["reqType"]
        self.reqSrc = geocode_list["reqSrc"]
        self.x = geocode_list["x"]
        self.y = geocode_list["y"]
        self.crs = geocode_list["crs"]
        self.geoAttr = geocode_list["geoAttr"]
        self.landFcList = [''] * len(self.jibunAddr)
        self.bdFcList = [''] * len(self.jibunAddr)

        #create a address table	
        self.addressTable.setRowCount(len(self.pnu))
        for i, (jibun, road, bdNm, bdNmDet) in enumerate(zip(self.jibunAddr, self.roadAddr, self.bdNm, self.bdNmDet)):
            jibunItem = QTableWidgetItem(jibun)
            roadItem = QTableWidgetItem(road)
            if bdNm == '' and bdNmDet == '':
                bdNmDisp = u'없음'
            elif bdNm != '' and bdNmDet == '':
                bdNmDisp = bdNm
            elif bdNm == '' and bdNmDet != '':
                bdNmDisp = bdNmDet
            else:
                bdNmDisp = bdNm + '(' + bdNmDet + ')'
            bdNmItem = QTableWidgetItem(bdNmDisp)
            self.addressTable.setItem(i, 0, jibunItem)
            self.addressTable.setItem(i, 1, roadItem)
            self.addressTable.setItem(i, 2, bdNmItem)
        self.progressLB.setText(geocode_list["feedback"])

    def change_land(self):
        self.currentIdx = self.addressTable.currentRow()
        self.bdNameTable.clearContents()
        self.bdNameTable.setRowCount(0)
        if self.showBdPolygon.isChecked() and self.currentIdx != -1:
            self.get_buildings()
     
    def get_land_fc(self):
        pnu = self.pnu[self.currentIdx]
        if self.landFcList[self.currentIdx] == '':
            if self.reqSrc == "Mois":
                pts = self.get_mois_xy(self.currentIdx)
                pointX = pts['juso'][0]['entX']
                pointY = pts['juso'][0]['entY']
            else:
                pointX = self.x[self.currentIdx]
                pointY = self.y[self.currentIdx]
            geomFilterPoint = 'POINT(' + pointX + ' ' + pointY + ')'
            try:
                result = get_vworld_data('LP_PA_CBND_BUBUN', 1, '', '', geomFilterPoint, '')
            except:
                self.msg = u'선택된 주소의 토지 지오메트리 정보 요청에 장애가 발생하였습니다.'
                self.iface.messageBar().pushMessage("Warning:", self.msg, level=Qgis.Warning, duration=5)
                return
            else:
                landFc = result['featureCollection']
                if result['status'] == 'OK':
                    for i, f in enumerate(self.landFcList):
                        if self.pnu[i] == pnu:
                            self.landFcList[i] = landFc 
                else:
                    self.msg = result['status']
                    self.iface.messageBar().pushMessage("Warning:", self.msg, level=Qgis.Warning, duration=5)
                    return
        else:
            landFc = self.landFcList[self.currentIdx]
        return landFc
       
    def get_buildings(self):
        self.landUnit.setChecked(True)
        if not self.showBdPolygon.isChecked():
            return
        self.change_selection_mode()
        if self.currentIdx == -1:
            self.iface.messageBar().pushMessage("Info:", u'선택된 주소가 없습니다.', level=Qgis.Info,  duration=5)
            return
        landFc = self.get_land_fc()

        #주소의 XY좌표가 속하는 필지의 폴리곤 지오메트리 필터
        if landFc:
            geom = [str(item[0]) + ' ' + str(item[1]) for item in landFc['features'][0]['geometry']['coordinates'][0][0]]
            geomFilter = 'POLYGON((' + ','.join(geom) + '))'
        else:
            self.iface.messageBar().pushMessage("Info:", self.msg, level=Qgis.Info,  duration=5)
            return

        #주소의 도로명과 건물번호로 구성된 속성 필터 
        pnu = self.pnu[self.currentIdx]
        attr = ['emdCd', 'rd_nm', 'buld_no']
        operator = ['=', '=', '=']
        attrFilter = [self.emdCd[self.currentIdx], self.rd_nm[self.currentIdx], self.buld_no[self.currentIdx]]

        if self.bdFcList[self.currentIdx] == '':
            #필지 단위 건물데이터(한 필지 내 상이한 도로명주소 있을 수 있으므로 필지 폴리곤 내 모든 건물 검색)
            try:
                result = get_vworld_data('LT_C_SPBD', 1, '', '', geomFilter, '')
            except:
                self.iface.messageBar().pushMessage("Warning:", u'건물정보 요청 중 장애가 발생하였습니다.', level=Qgis.Warning,  duration=5)
                return
            else:
                self.buildingFc = result['featureCollection']
                if self.buildingFc == 'OK':
                    resultByGeom = self.buildingFc["features"]
                else:
                    self.buildingFc = {
                        'type':'FeatureCollection',
                        'features':[], 
                        'crs': {
                            'type': 'name',
                            'properties': {
                                'name': 'urn:ogc:def:crs:EPSG::5179'
                            }
                        }
                    }
                    resultByGeom = []

            #도로명주소 단위 건물데이터(택지개발, 정비사업 등 지적미정리 필지는 누락된 건물 있을 수 있으므로 같은 도로명주소 내 모든 건물 검색)
            try:
                result = get_vworld_data('LT_C_SPBD', 1, attr, operator, '', attrFilter)
            except:
                self.iface.messageBar().pushMessage("Warning:", u'건물정보 요청 중 장애가 발생하였습니다.', level=Qgis.Warning,  duration=5)
                return
            else:
                buildingFcRoad = result["featureCollection"]
                if buildingFcRoad:
                    resultByAttr = buildingFcRoad["features"]
                else:
                    resultByAttr = []
                resultUnion = resultByGeom + resultByAttr
            
                if resultUnion:
                    #필지단위 건물데이터 + 도로명주소 단위 건물데이터
                    resultFeat = [feat for i, feat in enumerate(resultUnion) if feat not in resultUnion[i+1:]]
                    self.buildingFc['features'] = resultFeat
                    for i, f in enumerate(self.bdFcList):
                        if self.pnu[i] == pnu:
                            self.bdFcList[i] = self.buildingFc
                else:
                    self.iface.messageBar().pushMessage("Info:", u'해당 주소에는 건물 정보가 없습니다.', level=Qgis.Info,  duration=5)
                    return
        else:
            self.buildingFc = self.bdFcList[self.currentIdx]
            
        #건물정보 테이블에 출력
        try:
            self.bdNameTable.setRowCount(len(self.buildingFc['features']))
        except:
            self.iface.messageBar().pushMessage("Info:", u'해당 주소에는 건물 정보가 없습니다.', level=Qgis.Info,  duration=5)
        else:
            for i, fc in enumerate(self.buildingFc['features']):
                bd_mgt_sn = QTableWidgetItem(fc['properties']['bd_mgt_sn'])
                buld_nm = QTableWidgetItem(fc['properties']['buld_nm'])
                buld_nm_dc = QTableWidgetItem(fc['properties']['buld_nm_dc'])
                self.bdNameTable.setItem(i, 0, bd_mgt_sn)
                self.bdNameTable.setItem(i, 1, buld_nm)
                self.bdNameTable.setItem(i, 2, buld_nm_dc)

    def change_selection_mode(self):
        if self.landUnit.isChecked():
            self.bdNameTable.setCurrentIndex(self.bdNameTable.model().index(-1,-1))
            self.bdNameTable.setSelectionMode(0)
            self.bdNameTable.clearSelection()
        else:
            self.bdNameTable.setSelectionMode(3)

    def geocode_land(self):
        if not self.showPoint.isChecked() and not self.showLandPolygon.isChecked() and not self.showBdPolygon.isChecked():
            self.iface.messageBar().pushMessage("Info:", u'추가할 토지 또는 건물 레이어의 종류를 선택해주세요.', level=Qgis.Info,  duration=5)
            return
        landIdx = self.addressTable.currentRow()
        if landIdx == -1:
            self.iface.messageBar().pushMessage("Info:", u'선택된 주소가 없습니다.', level=Qgis.Info,  duration=5)
            return

        if self.bdUnit.isChecked() and not self.bdNameTable.selectedIndexes():
            self.iface.messageBar().pushMessage("Info:", u'선택된 건물이 없습니다.', level=Qgis.Info,  duration=5)
            return

        layerToShow = []

        jibunAddr = self.jibunAddr[landIdx]
        roadAddr = self.roadAddr[landIdx]
        pnu = self.pnu[landIdx]
        bdNm = self.bdNm[landIdx]
        emdCd = self.emdCd[landIdx]
        if self.reqType[landIdx] == 'PARCEL':
            reqType = u'지번주소'
        else:
            reqType = u'도로명주소'
        reqSrc = self.reqSrc

        if reqSrc == "Mois":
            pts = self.get_mois_xy(landIdx)
            pointX = pts['juso'][0]['entX']
            pointY = pts['juso'][0]['entY']
        else:
            pointX = self.x[landIdx]
            pointY = self.y[landIdx]

        project = QgsProject.instance()

        #create a land polygon layer
        if self.showLandPolygon.isChecked():
            landFc = self.get_land_fc()
            if landFc:
                landFc["features"][0]["properties"][u"요청주소"] = self.search_address
                landFc["features"][0]["properties"][u"도로명주소"] = roadAddr
                landFc["features"][0]["properties"][u"건물이름"] = bdNm
                landFc["features"][0]["properties"][u"주소원천"] = reqSrc
                landFc["features"][0]["properties"][u"요청타입"] = reqType
                featureJson = json.dumps(landFc)
                landPolygonLayer = QgsVectorLayer(featureJson, u"Geocode(토지):" + self.search_address, "ogr")
                landPolygonLayer.updateExtents()
                layerToShow.append(landPolygonLayer)
            else:
                self.iface.messageBar().pushMessage("Info:", self.msg, level=Qgis.Info,  duration=5)

        #create a building polygon layer as land unit
        if self.showBdPolygon.isChecked() and self.landUnit.isChecked():
            try:
                bdFc = self.buildingFc
            except:
                self.iface.messageBar().pushMessage("Info:", u'요청하신 주소의 건물폴리곤 정보를 얻을 수 없습니다.', level=Qgis.Info,  duration=5)
            else:
                if bdFc and bdFc['features']:
                    for f in bdFc["features"]:
                        f["properties"][u"요청주소"] = self.search_address
                        f["properties"][u"지번주소"] = jibunAddr
                        f["properties"][u"도로명주소"] = roadAddr
                        f["properties"][u"PNU"] = pnu
                        f["properties"][u"행정구역코드"] = emdCd
                        f["properties"][u"주소원천"] = reqSrc
                        f["properties"][u"요청타입"] = reqType
                    featureJson = json.dumps(bdFc)
                    bdPolygonLayer = QgsVectorLayer(featureJson, u"Geocode(건물):" + self.search_address, "ogr")
                    layerToShow.append(bdPolygonLayer)
                else:
                    self.iface.messageBar().pushMessage("Info:", u'요청하신 주소의 건물폴리곤 정보를 얻을 수 없습니다.', level=Qgis.Info,  duration=5)

        #create a building polygon selected
        if self.showBdPolygon.isChecked() and self.bdUnit.isChecked():
            try:
                bdFc = self.bdFcList[landIdx]
            except:
                self.iface.messageBar().pushMessage("Info:", u'요청하신 주소의 건물폴리곤 정보를 얻을 수 없습니다.', level=Qgis.Info,  duration=5)
            else:
                if bdFc and bdFc['features']:
                    bdSelectedList = [i.row() for i in self.bdNameTable.selectedIndexes()[::3]]
                    if len(bdSelectedList) > 0:
                        selectedFeats = [bdFc['features'][i] for i in bdSelectedList]
                        for f in selectedFeats:
                            f["properties"][u"요청주소"] = self.search_address
                            f["properties"][u"지번주소"] = jibunAddr
                            f["properties"][u"도로명주소"] = roadAddr
                            f["properties"][u"PNU"] = pnu
                            f["properties"][u"행정구역코드"] = emdCd
                            f["properties"][u"주소원천"] = reqSrc
                            f["properties"][u"요청타입"] = reqType
                        toDump = {
                            'type':'FeatureCollection',
                            'features':selectedFeats, 
                            'crs': {
                                'type': 'name',
                                'properties': {
                                    'name': 'urn:ogc:def:crs:EPSG::5179'
                                }
                            }
                        }
                        featureJson = json.dumps(toDump)
                        bdPolygonLayer = QgsVectorLayer(featureJson, u"Geocode(건물):" + self.search_address, "ogr")
                        layerToShow.append(bdPolygonLayer)
                    else:
                        self.iface.messageBar().pushMessage("Info:", u'요청하신 주소의 건물폴리곤 정보를 얻을 수 없습니다.', level=Qgis.Info,  duration=5)

        #create a point layer
        if self.showPoint.isChecked():
            try:
                geom = QgsGeometry.fromPointXY(QgsPointXY(float(pointX), float(pointY)))
            except:
                self.iface.messageBar().pushMessage("Info:", u'요청하신 주소의 포인트 정보를 얻을 수 없습니다.', level=Qgis.Info,  duration=5)
            else:
                pointLayer = QgsVectorLayer("point?crs=epsg:5179", u'Geocode(포인트):' + self.search_address, "memory")
                pr = pointLayer.dataProvider()

                #add fields 
                fields = [u'요청주소', u'지번주소', '도로명주소', 'PNU', '건물이름', '주소원천', '요청타입']
                fieldTypes = [QVariant.String, QVariant.String, QVariant.String, QVariant.String, QVariant.String, QVariant.String, QVariant.String]
                fieldList = [QgsField(f, t) for f, t in zip(fields, fieldTypes)]
                pr.addAttributes(fieldList)
                pointLayer.updateFields()

                #add a feature and geometry
                fet = QgsFeature()
                crs = self.crs[landIdx]        
                if crs != 'EPSG:5179':
                    xform = QgsCoordinateTransform(QgsCoordinateReferenceSystem(crs), QgsCoordinateReferenceSystem('EPSG:5179'), project)
                    geom.transform(xform)
                fet.setGeometry(geom)

                #add attributes 
                attrs = [self.search_address, jibunAddr, roadAddr, pnu, bdNm, reqSrc, reqType]
                fet.setAttributes(attrs)
                pr.addFeatures([fet])
                extent = pointLayer.extent()
                pointLayer.updateExtents()
                layerToShow.append(pointLayer)

        #load layers
        if layerToShow:
            canvas = self.iface.mapCanvas()
            canvasCrs = canvas.mapSettings().destinationCrs()
            xform2Canvas = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:5179"), canvasCrs, project)
            extent = QgsRectangle()
            extent.setMinimal()
            for lyr in layerToShow:
                project.addMapLayer(lyr)
                extent.combineExtentWith(lyr.extent())
            extent.scale(1.1)
            if canvas.scale() < 500:
                canvas.zoomScale(500)
            canvas.setExtent(xform2Canvas.transform(extent))
            self.progressLB.setText(u'완료되었습니다.')
        else:
            self.progressLB.setText(u'요청하신 주소의 정보를 얻을 수 없습니다.')


    def get_mois_xy(self, landIdx):
        admCd = self.geoAttr[landIdx][0]
        rnMgtSn = self.geoAttr[landIdx][1]
        udrtYn = self.geoAttr[landIdx][2]
        buldMnnm = self.geoAttr[landIdx][3]
        buldSlno = self.geoAttr[landIdx][4]
        pts = get_road_coords(admCd, rnMgtSn, udrtYn, buldMnnm, buldSlno)
        return pts
        
    def reject(self):
        """Reject override."""
        # exit the dialog
        QDialog.reject(self)

    def giveHelp(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(self.plugin_dir + "/help/geocodeLd.html"))

class GeocodeFileDialog(QDialog, FORM_CLASS_Land_FILE):
    def __init__(self, iface, parent=None):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

        # Constructor
        super(GeocodeFileDialog, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle(u'토지-파일로부터 검색')

        okButton = self.dialog_BB.button(QDialogButtonBox.Ok)
        cancelButton = self.dialog_BB.button(QDialogButtonBox.Cancel)
        cancelButton.setEnabled(False)
        closeButton = self.dialog_BB.button(QDialogButtonBox.Close)
        helpButton = self.dialog_BB.button(QDialogButtonBox.Help)
        self.fileWG.setFilter("CSV (*.csv);;TXT (*.txt)")

        # Connect signals
        okButton.clicked.connect(self.getAddress)
        cancelButton.clicked.connect(self.killWorker)
        closeButton.clicked.connect(self.reject)
        helpButton.clicked.connect(self.giveHelp)

        self.headerCheck.toggled.connect(self.changeTable)
        self.fileWG.fileChanged.connect(self.getTop10)

	# end of __init__

    def getTop10(self):
        self.refreshUi()
        filePath = self.fileWG.filePath()
        if filePath == '':
            self.progressLB.setText(u'경로를 선택하거나 입력하세요.')
            return
        try:
            f = open(filePath, 'r', encoding='CP949')
        except:
            self.progressLB.setText(u'해당 경로의 파일이나 폴더가 없습니다.')
        else:
            with f:
                csvreader = csv.reader(f)
                self.csvData = list(islice(csvreader, 11))
            self.headerCheck.setCheckable(True)
            self.headerCheck.setChecked(True)
            self.changeTable()

    def changeTable(self):
        self.headerCB.clear()
        if self.headerCheck.isChecked() == True:
            headers = self.csvData[0]
            address = self.csvData[1:11]
        else:
            headers = ['field_' + str(i) for i in range(0, len(self.csvData[0]))]
            address = self.csvData[0:10]
        self.addressTable.setColumnCount(len(headers))
        self.addressTable.setRowCount(len(address))
        self.addressTable.setHorizontalHeaderLabels(headers)
        addressIdx = self.headerCB.currentIndex()
        for i, row in enumerate(address):
            for j, col in enumerate(row):
                cItem = QTableWidgetItem(col)
                self.addressTable.setItem(i, j, cItem)
        for hd in headers:
             self.headerCB.addItem(hd)

    def refreshUi(self):
        self.headerCB.clear()
        self.headerCheck.setCheckable(False)
        self.headerCheck.setChecked(False)
        self.progressLB.setText(u'')
        self.addressTable.clearContents()
        self.addressTable.setRowCount(0)
        self.addressTable.setColumnCount(0)

    def getAddress(self):
        filePath = self.fileWG.filePath()
        fieldIndex = self.headerCB.currentIndex()
        if filePath == '':
            self.progressLB.setText(u'경로를 선택하거나 입력하세요.')
            return
        if fieldIndex == -1:
            self.iface.messageBar().pushMessage("Info:", u'주소가 포함된 필드를 선택해 주세요.', level=Qgis.Info,  duration=5)
            return
        try:
            f = open(filePath, 'r', encoding='CP949')
        except:
            self.progressLB.setText(u'해당 경로의 파일이나 폴더가 없습니다.')
        else:
            with f:
                csvreader = csv.reader(f)
                addressCol = list(zip(*csvreader))[fieldIndex]
            if self.headerCheck.isChecked():
                addressCol = addressCol[1:]

        searchCount = len(addressCol)
        self.progressBar.setValue(0)
        self.progressBar.setMaximum(searchCount)

        params = {
            "addressCol":addressCol,
            "showLandPolygon":self.showLandPolygon.isChecked(),
            "showBdPolygon":self.showBdPolygon.isChecked(),
            "filePath":filePath
        }
        self.worker = Worker(params)
        self.initMsg = u'검색 시작...'
        QgsApplication.taskManager().addTask(self.worker)

        # start the worker in a new thread
        #self.worker.begun.connect(lambda: self.progressLB.setText(self.initMsg))
        self.worker.workerStep.connect(self.progressLB.setText)
        self.worker.progressChanged.connect(lambda: self.progressBar.setValue(self.worker.progress()))
        self.worker.taskCompleted.connect(self.workerFinished)
        self.worker.taskTerminated.connect(self.workerFinished)

        self.dialog_BB.button(QDialogButtonBox.Ok).setEnabled(False)
        self.dialog_BB.button(QDialogButtonBox.Close).setEnabled(False)
        self.dialog_BB.button(QDialogButtonBox.Cancel).setEnabled(True)
    # end of worker

    def workerFinished(self):
        self.progressBar.setValue(0.0)
        self.dialog_BB.button(QDialogButtonBox.Ok).setEnabled(True)
        self.dialog_BB.button(QDialogButtonBox.Close).setEnabled(True)
        self.dialog_BB.button(QDialogButtonBox.Cancel).setEnabled(False)

    def killWorker(self):
        """Kill the worker thread."""
        if self.worker is not None:
            self.progressLB.setText(u'취소가 종료될 때까지 잠시만 기다려주세요.')        
            self.worker.cancel()

    # Implement the accept method to avoid exiting the dialog when starting the work
    def accept(self):
        pass

    def reject(self):
        """Reject override."""
        # exit the dialog
        QDialog.reject(self)

    def giveHelp(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(self.plugin_dir + "/help/geocodeLd.html"))