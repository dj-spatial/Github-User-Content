# -*- coding: utf-8 -*-
"""
/***************************************************************************
 NSearchDialog
                                 A QGIS plugin
 .
                             -------------------
        begin                : 2017-02-06
        git sha              : $Format:%H$
        copyright            : (C) 2017 by D.J Paek
        email                : 1002jeen@daum.net
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from qgis.core import (Qgis,
                       QgsTask,
                       QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform,
                       QgsProject,QgsMessageLog,
                       QgsVectorLayer,
                       QgsFeature,
                       QgsField,
                       QgsGeometry,
                       QgsPointXY
                       )
from qgis.utils import iface					   
from PyQt5.QtCore import pyqtSignal
import json
from pathlib import Path
from PyQt5.QtCore import QVariant
from ..utils.utils import get_vworld_data, get_road_coords
from ..utils.geocode_utils import getGeoCode

class Worker(QgsTask):
    workerStep = pyqtSignal(str)  # For reporting progress

    def __init__(self, params):
        QgsTask.__init__(self)
        self.addressCol = params["addressCol"]
        self.showLandPolygon = params["showLandPolygon"]
        self.showBdPolygon = params["showBdPolygon"]
        self.filePath = params["filePath"]
        self.exception = None

    def run(self):
        count = 0
        self.successPoints = 0
        self.successLand = 0
        self.successBd = 0
        self.pointFeats = []
        self.project = QgsProject.instance()

        # 데이터 검색 시작
        self.workerStep.emit(u'포인트 데이터 요청..')
        for searchAddress in self.addressCol:
            if self.isCanceled():
                return False

            #create a point layer
            self.fet = QgsFeature()
            geoCodeList = getGeoCode(searchAddress)
            if geoCodeList["total_count"] < 1:
                jibunAddr = ''
                roadAddr = ''
                pnu = ''
                emdCd = ''
                rd_nm = ''
                buld_no = ''
                bdNm = ''
                reqSrc = ''
                reqType = ''
                success = "Fail"
            else:
                jibunAddr = geoCodeList["jibunAddr"][0]
                roadAddr = geoCodeList["roadAddr"][0]
                pnu = geoCodeList["pnu"][0]
                emdCd = geoCodeList["emdCd"][0]
                rd_nm = geoCodeList["rd_nm"][0]
                buld_no = geoCodeList["buld_no"][0]
                bdNm = geoCodeList["bdNm"][0]
                reqSrc = geoCodeList["reqSrc"]
                crs = geoCodeList["crs"][0]
                if geoCodeList["reqType"][0] == 'PARCEL':
                    reqType = u'지번주소'
                else:
                    reqType = u'도로명주소'
                if reqSrc == "Mois":
                    geoAttr = geoCodeList["geoAttr"][0]
                    admCd = geoAttr[0]
                    rnMgtSn = geoAttr[1]
                    udrtYn = geoAttr[2]
                    buldMnnm = geoAttr[3]
                    buldSlno = geoAttr[4]
                    pts = get_road_coords(admCd, rnMgtSn, udrtYn, buldMnnm, buldSlno)
                    pointX = pts['juso'][0]['entX']
                    pointY = pts['juso'][0]['entY']
                else:
                    pointX = geoCodeList["x"][0]
                    pointY = geoCodeList["y"][0]
                success = "Success"

                #add a geometry
                try:
                    pointGeom = QgsGeometry.fromPointXY(QgsPointXY(float(pointX), float(pointY)))
                except:
                    success = "Fail"
                else:
                    #add a feature and geometry
                    if crs != 'EPSG:5179':
                        xform = QgsCoordinateTransform(QgsCoordinateReferenceSystem(crs), QgsCoordinateReferenceSystem('EPSG:5179'), self.project)
                        pointGeom.transform(xform)
                    self.fet.setGeometry(pointGeom)
                    success = "Success"
                    self.successPoints += 1

            #add attributes
            attrs = [searchAddress, jibunAddr, roadAddr, pnu, emdCd, rd_nm, buld_no, bdNm, reqSrc, reqType, success]
            self.fet.setAttributes(attrs)
            self.pointFeats.append(self.fet)
            count += 1
            self.setProgress(count)

        #create a land polygon layer
        if self.showLandPolygon:
            self.workerStep.emit(u'토지 폴리곤 데이터 요청..')

            count = 0
            polygonFeats = []
            featureCollection = {
                "type": "FeatureCollection",
                "crs": {
                    "type": "name",
                    "properties": {
                      "name": "urn:ogc:def:crs:EPSG::5179"
                    }
                }
            }
            for feat in self.pointFeats:
                if self.isCanceled():
                    return False
                searchAddress = feat.attributes()[0]
                roadAddr = feat.attributes()[2]
                pnu = feat.attributes()[3]
                bdNm = feat.attributes()[7]
                reqSrc = feat.attributes()[8]
                reqType = feat.attributes()[9]
                try:
                    landFc = get_vworld_data('LP_PA_CBND_BUBUN', 1, ['pnu'], ['='], '', [pnu])["featureCollection"]
                except:
                    landFc = {"features": [{"type": "Feature", "properties":{u"요청주소":searchAddress, u"검색결과":"Fail"}}]}
                else:
                    if landFc:
                        landFc["features"][0]["properties"][u"요청주소"] = searchAddress
                        landFc["features"][0]["properties"][u"도로명주소"] = roadAddr
                        landFc["features"][0]["properties"][u"건물이름"] = bdNm
                        landFc["features"][0]["properties"][u"주소원천"] = reqSrc
                        landFc["features"][0]["properties"][u"요청타입"] = reqType
                        landFc["features"][0]["properties"][u"검색결과"] = "Success"
                        self.successLand += 1
                    else:
                        landFc = {"features": [{"type": "Feature", "properties":{u"요청주소":searchAddress, u"검색결과":"Fail"}}]}
                polygonFeats.append(landFc["features"][0])
                count += 1
                self.setProgress(count)
            featureCollection.update({"features":polygonFeats})
            self.landFeatureJson = json.dumps(featureCollection)

        #create a building polygon layer
        if self.showBdPolygon:
            self.workerStep.emit(u'건물 폴리곤 데이터 요청..')

            count = 0
            polygonFeats = []
            featureCollection = {
                "type": "FeatureCollection",
                "crs": {
                    "type": "name",
                    "properties": {
                      "name": "urn:ogc:def:crs:EPSG::5179"
                    }
                }
            }
            
            for feat in self.pointFeats:
                if self.isCanceled():
                    return False
                searchAddress = feat.attributes()[0]
                jibunAddr = feat.attributes()[1]
                roadAddr = feat.attributes()[2]
                pnu = feat.attributes()[3]
                emdCd = feat.attributes()[4]
                rd_nm = feat.attributes()[5]
                buld_no = feat.attributes()[6]
                reqSrc = feat.attributes()[8]
                reqType = feat.attributes()[9]
                attr = ['emdCd', 'rd_nm', 'buld_no']
                operator = ['=', '=', '=']
                attrFilter = [emdCd, rd_nm, buld_no]
                failedFc = {"type": "Feature", "properties":{u"요청주소":searchAddress, u"검색결과":"Fail"}}

                try:
                    geomX = feat.geometry().asPoint().x()
                    geomY = feat.geometry().asPoint().y()
                except:
                    polygonFeats.append(failedFc)
                else:
                    geomFilter = 'POINT(' + str(geomX) + ' ' + str(geomY) + ')'
                
                try:
                    #주소의 XY좌표가 속하는 필지의 폴리곤 지오메트리 필터
                    landFc = get_vworld_data('LP_PA_CBND_BUBUN', 1, '', '', geomFilter, '')["featureCollection"]
                except:
                    polygonFeats.append(failedFc)
                else:
                    geom = [str(item[0]) + ' ' + str(item[1]) for item in landFc['features'][0]['geometry']['coordinates'][0][0]]
                    geomFilter = 'POLYGON((' + ','.join(geom) + '))'

                #필지 폴리곤 내부에 속한 건물데이터(한 필지 내 상이한 도로명주소 있을 수 있으므로 필지 폴리곤 내 모든 건물 검색)
                try:
                    bdFc = get_vworld_data('LT_C_SPBD', 1, '', '', geomFilter, '')["featureCollection"]
                except:
                    polygonFeats.append(failedFc)
                else:
                    if bdFc:
                        resultByGeom = bdFc["features"]
                    else:
                        resultByGeom = []

                #도로명주소에 속한 건물데이터(택지개발, 정비사업 등 지적미정리 필지는 누락된 건물 있을 수 있으므로 같은 도로명주소 내 모든 건물 검색)
                try:
                    bdFcRoad = get_vworld_data('LT_C_SPBD', 1, attr, operator, '', attrFilter)["featureCollection"]
                except:
                    polygonFeats.append(failedFc)
                else:
                    if bdFcRoad:
                        resultByAttr = bdFcRoad["features"]
                    else:
                        resultByAttr = []
                    resultUnion = resultByGeom + resultByAttr
                    
                    if resultUnion:
                        resultFeat = [feat for i, feat in enumerate(resultUnion) if feat not in resultUnion[i+1:]]
                        bdFc['features'] = resultFeat
                    if bdFc:
                        for f in bdFc["features"]:
                            f["properties"][u"요청주소"] = searchAddress
                            f["properties"][u"지번주소"] = jibunAddr
                            f["properties"][u"도로명주소"] = roadAddr
                            f["properties"][u"PNU"] = pnu
                            f["properties"][u"행정구역코드"] = emdCd
                            f["properties"][u"주소원천"] = reqSrc
                            f["properties"][u"요청타입"] = reqType
                            f["properties"][u"검색결과"] = "Success"
                            polygonFeats.append(f)
                        self.successBd += 1
                    else:
                        polygonFeats.append(failedFc)
                count += 1
                self.setProgress(count)
            featureCollection.update({"features":polygonFeats})
            self.bdFeatureJson = json.dumps(featureCollection)
        return True

    def finished(self, result):
        if result:
            #create a point layer
            self.layer_name = 'Geocode:' + Path(self.filePath).stem
            pointLayer = QgsVectorLayer("point?crs=epsg:5179", self.layer_name + '-포인트', "memory")
            pr = pointLayer.dataProvider()

            ##add fields
            fields = [u'요청주소', u'지번주소', u'도로명주소', 'PNU', u'행정구역코드', u'도로명', '건물번호', u'건물이름', u'주소원천', u'요청타입', u'검색결과']
            fieldTypes = [QVariant.String] * len(fields)
            fieldList = [QgsField(f, t) for f, t in zip(fields, fieldTypes)]
            pr.addAttributes(fieldList)
            pointLayer.updateFields()            
            pr.addFeatures(self.pointFeats)
            self.project.addMapLayer(pointLayer)

            #create a land polygon layer
            if self.showLandPolygon:
                landPolygonLayer = QgsVectorLayer(self.landFeatureJson, self.layer_name + '-필지', "ogr")
                self.project.addMapLayer(landPolygonLayer)

            #create a building polygon layer
            if self.showBdPolygon:
                bdPolygonLayer = QgsVectorLayer(self.bdFeatureJson, self.layer_name + '-건물', "ogr")
                self.project.addMapLayer(bdPolygonLayer)

            pointLayer.updateExtents()
            canvas = iface.mapCanvas()
            canvasCrs = canvas.mapSettings().destinationCrs()
            xform2Canvas = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:5179"), canvasCrs, self.project)
            canvas.setExtent(xform2Canvas.transform(pointLayer.extent()))

            self.step = u'요청주소(' + str(len(self.addressCol)) + u'개) - ' + u'검색주소(포인트:' + str(self.successPoints) + u'개 토지폴리곤:' + str(self.successLand) + u'개 건물폴리곤:' + str(self.successBd) + u'개)'
            self.workerStep.emit(self.step)
        else:
            if self.exception is None:
                self.step = u'취소 또는 예외발생으로 실행이 취소되었습니다.'
                self.step_progress()
                iface.messageBar().pushMessage("Warning:", self.step, level=Qgis.Warning,  duration = 5)
            else:
                self.step = self.exceptionMsg
                self.step_progress()
                iface.messageBar().pushMessage("Critical:", self.exceptionMsg, level=Qgis.Critical,  duration = 5)

    def step_progress(self):
        self.step = str(self.step) + '.'
        self.workerStep.emit(self.step)